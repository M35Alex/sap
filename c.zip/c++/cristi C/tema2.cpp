//it counldn't read a line (511733,2731998-1,4904420-2,7517088-3,9974366-4) so i removed a line/character in that line
#define _CRT_SECURE_NO_WARNINGS
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/bio.h>
#include <openssl/sha.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cctype>

void rsaDecrypt(unsigned char* key, int sizeOfKey, unsigned char* tmpBuffer, int sizeOfTmpBuffer, unsigned char*& output, int& sizeOfOutput) {
	BIO* bio = BIO_new_mem_buf(key, sizeOfKey);
	RSA* rsa = RSA_new();
	if (!PEM_read_bio_RSAPublicKey(bio, &rsa, nullptr, nullptr)) {
		printf("Problem occured!");
	}
	else {
		unsigned char* outputBuffer = (unsigned char*)malloc(RSA_size(rsa));

		int result = RSA_public_decrypt(sizeOfTmpBuffer,
			(unsigned char*)tmpBuffer,
			(unsigned char*)outputBuffer,
			rsa,
			RSA_PKCS1_PADDING);
		output = outputBuffer;
		sizeOfOutput = result;
		BIO_free(bio);
		RSA_free(rsa);
	}
}
char* byteArrayToChar(unsigned char* input, int inputSize) {
	char* output;
	char* hexaDeciNum;
	output = (char*)malloc(inputSize * 4 - 4); //*2 because each byte is reprezented by 2 characters
	for (int i = 0; i < inputSize * 2 - 2; i++)
	{
		int byteOfI = int(input[i]);

		hexaDeciNum = (char*)malloc(2 * sizeof(char));
		//reset hexaDeciNum
		hexaDeciNum[0] = '0';
		hexaDeciNum[1] = '0';


		int counter = 0;
		while (byteOfI != 0) {

			// temporary variable to store remainder
			int temp = 0;

			// storing remainder in temp variable.
			temp = byteOfI % 16;

			// check if temp < 10
			if (temp < 10) {
				hexaDeciNum[counter] = (char)(temp + 48);
				counter++;
			}
			else {
				hexaDeciNum[counter] = (char)(temp + 55);
				counter++;
			}
			byteOfI = byteOfI / 16;
		}
		output[i * 2] = hexaDeciNum[1];
		output[i * 2 + 1] = hexaDeciNum[0];
		free(hexaDeciNum);
	}
	return output;
}
int main() {
	FILE* passFile;
	FILE* RSASignFile;
	FILE* PuKeyFile;

#pragma region Read files
	passFile = fopen("ignis-10M.txt", "rb");
	RSASignFile = fopen("RSASign.sig", "rb");
	PuKeyFile = fopen("pubKeySender.pem", "rb");

	if (passFile == NULL) {
		printf("Pass file not found!");
		return 1;
	}
	if (RSASignFile == NULL) {
		printf("RSA signiture file not found!");
		return 1;
	}
	if (PuKeyFile == NULL) {
		printf("Public key file not found!");
		return 1;
	}
#pragma endregion
	unsigned char* key;
	int indexKey = 0;
#pragma region Read key
	char letter = NULL;
	char keyBuffer[500];
	while (!feof(PuKeyFile)) {
		fread(&letter, sizeof(char), 1, PuKeyFile);
		keyBuffer[indexKey] = letter;
		indexKey++;
	}
	indexKey--;
	key = (unsigned char*)malloc(indexKey * sizeof(char));
	for (int i = 0; i < indexKey; i++) {
		key[i] = keyBuffer[i];
	}
#pragma endregion
	unsigned char* RSASigniture;
	int indexRSASigniture = 0;
#pragma region RSA Signiture
	char RSASignitureBuffer[150];
	while (!feof(RSASignFile)) {
		fread(&letter, sizeof(char), 1, RSASignFile);
		RSASignitureBuffer[indexRSASigniture] = letter;
		indexRSASigniture++;
	}
	indexRSASigniture--;
	RSASigniture = (unsigned char*)malloc(indexRSASigniture * sizeof(char));
	for (int i = 0; i < indexRSASigniture; i++) {
		RSASigniture[i] = RSASignitureBuffer[i];
	}
#pragma endregion
	unsigned char* RSASignitureDecryptedBuffer= (unsigned char*)malloc(1000 * sizeof(char));
	int indexRSASignitureDecrypted = 0;
	rsaDecrypt(key, indexKey, RSASigniture, indexRSASigniture, RSASignitureDecryptedBuffer, indexRSASignitureDecrypted);
	char* RSASignitureDecrypted = byteArrayToChar(RSASignitureDecryptedBuffer, indexRSASignitureDecrypted);
	printf("Signiture decrypted with public key is: ");
	for (int i = 0; i < indexRSASignitureDecrypted*2; i++) {
		printf("%c", tolower(RSASignitureDecrypted[i]));
	}
	printf("\n");

#pragma region Search in ignis110M
	unsigned char* finalDigestsha256;//[SHA_DIGEST_LENGTH]
	finalDigestsha256 = (unsigned char*)malloc(SHA256_DIGEST_LENGTH * sizeof(unsigned char));
	SHA256_CTX ctx;
	SHA256_Init(&ctx);

	fseek(passFile, 0L, SEEK_END);
	int sz = ftell(passFile);
	fseek(passFile, 0L, SEEK_SET);
	printf("Size of Ignis is: %d\n", sz);

	int noIter = sz / 250;
	int lastIterSize = sz % 250;
	printf("No of iter: %d\n", noIter);
	printf("Last iter size: %d\n", lastIterSize);


	char* tmpBuffer = (char*)malloc(sizeof(char) * 250);
	int sizeOfTempBuffer = 250;
	for (int i = 0; i < noIter; i++) {
		fread(tmpBuffer, sizeof(char), 250, passFile);
		SHA256_Update(&ctx, tmpBuffer, sizeOfTempBuffer);
	}
	fread(tmpBuffer, sizeof(char), lastIterSize, passFile);
	SHA256_Update(&ctx, tmpBuffer, lastIterSize);

	SHA256_Final(finalDigestsha256, &ctx);

	char* finalDigestsha256ToDisplay = byteArrayToChar(finalDigestsha256, SHA256_DIGEST_LENGTH);
	printf("Digest of ignis10M: ");
	for (int i = 0; i < SHA256_DIGEST_LENGTH*2; i++) {
		printf("%c", tolower(finalDigestsha256ToDisplay[i]));
	}
	printf("\n");

	bool ok = 1;
	for (int i = 0; i < SHA256_DIGEST_LENGTH * 2; i++) {
		if (finalDigestsha256ToDisplay[i] != RSASignitureDecrypted[i]) {
			ok = 0;
		}
	}
	if (ok == 1) {
		printf("They are the same! Obviously");
	}
#pragma endregion

#pragma region Close program
	free(key);
	free(RSASigniture);
	fclose(passFile);
	fclose(RSASignFile);
	fclose(PuKeyFile);

	return 0;
#pragma endregion
}