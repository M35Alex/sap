#include <tinycrypt/ccm_mode.h>
#include <tinycrypt/constants.h>
#include <test_utils.h>

#include <string.h>

/*
tinycrypt VS project settings

    - https://github.com/intel/tinycrypt
	- this VS implementation: AES-CCM
		- Add lib source code files into the project
		- Additional Include Directories: path to ---> UseTinyCryptSol\lib\include

*/

#define TC_CCM_MAX_CT_SIZE 50
#define TC_CCM_MAX_PT_SIZE 25
#define NUM_NIST_KEYS 16
#define NONCE_LEN 13
#define HEADER_LEN 8
#define M_LEN8 8
#define M_LEN10 10
#define DATA_BUF_LEN23 23
#define DATA_BUF_LEN24 24
#define DATA_BUF_LEN25 25
#define EXPECTED_BUF_LEN31 31
#define EXPECTED_BUF_LEN32 32
#define EXPECTED_BUF_LEN33 33
#define EXPECTED_BUF_LEN34 34
#define EXPECTED_BUF_LEN35 35

int do_test(const uint8_t* key, uint8_t* nonce,
	size_t nlen, const uint8_t* hdr,
	size_t hlen, const uint8_t* data,
	size_t dlen, const uint8_t* expected,
	size_t elen, const int mlen)
{

	int result = TC_PASS;

	uint8_t ciphertext[TC_CCM_MAX_CT_SIZE];
	uint8_t decrypted[TC_CCM_MAX_PT_SIZE];
	struct tc_ccm_mode_struct c;
	struct tc_aes_key_sched_struct sched;

	tc_aes128_set_encrypt_key(&sched, key);

	result = tc_ccm_config(&c, &sched, nonce, nlen, mlen);
	if (result == 0) {
		TC_ERROR("CCM config failed in %s.\n", __func__);

		result = TC_FAIL;
		goto exitTest1;
	}

	// one single shot
	result = tc_ccm_generation_encryption(ciphertext, TC_CCM_MAX_CT_SIZE, hdr,
		hlen, data, dlen, &c);
	if (result == 0) {
		TC_ERROR("ccm_encrypt failed in %s.\n", __func__);

		result = TC_FAIL;
		goto exitTest1;
	}


	if (memcmp(expected, ciphertext, elen) != 0) {
		TC_ERROR("ccm_encrypt produced wrong ciphertext in %s.\n",
			__func__);
		show_str("\t\tExpected", expected, elen);
		show_str("\t\tComputed", ciphertext, elen);

		result = TC_FAIL;
		goto exitTest1;
	}

	result = tc_ccm_decryption_verification(decrypted, TC_CCM_MAX_PT_SIZE, hdr,
		hlen, ciphertext, dlen + mlen, &c);
	if (result == 0) {
		TC_ERROR("ccm_decrypt failed in %s.\n", __func__);
		show_str("\t\tExpected", data, dlen);
		show_str("\t\tComputed", decrypted, sizeof(decrypted));

		result = TC_FAIL;
		goto exitTest1;
	}

	result = TC_PASS;

exitTest1:
	TC_END_RESULT(result);
	return result;
}

int test_vector_1(void)
{
	int result = TC_PASS;
	/* RFC 3610 test vector #1 */
	const uint8_t key[NUM_NIST_KEYS] = {
		0xc0, 0xc1, 0xc2, 0xc3, 0xc4, 0xc5, 0xc6, 0xc7,
		0xc8, 0xc9, 0xca, 0xcb, 0xcc, 0xcd, 0xce, 0xcf
	};
	uint8_t nonce[NONCE_LEN] = {
		0x00, 0x00, 0x00, 0x03, 0x02, 0x01, 0x00, 0xa0,
		0xa1, 0xa2, 0xa3, 0xa4, 0xa5
	};
	const uint8_t hdr[HEADER_LEN] = {
		0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07
	};
	const uint8_t data[DATA_BUF_LEN23] = {
		0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
		0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17,
		0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e
	};
	const uint8_t expected[EXPECTED_BUF_LEN31] = {
		0x58, 0x8c, 0x97, 0x9a, 0x61, 0xc6, 0x63, 0xd2,
		0xf0, 0x66, 0xd0, 0xc2, 0xc0, 0xf9, 0x89, 0x80,
		0x6d, 0x5f, 0x6b, 0x61, 0xda, 0xc3, 0x84, 0x17,
		0xe8, 0xd1, 0x2c, 0xfd, 0xf9, 0x26, 0xe0
	};
	uint16_t mlen = M_LEN8;

	TC_PRINT("%s: Performing CCM test #1 (RFC 3610 test vector #1):\n",
		__func__);

	result = do_test(key, nonce, sizeof(nonce), hdr, sizeof(hdr),
		data, sizeof(data), expected, sizeof(expected), mlen);

	return result;
}

/*
 * Main task to test CCM
 */
int main(void)
{
	int result = TC_PASS;

	TC_START("Performing CCM tests:");

	result = test_vector_1();
	if (result == TC_FAIL) { /* terminate test */
		TC_ERROR("CCM test #1 (RFC 3610 test vector #1) failed.\n");
	}

	TC_END_RESULT(result);
	TC_END_REPORT(result);

	return result;
}