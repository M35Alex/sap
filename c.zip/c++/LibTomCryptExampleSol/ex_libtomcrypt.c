#include <tomcrypt.h>

/*
libtomcrypt build and VS project setup

	- https://github.com/libtom/libtomcrypt
	- https://github.com/libtom/libtommath (crypto needs BN arithmetics)
	- build libtommath in VS for Windows to get BN lib (tommath.lib)
		- Configuration Type: static library
	- build libtomcrypt + libtommath in VS for Windows to get crypto lib (tomcryptd.lib)
		- Configuration Type: static library
		- Additional Include Directories: src\headers;..\libtommath
	- this implementation setup:
		- Configuration Type: Application
		- Additional Include Directories: path to ---> libtomcrypt\libtomcrypt-develop\src\headers
		- Add Existing Item: path to ---> tomcryptd.lib

*/
int main(void)
{
	
	unsigned char key[16] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x00, 0x00, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05 }; 
	unsigned char IV[16] = { 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01 };
	unsigned char buffer[] = { 0x54, 0x68, 0x69, 0x73, 0x20, 0x69, 0x73, 0x20, 0x74, 0x68, 0x65, 0x20, 0x6e, 0x65, 0x77, 0x20, 
							   0x63, 0x6f, 0x6e, 0x74, 0x65, 0x6e, 0x74, 0x20, 0x6f, 0x66, 0x20, 0x74, 0x68, 0x65, 0x20, 0x66, 
							   0x69, 0x6c, 0x65, 0x2e, 0x74, 0x78, 0x74, 0x00 };
	symmetric_CTR ctr;
	int x, err;

	// symmetric cipher example (AES-CTR) from libtomcrypt documentation
	/* register twofish first */
	if (register_cipher(&twofish_desc) == -1) { // Twofish is a symmetric key block cipher with a block size 
												// of 128 bits and key sizes up to 256 bits
		printf("Error registering cipher.\n");
		return -1;
	}

	/* somehow fill out key and IV */
	/* start up CTR mode */
	if ((err = ctr_start(
		find_cipher("twofish"), /* index of desired cipher */
		IV,						/* the initialization vector */
		key,					/* the secret key */
		16,						/* length of secret key (16 bytes) */
		0,						/* 0 == default # of rounds */
		CTR_COUNTER_LITTLE_ENDIAN, /* Little endian counter */
		&ctr)					/* where to store the CTR state */
		) != CRYPT_OK) {
		printf("ctr_start error: %s\n", error_to_string(err));
		return -1;
	}

	/* somehow fill buffer than encrypt it */
	if ((err = ctr_encrypt(buffer,  /* plaintext */
		buffer,						/* ciphertext */
		sizeof(buffer),				/* length of plaintext pt */
		&ctr)						/* CTR state */
		) != CRYPT_OK) {
		printf("ctr_encrypt error: %s\n", error_to_string(err));
		return -1;
	}

	/* make use of ciphertext... */
	/* now we want to decrypt so let's use ctr_setiv */
	if ((err = ctr_setiv(IV,	/* the initial IV we gave to ctr_start */
		16,						/* the IV is 16 bytes long */
		&ctr)					/* the ctr state we wish to modify */
		) != CRYPT_OK) {
		printf("ctr_setiv error: %s\n", error_to_string(err));
		return -1;
	}

	if ((err = ctr_decrypt(buffer,	/* ciphertext */
		buffer,						/* plaintext */
		sizeof(buffer),				/* length of plaintext */
		&ctr)						/* CTR state */
		) != CRYPT_OK) {
		printf("ctr_decrypt error: %s\n", error_to_string(err));
		return -1;
	}

	/* terminate the stream */
	if ((err = ctr_done(&ctr)) != CRYPT_OK) {
		printf("ctr_done error: %s\n", error_to_string(err));
		return -1;
	}

	/* clear up and return */
	zeromem(key, sizeof(key));
	zeromem(&ctr, sizeof(ctr));
	return 0;
}