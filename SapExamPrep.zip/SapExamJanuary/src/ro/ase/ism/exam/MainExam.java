package ro.ase.ism.exam;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;


class Util{
	public static byte[] getPBKDF(String userPassword, 
			  String algorithm,
			  String salt,
			  int noIterations,
			  int mdSize) throws 
NoSuchAlgorithmException, InvalidKeySpecException 
{
SecretKeyFactory pbkdf = SecretKeyFactory.getInstance(algorithm);
PBEKeySpec pbkdfKeySpec = new PBEKeySpec(userPassword.toCharArray(), salt.getBytes(), noIterations,mdSize);
SecretKey secretKey = pbkdf.generateSecret(pbkdfKeySpec);
return secretKey.getEncoded();
}	
	public static void decrypt(
			String filename, 
			String outputFile, 
			String password, 
			String algorithm,
			byte[] IV) throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
		
		
		//IV the cipher file at the beginning
		
		File inputFile = new File(filename);
		if(!inputFile.exists()) {
			throw new UnsupportedOperationException("Missing file");
		}
		File outFile = new File(outputFile);
		if(!outFile.exists()) {
			outFile.createNewFile();
		}
		
		FileInputStream fis = new FileInputStream(inputFile);
		FileOutputStream fos = new FileOutputStream(outFile);
		
		Cipher cipher = Cipher.getInstance(algorithm + "/CBC/NoPadding");
		SecretKeySpec key = new SecretKeySpec(password.getBytes(), algorithm);
		IvParameterSpec ivSpec = new IvParameterSpec(IV);
		
		cipher.init(Cipher.DECRYPT_MODE, key, ivSpec);
		
		byte[] buffer = new byte[cipher.getBlockSize()];
		int noBytes = 0;
		
		while(true) {
			noBytes = fis.read(buffer);
			if(noBytes == -1) {
				break;
			}
			byte[] cipherBlock = cipher.update(buffer, 0, noBytes);
			fos.write(cipherBlock);
		}
		byte[] lastBlock = cipher.doFinal();
		fos.write(lastBlock);
		
		fis.close();
		fos.close();
	}
	public static KeyStore getkeyStore(String keyStoreFile,
			   String keyStorePass,
			   String keyStoreType) throws 
NoSuchAlgorithmException, CertificateException, IOException, KeyStoreException {
File file = new File(keyStoreFile);
if (!file.exists()) {
throw new UnsupportedOperationException("Missing key store file");
}

FileInputStream fis = new FileInputStream(file);

KeyStore ks = KeyStore.getInstance(keyStoreType);
ks.load(fis,keyStorePass.toCharArray());
fis.close();
return ks;
}
	public static PrivateKey getPrivateKey(String alias, String keyPass, KeyStore ks) throws UnrecoverableKeyException, KeyStoreException, NoSuchAlgorithmException {
		if (ks == null) {
			throw new UnsupportedOperationException("Missing Key Store");
		}
		if (ks.containsAlias(alias)) {
			return (PrivateKey) ks.getKey(alias,keyPass.toCharArray());
		}
		else {
			return null;
		}
		
	}
	public static byte[] signFile(String filename, PrivateKey key) throws IOException, NoSuchAlgorithmException, InvalidKeyException, SignatureException {
		File file = new File(filename);
		if(!file.exists()) {
			throw new FileNotFoundException();
		}
		FileInputStream fis = new FileInputStream(file);
		
		byte[] fileContent = fis.readAllBytes();
		
		fis.close();
		
		Signature signature = Signature.getInstance("SHA256withRSA");
		signature.initSign(key);
		
		signature.update(fileContent);
		return signature.sign();		
	}
	public static  PublicKey getCertificateKey(String certificateFile) throws CertificateException, IOException {
		File file = new File(certificateFile);
		if (!file.exists()) {
			throw new UnsupportedOperationException("********** Missing file **********");
		}
		FileInputStream fis = new FileInputStream(file);
		
		CertificateFactory certFactory =CertificateFactory.getInstance("X.509");
		X509Certificate certificate = (X509Certificate) certFactory.generateCertificate(fis);
		fis.close();
		return certificate.getPublicKey();
		
	}
	public static boolean hasValidSignature(
			String filename, PublicKey key, byte[] signature) throws IOException, NoSuchAlgorithmException, InvalidKeyException, SignatureException {
		
		File file = new File(filename);
		if(!file.exists()) {
			throw new FileNotFoundException();
		}
		
		FileInputStream fis = new FileInputStream(file);	
		byte[] fileContent = fis.readAllBytes();	
		fis.close();
		
		Signature signatureModule = Signature.getInstance("SHA256withRSA");
		signatureModule.initVerify(key);
		
		signatureModule.update(fileContent);
		return signatureModule.verify(signature);
		
	}
	public static String getHexString(byte[] value) {
		StringBuilder result = new StringBuilder();
		result.append("0x");
		for (byte b: value) {
			result.append(String.format("%02x", b).toUpperCase());
		}
		return result.toString();
	}
	public static void encrypt(
			String filename, 
			String cipherFilename, 
			String password, 
			String algorithm,
			byte[] IV) throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
		
		
		//IV is known/generated and placed in the cipher file at the beginning
		
		File inputFile = new File(filename);
		if(!inputFile.exists()) {
			throw new UnsupportedOperationException("Missing file");
		}
		File cipherFile = new File(cipherFilename);
		if(!cipherFile.exists()) {
			cipherFile.createNewFile();
		}
		
		FileInputStream fis = new FileInputStream(inputFile);
		FileOutputStream fos = new FileOutputStream(cipherFile);
		
		Cipher cipher = Cipher.getInstance(algorithm + "/CBC/PKCS5Padding");
		SecretKeySpec key = new SecretKeySpec(password.getBytes(), algorithm);
		IvParameterSpec ivSpec = new IvParameterSpec(IV);
		
		cipher.init(Cipher.ENCRYPT_MODE, key, ivSpec);
		
		byte[] buffer = new byte[cipher.getBlockSize()];
		int noBytes = 0;

		while(true) {
			noBytes = fis.read(buffer);
			if(noBytes == -1) {
				break;
			}
			byte[] cipherBlock = cipher.update(buffer, 0, noBytes);
			fos.write(cipherBlock);
		}
		//get the last ciphertext block
		byte[] lastBlock = cipher.doFinal();
		fos.write(lastBlock);
		
		fis.close();
		fos.close();
	}
}
public class MainExam {
	/* EXAM SAP JANUARY 2024
	public static void main(String[] args) throws IOException, NoSuchAlgorithmException, InvalidKeyException, NoSuchPaddingException, 
	IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException, 
	InvalidKeySpecException, CertificateException, KeyStoreException, UnrecoverableKeyException, SignatureException {
		String hashBase64="u7Q+O1NzmG4aQOvvEIKwpEzJxLedo/tiT7G8VSLUbEU=";
		String password="userfilepass%1#8";
		//IV -> The byte with index 5 from left to right has all bits 1. The others are all 0 
		//IV has the 5th byte from left to right all bits 1
		byte[] IV = new byte[16];
		IV[5] = (byte) 0xFF;
		
		File location = new File("users");
		String absPath = location.getAbsolutePath()+File.separator;
		byte [] content = null;
		byte [] hashed = null;
		String hashToBase64 = null;
		String found = null;
		for (File file: location.listFiles()) {
			FileInputStream fis = new FileInputStream(file);
			content = fis.readAllBytes();
			MessageDigest md = MessageDigest.getInstance("SHA256");
			hashed = md.digest(content);
			hashToBase64 = Base64.getEncoder().encodeToString(hashed);
			if (hashToBase64.equals(hashBase64)) {
				System.out.println("File found: ");
				found = absPath+file.getName();
			}
		}
		System.out.println(found);
		Util.decrypt(found, "decrypted.txt", password,"AES",IV);
		File decrypted = new File("decrypted.txt");
		FileInputStream fis2 = new FileInputStream(decrypted);
		byte[] decryptedPass = fis2.readAllBytes();
		String decryptedPassStr = new String(decryptedPass);
		System.out.println("Password: "+decryptedPassStr);
		fis2.close();
		
		byte[] pbkdf = Util.getPBKDF(decryptedPassStr, "PBKDF2WithHmacSHA1", "ism2021", 150, 160);
		File outPBKDF = new File("outPBKDF.bin");
		if (!outPBKDF.exists()) {
			outPBKDF.createNewFile();
		}
		FileOutputStream fos2 = new FileOutputStream(outPBKDF);
		fos2.write(pbkdf);
		fos2.close();
		
		//keytool.exe -genkey -keyalg RSA -alias ismkey1 -keypass passism1 -storepass passks -keystore ismkeystore.ks -dname "cn=ISM, ou=ISM, o=IT&C Security Master, c=RO"
        //keytool.exe -export -alias ismkey1 -file ISMCertificateX509.cer -keystore ismkeystore.ks -storepass passks
		KeyStore ks = Util.getkeyStore("ismkeystore.ks", "passks","pkcs12");
		PrivateKey privIsm1 = Util.getPrivateKey("ismkey1", "passks", ks);
		byte[] signedFile = Util.signFile("outPBKDF.bin", privIsm1);
		
		File signedPBKDF = new File("signedPBKDV.sign");
		if (!signedPBKDF.exists()) {
			signedPBKDF.createNewFile();
		}
		FileOutputStream fos3 = new FileOutputStream(signedPBKDF);
		fos3.write(signedFile);
		fos3.close();
		
		//CHECK 
		
		PublicKey pubKey = Util.getCertificateKey("ISMCertificateX509.cer");
		if (Util.hasValidSignature("outPBKDF.bin", pubKey, signedFile)) {
			System.out.println("VALID SIGNATURE!!!");
		}
	}
	*/
	public static void main(String[] args) throws IOException, NoSuchAlgorithmException, InvalidKeyException, NoSuchPaddingException, 
	IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException, CertificateException, KeyStoreException, 
	UnrecoverableKeyException, SignatureException {
		//EX1
		File message = new File("msg.txt");
		FileInputStream fis = new FileInputStream(message);
		byte[] messageContent = fis.readAllBytes();
		MessageDigest md = MessageDigest.getInstance("SHA256");
		byte[] sha256 = md.digest(messageContent);
		System.out.println(Util.getHexString(sha256));
		
		//EX2
		byte[] IV = new byte[16];
		IV[5] = (byte) 0xCC;
		String password = "passwordsecurity";
		Util.encrypt("msg.txt", "msgEncrypted.enc", password, "AES", IV);
		
		//EX3
		//keytool.exe -genkey -keyalg RSA -alias ismkey1 -keypass passism1 -storepass passks -keystore ismkeystore.ks -dname "cn=ISM, ou=ISM, o=IT&C Security Master, c=RO"
        //keytool.exe -export -alias ismkey1 -file ISMCertificateX509.cer -keystore ismkeystore.ks -storepass passks
		KeyStore ks = Util.getkeyStore("ismkeystore.ks", "passks","pkcs12");
		PrivateKey privIsm1 = Util.getPrivateKey("ismkey1", "passks", ks);
		byte[] signedFile = Util.signFile("msgEncrypted.enc", privIsm1);
		
		File signedPBKDF = new File("signedMsgEnc.sign");
		if (!signedPBKDF.exists()) {
			signedPBKDF.createNewFile();
		}
		FileOutputStream fos3 = new FileOutputStream(signedPBKDF);
		fos3.write(signedFile);
		fos3.close();
		
		//CHECK 
		
		PublicKey pubKey = Util.getCertificateKey("ISMCertificateX509.cer");
		if (Util.hasValidSignature("msgEncrypted.enc", pubKey, signedFile)) {
			System.out.println("VALID SIGNATURE!!!");
		}
	}
}
