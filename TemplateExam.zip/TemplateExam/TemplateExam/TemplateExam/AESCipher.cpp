#include "AESCipher.h"
void AESCipher::prtErrAndExit(int eVal, char* msg) {
	if (msg != NULL)
		fprintf(stderr, "INFO(evp_crypt): %s\n\n", msg);
	exit(eVal);
}
void AESCipher::EncryptECB(const char* inputfName, const char* outputfName, unsigned char** outBuffer,
	unsigned char* key, int key_size) {
	int outBytes, inBytes, tmpOutBytes;
	int cipherBlockSize, cipherKeyLength, cipherIvLength;
	unsigned char buf2crypt[INBUFSIZE];
	unsigned char outBuf[OUTBUFSIZE];
	EVP_CIPHER_CTX* ctx;
	ctx = EVP_CIPHER_CTX_new();
	EVP_CIPHER_CTX_init(ctx);
	if (key_size == 128) {
		EVP_EncryptInit_ex(ctx, EVP_aes_128_ecb(), NULL, key, NULL);
	}
	if (key_size == 192) {
		EVP_EncryptInit_ex(ctx, EVP_aes_192_ecb(), NULL, key, NULL);
	}
	if (key_size == 256) {
		EVP_EncryptInit_ex(ctx, EVP_aes_256_ecb(), NULL, key, NULL);
	}
	cipherBlockSize = EVP_CIPHER_CTX_block_size(ctx);
	cipherKeyLength = EVP_CIPHER_CTX_key_length(ctx);
	cipherIvLength = EVP_CIPHER_CTX_iv_length(ctx);
	if ((cipherKeyLength > 32) || (cipherIvLength > 16))
		prtErrAndExit(1, (char*)"ERROR: Hardwired key or iv was too short!!\n");

	inBytes = outBytes = 0;
	FILE* fc = NULL;
	errno_t err;
	err = fopen_s(&fc, inputfName, "rb");
	if (err == 0) {
		fseek(fc, 0, SEEK_END);
		int fileLen = ftell(fc);
		fseek(fc, 0, SEEK_SET);
	}
	int read_length = INBUFSIZE;
	while (read_length == INBUFSIZE)
	{
		read_length = fread(buf2crypt, sizeof(char), INBUFSIZE, fc);
		if ((OUTBUFSIZE - ((read_length + cipherBlockSize - 1) + outBytes)) <= 0)
			prtErrAndExit(1, (char*)"ERROR: Buffer was not big enough to hold encrypted data!!\n");
		if (!EVP_EncryptUpdate(ctx, outBuf + outBytes, &tmpOutBytes, buf2crypt, read_length))
			prtErrAndExit(1, (char*)"ERROR: EVP_EncryptUpdate didn't work...\n");
		outBytes += tmpOutBytes;
		inBytes += read_length;
	}
	if ((OUTBUFSIZE - (cipherBlockSize + outBytes)) <= 0)
		prtErrAndExit(1, (char*)"ERROR: Buffer was not big enough to hold encrypted data!!\n");
	if (!EVP_EncryptFinal_ex(ctx, outBuf + outBytes, &tmpOutBytes))
		prtErrAndExit(1, (char*)"ERROR: EVP_EncryptFinal_ex didn't work...\n");
	outBytes += tmpOutBytes;
	EVP_CIPHER_CTX_cleanup(ctx);
	outEncryptedBytes = outBytes;

	if (outputfName == NULL) {
		memcpy(*outBuffer, outBuf, outBytes);
	}
	else {
		FILE* fd = NULL;
		err = fopen_s(&fd, outputfName, "wb+");
		fwrite(outBuf, sizeof(unsigned char), outBytes, fd);
		fclose(fd);
	}
	fclose(fc);
}
void AESCipher::EncryptCBC(const char* inputfName, const char* outputfName, unsigned char** outBuffer,
	unsigned char* key, int key_size, unsigned char* iv) {
	int outBytes, inBytes, tmpOutBytes;
	int cipherBlockSize, cipherKeyLength, cipherIvLength;
	unsigned char buf2crypt[INBUFSIZE];
	unsigned char outBuf[OUTBUFSIZE];
	EVP_CIPHER_CTX* ctx;
	ctx = EVP_CIPHER_CTX_new();
	EVP_CIPHER_CTX_init(ctx);
	if (key_size == 128) {
		EVP_EncryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv);
	}
	if (key_size == 192) {
		EVP_EncryptInit_ex(ctx, EVP_aes_192_cbc(), NULL, key, iv);
	}
	if (key_size == 256) {
		EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv);
	}
	cipherBlockSize = EVP_CIPHER_CTX_block_size(ctx);
	cipherKeyLength = EVP_CIPHER_CTX_key_length(ctx);
	cipherIvLength = EVP_CIPHER_CTX_iv_length(ctx);
	if ((cipherKeyLength > 32) || (cipherIvLength > 16))
		prtErrAndExit(1, (char*)"ERROR: Hardwired key or iv was too short!!\n");

	inBytes = outBytes = 0;
	FILE* fc = NULL;
	errno_t err;
	err = fopen_s(&fc, inputfName, "rb");
	if (err == 0) {
		fseek(fc, 0, SEEK_END);
		int fileLen = ftell(fc);
		fseek(fc, 0, SEEK_SET);
	}
	int read_length = INBUFSIZE;
	while (read_length == INBUFSIZE)
	{
		read_length = fread(buf2crypt, sizeof(char), INBUFSIZE, fc);
		if ((OUTBUFSIZE - ((read_length + cipherBlockSize - 1) + outBytes)) <= 0)
			prtErrAndExit(1, (char*)"ERROR: Buffer was not big enough to hold encrypted data!!\n");
		if (!EVP_EncryptUpdate(ctx, outBuf + outBytes, &tmpOutBytes, buf2crypt, read_length))
			prtErrAndExit(1, (char*)"ERROR: EVP_EncryptUpdate didn't work...\n");
		outBytes += tmpOutBytes;
		inBytes += read_length;
	}
	if ((OUTBUFSIZE - (cipherBlockSize + outBytes)) <= 0)
		prtErrAndExit(1, (char*)"ERROR: Buffer was not big enough to hold encrypted data!!\n");
	if (!EVP_EncryptFinal_ex(ctx, outBuf + outBytes, &tmpOutBytes))
		prtErrAndExit(1, (char*)"ERROR: EVP_EncryptFinal_ex didn't work...\n");
	outBytes += tmpOutBytes;
	EVP_CIPHER_CTX_cleanup(ctx);
	outEncryptedBytes = outBytes;

	if (outputfName == NULL) {
		memcpy(*outBuffer, outBuf, outBytes);
	}
	else {
		FILE* fd = NULL;
		err = fopen_s(&fd, outputfName, "wb+");
		fwrite(outBuf, sizeof(unsigned char), outBytes, fd);
		fclose(fd);
	}
	fclose(fc);
}
void AESCipher::DecryptECB(const char* inputfName, const char* outputfName, unsigned char** outBuffer, unsigned char* key, int key_size)
{
	int outBytes, tmpOutBytes, bytesInBuf;
	int cipherBlockSize, cipherKeyLength, cipherIvLength;
	unsigned char buf2crypt[INBUFSIZE];
	unsigned char outBuf[OUTBUFSIZE];
	EVP_CIPHER_CTX* ctx;
	ctx = EVP_CIPHER_CTX_new();
	EVP_CIPHER_CTX_init(ctx);
	if (key_size == 128) {
		EVP_DecryptInit_ex(ctx, EVP_aes_128_ecb(), NULL, key, NULL);
	}
	if (key_size == 192) {
		EVP_DecryptInit_ex(ctx, EVP_aes_192_ecb(), NULL, key, NULL);
	}
	if (key_size == 256) {
		EVP_DecryptInit_ex(ctx, EVP_aes_256_ecb(), NULL, key, NULL);
	}
	cipherBlockSize = EVP_CIPHER_CTX_block_size(ctx);
	cipherKeyLength = EVP_CIPHER_CTX_key_length(ctx);
	cipherIvLength = EVP_CIPHER_CTX_iv_length(ctx);
	if ((cipherKeyLength > 32) || (cipherIvLength > 16))
		prtErrAndExit(1, (char*)"ERROR: Hardwired key or iv was too short!!\n");

	unsigned int infile_length;
	FILE* fb;
	errno_t err = fopen_s(&fb, inputfName, "rb");
	if (err == 0) {
		fseek(fb, 0, SEEK_END);
		infile_length = ftell(fb);
		fseek(fb, 0, SEEK_SET);
	}

	outBytes = 0; // offset of the 1st byte within outBuf containing the restored plaintext
	int read_length = INBUFSIZE;

	while ((read_length == INBUFSIZE)) {
		read_length = fread(buf2crypt, sizeof(char), INBUFSIZE, fb);
		if ((OUTBUFSIZE - ((read_length + cipherBlockSize - 1) + outBytes)) <= 0)
			prtErrAndExit(1, (char*)"ERROR: Buffer was not big enough to hold decrypted data!!\n");
		if (!EVP_DecryptUpdate(ctx, outBuf + outBytes, &tmpOutBytes, buf2crypt, read_length))
			prtErrAndExit(1, (char*)"ERROR: EVP_DecryptUpdate didn't work...\n");
		outBytes += tmpOutBytes;
	}

	if ((OUTBUFSIZE - (cipherBlockSize + outBytes)) <= 0)
		prtErrAndExit(1, (char*)"ERROR: Buffer was not big enough to hold decrypted data!!\n");
	if (!EVP_DecryptFinal_ex(ctx, outBuf + outBytes, &tmpOutBytes))
		prtErrAndExit(1, (char*)"ERROR: EVP_DecryptFinal_ex didn't work...\n");
	outBytes += tmpOutBytes;

	EVP_CIPHER_CTX_cleanup(ctx);

	outBuf[outBytes] = 0; // put the string terminator right after the last byte of the initial plaintext


	if (outputfName == NULL) {
		memcpy(*outBuffer, outBuf, outBytes);
	}
	else {
		FILE* fd = NULL;
		err = fopen_s(&fd, outputfName, "wb+");
		fwrite(outBuf, sizeof(unsigned char), outBytes, fd);
		fclose(fd);
	}

	fclose(fb);
}
void AESCipher::DecryptCBC(const char* inputfName, const char* outputfName, unsigned char** outBuffer, unsigned char* key, int key_size, unsigned char* iv)
{
	int outBytes, tmpOutBytes, bytesInBuf;
	int cipherBlockSize, cipherKeyLength, cipherIvLength;
	unsigned char buf2crypt[INBUFSIZE];
	unsigned char outBuf[OUTBUFSIZE];
	EVP_CIPHER_CTX* ctx;
	ctx = EVP_CIPHER_CTX_new();
	EVP_CIPHER_CTX_init(ctx);
	if (key_size == 128) {
		EVP_DecryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv);
	}
	if (key_size == 192) {
		EVP_DecryptInit_ex(ctx, EVP_aes_192_cbc(), NULL, key, iv);
	}
	if (key_size == 256) {
		EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv);
	}
	cipherBlockSize = EVP_CIPHER_CTX_block_size(ctx);
	cipherKeyLength = EVP_CIPHER_CTX_key_length(ctx);
	cipherIvLength = EVP_CIPHER_CTX_iv_length(ctx);
	if ((cipherKeyLength > 32) || (cipherIvLength > 16))
		prtErrAndExit(1, (char*)"ERROR: Hardwired key or iv was too short!!\n");

	unsigned int infile_length;
	FILE* fb;
	errno_t err = fopen_s(&fb, inputfName, "rb");
	if (err == 0) {
		fseek(fb, 0, SEEK_END);
		infile_length = ftell(fb);
		fseek(fb, 0, SEEK_SET);
	}

	outBytes = 0; // offset of the 1st byte within outBuf containing the restored plaintext
	int read_length = INBUFSIZE;

	while ((read_length == INBUFSIZE)) {
		read_length = fread(buf2crypt, sizeof(char), INBUFSIZE, fb);
		if ((OUTBUFSIZE - ((read_length + cipherBlockSize - 1) + outBytes)) <= 0)
			prtErrAndExit(1, (char*)"ERROR: Buffer was not big enough to hold decrypted data!!\n");
		if (!EVP_DecryptUpdate(ctx, outBuf + outBytes, &tmpOutBytes, buf2crypt, read_length))
			prtErrAndExit(1, (char*)"ERROR: EVP_DecryptUpdate didn't work...\n");
		outBytes += tmpOutBytes;
	}

	if ((OUTBUFSIZE - (cipherBlockSize + outBytes)) <= 0)
		prtErrAndExit(1, (char*)"ERROR: Buffer was not big enough to hold decrypted data!!\n");
	if (!EVP_DecryptFinal_ex(ctx, outBuf + outBytes, &tmpOutBytes))
		prtErrAndExit(1, (char*)"ERROR: EVP_DecryptFinal_ex didn't work...\n");
	outBytes += tmpOutBytes;

	EVP_CIPHER_CTX_cleanup(ctx);

	outBuf[outBytes] = 0; // put the string terminator right after the last byte of the initial plaintext


	if (outputfName == NULL) {
		memcpy(*outBuffer, outBuf, outBytes);
	}
	else {
		FILE* fd = NULL;
		err = fopen_s(&fd, outputfName, "wb+");
		fwrite(outBuf, sizeof(unsigned char), outBytes, fd);
		fclose(fd);
	}

	fclose(fb);
}

void AESCipher::EncryptBufferCBC(unsigned char* plaintext, int sizeOfPlaintext,unsigned char* key, unsigned char* iv, unsigned char** outBuffer)
{
}
