#include <string.h>
#include <malloc.h>
#include <openssl/md5.h>
#include <openssl/sha.h>
class MessageDigest
{	
public:
	MessageDigest(){}
	static void getHashToFile(const char* inputfName, const char* outputfName, const char* algorithm);
	static void getHashToBuf(const char* inputfName, unsigned char** outputBuf, const char* algorithm);
	static void printHash(unsigned char* hash, const char* algorithm);
};

