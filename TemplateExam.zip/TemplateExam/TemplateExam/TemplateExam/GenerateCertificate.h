#include <stdio.h>
#include <malloc.h>
#include <memory.h>
#include <openssl/x509.h>
#include <openssl/bio.h>
#include <openssl/rsa.h>
#include <openssl/evp.h>
class GenerateCertificate
{
public:
	static void generate(const char* cerFileName, const char* privKeyfName);
};

