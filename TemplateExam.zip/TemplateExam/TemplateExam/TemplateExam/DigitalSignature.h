#pragma once
class DigitalSignature
{public:
	static void create(const char* inputfName, const char* privKeyfName, const char* signaturefName, const char* md_algorithm);
	static void verify(const char* inputfName, const char* pubKeyfName, const char* signaturefName, const char* md_algorithm);
};

