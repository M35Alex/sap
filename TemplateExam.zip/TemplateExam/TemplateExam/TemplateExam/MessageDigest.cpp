#include "MessageDigest.h"
#include <stdio.h>
#include <openssl/md5.h>
#include <openssl/sha.h>
#define MESSAGE_CHUNK 256

void MessageDigest::getHashToFile(const char* inputfName, const char* outputfName, const char* algorithm) {
	if (!strcmp(algorithm, "MD5")) {
		FILE* f = NULL;
		errno_t err;
		MD5_CTX ctx;
		unsigned char finalDigest[MD5_DIGEST_LENGTH];
		MD5_Init(&ctx);
		unsigned char* fileBuffer = NULL;

		err = fopen_s(&f, inputfName, "rb");
		if (err == 0) {
			fseek(f, 0, SEEK_END);
			int fileLen = ftell(f);
			fseek(f, 0, SEEK_SET);

			unsigned char* tmpBuffer_Chunk = (unsigned char*)malloc(MESSAGE_CHUNK);

			int read_length = MESSAGE_CHUNK;
			while (read_length == MESSAGE_CHUNK) {
				read_length = fread(tmpBuffer_Chunk, 1, MESSAGE_CHUNK, f);
				MD5_Update(&ctx, tmpBuffer_Chunk, read_length);
			}
			MD5_Final(finalDigest, &ctx);
			fclose(f);
		}
		else {
			printf("\n Input file doesn't exist! \n\n");
			return;
		}
		err = fopen_s(&f, outputfName, "wb+");
		if (err == 0) {
			fwrite(finalDigest, sizeof(unsigned char), MD5_DIGEST_LENGTH, f);
			fclose(f);
		}
		else {
			printf("\n Output file doesn't exist! \n\n");
		}

	}
	if (!strcmp(algorithm, "SHA1")) {
		FILE* f = NULL;
		errno_t err;
		SHA_CTX ctx;

		unsigned char finalDigest[SHA_DIGEST_LENGTH];
		SHA1_Init(&ctx);

		unsigned char* fileBuffer = NULL;

		err = fopen_s(&f, inputfName, "rb");
		if (err == 0) {
			fseek(f, 0, SEEK_END);
			int fileLen = ftell(f);
			fseek(f, 0, SEEK_SET);

			fileBuffer = (unsigned char*)malloc(fileLen);
			fread(fileBuffer, fileLen, 1, f);
			unsigned char* tmpBuffer = fileBuffer;

			while (fileLen > 0) {
				if (fileLen > MESSAGE_CHUNK) {
					SHA1_Update(&ctx, tmpBuffer, MESSAGE_CHUNK);
				}
				else {
					SHA1_Update(&ctx, tmpBuffer, fileLen);
				}
				fileLen -= MESSAGE_CHUNK;
				tmpBuffer += MESSAGE_CHUNK;
			}

			SHA1_Final(finalDigest, &ctx);
			fclose(f);
		}
		else {
			printf("\n Input file doesn't exist! \n\n");
			return;
		}
		err = fopen_s(&f, outputfName, "wb+");
		if (err == 0) {
			fwrite(finalDigest, sizeof(unsigned char), SHA_DIGEST_LENGTH, f);
			fclose(f);
		}
		else {
			printf("\n Output file doesn't exist! \n\n");
			return;
		}
	}
	if (!strcmp(algorithm, "SHA224")) {
		FILE* f = NULL;
		errno_t err;
		SHA256_CTX ctx;

		unsigned char finalDigest[SHA224_DIGEST_LENGTH];
		SHA224_Init(&ctx);

		unsigned char* fileBuffer = NULL;

		err = fopen_s(&f, inputfName, "rb");
		if (err == 0) {
			fseek(f, 0, SEEK_END);
			int fileLen = ftell(f);
			fseek(f, 0, SEEK_SET);

			fileBuffer = (unsigned char*)malloc(fileLen);
			fread(fileBuffer, fileLen, 1, f);
			unsigned char* tmpBuffer = fileBuffer;

			while (fileLen > 0) {
				if (fileLen > MESSAGE_CHUNK) {
					SHA224_Update(&ctx, tmpBuffer, MESSAGE_CHUNK);
				}
				else {
					SHA224_Update(&ctx, tmpBuffer, fileLen);
				}
				fileLen -= MESSAGE_CHUNK;
				tmpBuffer += MESSAGE_CHUNK;
			}

			SHA224_Final(finalDigest, &ctx);
			fclose(f);
		}
		else {
			printf("\n Input file doesn't exist! \n\n");
			return;
		}
		err = fopen_s(&f, outputfName, "wb+");
		if (err == 0) {
			fwrite(finalDigest, sizeof(unsigned char), SHA224_DIGEST_LENGTH, f);
			fclose(f);
		}
		else {
			printf("\n Output file doesn't exist! \n\n");
			return;
		}
	}
	if (!strcmp(algorithm, "SHA256")) {
		FILE* f = NULL;
		errno_t err;
		SHA256_CTX ctx;

		unsigned char finalDigest[SHA256_DIGEST_LENGTH];
		SHA256_Init(&ctx);

		unsigned char* fileBuffer = NULL;

		err = fopen_s(&f, inputfName, "rb");
		if (err == 0) {
			fseek(f, 0, SEEK_END);
			int fileLen = ftell(f);
			fseek(f, 0, SEEK_SET);

			fileBuffer = (unsigned char*)malloc(fileLen);
			fread(fileBuffer, fileLen, 1, f);
			unsigned char* tmpBuffer = fileBuffer;

			while (fileLen > 0) {
				if (fileLen > MESSAGE_CHUNK) {
					SHA256_Update(&ctx, tmpBuffer, MESSAGE_CHUNK);
				}
				else {
					SHA256_Update(&ctx, tmpBuffer, fileLen);
				}
				fileLen -= MESSAGE_CHUNK;
				tmpBuffer += MESSAGE_CHUNK;
			}

			SHA256_Final(finalDigest, &ctx);
			fclose(f);
		}
		else {
			printf("\n Input file doesn't exist! \n\n");
			return;
		}
		err = fopen_s(&f, outputfName, "wb+");
		if (err == 0) {
			fwrite(finalDigest, sizeof(unsigned char), SHA256_DIGEST_LENGTH, f);
			fclose(f);
		}
		else {
			printf("\n Output file doesn't exist! \n\n");
			return;
		}
	}
	if (!strcmp(algorithm, "SHA384")) {
		FILE* f = NULL;
		errno_t err;
		SHA512_CTX ctx;

		unsigned char finalDigest[SHA384_DIGEST_LENGTH];
		SHA384_Init(&ctx);

		unsigned char* fileBuffer = NULL;

		err = fopen_s(&f, inputfName, "rb");
		if (err == 0) {
			fseek(f, 0, SEEK_END);
			int fileLen = ftell(f);
			fseek(f, 0, SEEK_SET);

			fileBuffer = (unsigned char*)malloc(fileLen);
			fread(fileBuffer, fileLen, 1, f);
			unsigned char* tmpBuffer = fileBuffer;

			while (fileLen > 0) {
				if (fileLen > MESSAGE_CHUNK) {
					SHA384_Update(&ctx, tmpBuffer, MESSAGE_CHUNK);
				}
				else {
					SHA384_Update(&ctx, tmpBuffer, fileLen);
				}
				fileLen -= MESSAGE_CHUNK;
				tmpBuffer += MESSAGE_CHUNK;
			}

			SHA384_Final(finalDigest, &ctx);
			fclose(f);
		}
		else {
			printf("\n Input file doesn't exist! \n\n");
			return;
		}
		err = fopen_s(&f, outputfName, "wb+");
		if (err == 0) {
			fwrite(finalDigest, sizeof(unsigned char), SHA384_DIGEST_LENGTH, f);
			fclose(f);
		}
		else {
			printf("\n Output file doesn't exist! \n\n");
			return;
		}
	}
	if (!strcmp(algorithm, "SHA512")) {
		FILE* f = NULL;
		errno_t err;
		SHA512_CTX ctx;

		unsigned char finalDigest[SHA512_DIGEST_LENGTH];
		SHA512_Init(&ctx);

		unsigned char* fileBuffer = NULL;

		err = fopen_s(&f, inputfName, "rb");
		if (err == 0) {
			fseek(f, 0, SEEK_END);
			int fileLen = ftell(f);
			fseek(f, 0, SEEK_SET);

			fileBuffer = (unsigned char*)malloc(fileLen);
			fread(fileBuffer, fileLen, 1, f);
			unsigned char* tmpBuffer = fileBuffer;

			while (fileLen > 0) {
				if (fileLen > MESSAGE_CHUNK) {
					SHA512_Update(&ctx, tmpBuffer, MESSAGE_CHUNK);
				}
				else {
					SHA512_Update(&ctx, tmpBuffer, fileLen);
				}
				fileLen -= MESSAGE_CHUNK;
				tmpBuffer += MESSAGE_CHUNK;
			}

			SHA512_Final(finalDigest, &ctx);
			fclose(f);
		}
		else {
			printf("\n Input file doesn't exist! \n\n");
			return;
		}
		err = fopen_s(&f, outputfName, "wb+");
		if (err == 0) {
			fwrite(finalDigest, sizeof(unsigned char), SHA512_DIGEST_LENGTH, f);
			fclose(f);
		}
		else {
			printf("\n Output file doesn't exist! \n\n");
			return;
		}
	}
}

void MessageDigest::getHashToBuf(const char* inputfName, unsigned char** outputBuf, const char* algorithm){
	if (!strcmp(algorithm, "MD5")) {
		FILE* f = NULL;
		errno_t err;
		MD5_CTX ctx;
		unsigned char finalDigest[MD5_DIGEST_LENGTH];
		MD5_Init(&ctx);
		unsigned char* fileBuffer = NULL;

		err = fopen_s(&f, inputfName, "rb");
		if (err == 0) {
			fseek(f, 0, SEEK_END);
			int fileLen = ftell(f);
			fseek(f, 0, SEEK_SET);

			unsigned char* tmpBuffer_Chunk = (unsigned char*)malloc(MESSAGE_CHUNK);

			int read_length = MESSAGE_CHUNK;
			while (read_length == MESSAGE_CHUNK) {
				read_length = fread(tmpBuffer_Chunk, 1, MESSAGE_CHUNK, f);
				MD5_Update(&ctx, tmpBuffer_Chunk, read_length);
			}
			MD5_Final(finalDigest, &ctx);
			fclose(f);
		}
		else {
			printf("\n Input file doesn't exist! \n\n");
			return;
		}
		memcpy(*outputBuf, finalDigest, MD5_DIGEST_LENGTH);
	}
	if (!strcmp(algorithm, "SHA1")) {
		FILE* f = NULL;
		errno_t err;
		SHA_CTX ctx;

		unsigned char finalDigest[SHA_DIGEST_LENGTH];
		SHA1_Init(&ctx);

		unsigned char* fileBuffer = NULL;

		err = fopen_s(&f, inputfName, "rb");
		if (err == 0) {
			fseek(f, 0, SEEK_END);
			int fileLen = ftell(f);
			fseek(f, 0, SEEK_SET);

			fileBuffer = (unsigned char*)malloc(fileLen);
			fread(fileBuffer, fileLen, 1, f);
			unsigned char* tmpBuffer = fileBuffer;

			while (fileLen > 0) {
				if (fileLen > MESSAGE_CHUNK) {
					SHA1_Update(&ctx, tmpBuffer, MESSAGE_CHUNK);
				}
				else {
					SHA1_Update(&ctx, tmpBuffer, fileLen);
				}
				fileLen -= MESSAGE_CHUNK;
				tmpBuffer += MESSAGE_CHUNK;
			}

			SHA1_Final(finalDigest, &ctx);
			fclose(f);
		}
		else {
			printf("\n Input file doesn't exist! \n\n");
			return;
		}
		memcpy(*outputBuf, finalDigest, SHA_DIGEST_LENGTH);

	}
	if (!strcmp(algorithm, "SHA224")) {
		FILE* f = NULL;
		errno_t err;
		SHA256_CTX ctx;

		unsigned char finalDigest[SHA224_DIGEST_LENGTH];
		SHA224_Init(&ctx);

		unsigned char* fileBuffer = NULL;

		err = fopen_s(&f, inputfName, "rb");
		if (err == 0) {
			fseek(f, 0, SEEK_END);
			int fileLen = ftell(f);
			fseek(f, 0, SEEK_SET);

			fileBuffer = (unsigned char*)malloc(fileLen);
			fread(fileBuffer, fileLen, 1, f);
			unsigned char* tmpBuffer = fileBuffer;

			while (fileLen > 0) {
				if (fileLen > MESSAGE_CHUNK) {
					SHA224_Update(&ctx, tmpBuffer, MESSAGE_CHUNK);
				}
				else {
					SHA224_Update(&ctx, tmpBuffer, fileLen);
				}
				fileLen -= MESSAGE_CHUNK;
				tmpBuffer += MESSAGE_CHUNK;
			}

			SHA224_Final(finalDigest, &ctx);
			fclose(f);
		}
		else {
			printf("\n Input file doesn't exist! \n\n");
			return;
		}
		memcpy(*outputBuf, finalDigest, SHA224_DIGEST_LENGTH);

	}
	if (!strcmp(algorithm, "SHA256")) {
		FILE* f = NULL;
		errno_t err;
		SHA256_CTX ctx;

		unsigned char finalDigest[SHA256_DIGEST_LENGTH];
		SHA256_Init(&ctx);

		unsigned char* fileBuffer = NULL;

		err = fopen_s(&f, inputfName, "rb");
		if (err == 0) {
			fseek(f, 0, SEEK_END);
			int fileLen = ftell(f);
			fseek(f, 0, SEEK_SET);

			fileBuffer = (unsigned char*)malloc(fileLen);
			fread(fileBuffer, fileLen, 1, f);
			unsigned char* tmpBuffer = fileBuffer;

			while (fileLen > 0) {
				if (fileLen > MESSAGE_CHUNK) {
					SHA256_Update(&ctx, tmpBuffer, MESSAGE_CHUNK);
				}
				else {
					SHA256_Update(&ctx, tmpBuffer, fileLen);
				}
				fileLen -= MESSAGE_CHUNK;
				tmpBuffer += MESSAGE_CHUNK;
			}

			SHA256_Final(finalDigest, &ctx);
			fclose(f);
		}
		else {
			printf("\n Input file doesn't exist! \n\n");
			return;
		}
		memcpy(*outputBuf, finalDigest, SHA256_DIGEST_LENGTH);

	}
	if (!strcmp(algorithm, "SHA384")) {
		FILE* f = NULL;
		errno_t err;
		SHA512_CTX ctx;

		unsigned char finalDigest[SHA384_DIGEST_LENGTH];
		SHA384_Init(&ctx);

		unsigned char* fileBuffer = NULL;

		err = fopen_s(&f, inputfName, "rb");
		if (err == 0) {
			fseek(f, 0, SEEK_END);
			int fileLen = ftell(f);
			fseek(f, 0, SEEK_SET);

			fileBuffer = (unsigned char*)malloc(fileLen);
			fread(fileBuffer, fileLen, 1, f);
			unsigned char* tmpBuffer = fileBuffer;

			while (fileLen > 0) {
				if (fileLen > MESSAGE_CHUNK) {
					SHA384_Update(&ctx, tmpBuffer, MESSAGE_CHUNK);
				}
				else {
					SHA384_Update(&ctx, tmpBuffer, fileLen);
				}
				fileLen -= MESSAGE_CHUNK;
				tmpBuffer += MESSAGE_CHUNK;
			}

			SHA384_Final(finalDigest, &ctx);
			fclose(f);
		}
		else {
			printf("\n Input file doesn't exist! \n\n");
			return;
		}
		memcpy(*outputBuf, finalDigest, SHA384_DIGEST_LENGTH);

	}
	if (!strcmp(algorithm, "SHA512")) {
		FILE* f = NULL;
		errno_t err;
		SHA512_CTX ctx;

		unsigned char finalDigest[SHA512_DIGEST_LENGTH];
		SHA512_Init(&ctx);

		unsigned char* fileBuffer = NULL;

		err = fopen_s(&f, inputfName, "rb");
		if (err == 0) {
			fseek(f, 0, SEEK_END);
			int fileLen = ftell(f);
			fseek(f, 0, SEEK_SET);

			fileBuffer = (unsigned char*)malloc(fileLen);
			fread(fileBuffer, fileLen, 1, f);
			unsigned char* tmpBuffer = fileBuffer;

			while (fileLen > 0) {
				if (fileLen > MESSAGE_CHUNK) {
					SHA512_Update(&ctx, tmpBuffer, MESSAGE_CHUNK);
				}
				else {
					SHA512_Update(&ctx, tmpBuffer, fileLen);
				}
				fileLen -= MESSAGE_CHUNK;
				tmpBuffer += MESSAGE_CHUNK;
			}

			SHA512_Final(finalDigest, &ctx);
			fclose(f);
		}
		else {
			printf("\n Input file doesn't exist! \n\n");
			return;
		}
		memcpy(*outputBuf, finalDigest, SHA512_DIGEST_LENGTH);

	}
}

void MessageDigest::printHash(unsigned char* hash, const char* algorithm){
	if (!strcmp(algorithm, "MD5")) {
		printf("MD5: ");
		for (int i = 0; i < MD5_DIGEST_LENGTH; i++) {
			printf("%02x", hash[i]);
		}
	}
	if (!strcmp(algorithm, "SHA1")) {
		printf("SHA1: ");
		for (int i = 0; i < SHA_DIGEST_LENGTH; i++) {
			printf("%02x", hash[i]);
		}
	}
	if (!strcmp(algorithm, "SHA224")) {
		printf("SHA224: ");
		for (int i = 0; i < SHA224_DIGEST_LENGTH; i++) {
			printf("%02x", hash[i]);
		}
	}
	if (!strcmp(algorithm, "SHA256")) {
		printf("SHA256: ");
		for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
			printf("%02x", hash[i]);
		}
	}
	if (!strcmp(algorithm, "SHA384")) {
		printf("SHA384: ");
		for (int i = 0; i < SHA384_DIGEST_LENGTH; i++) {
			printf("%02x", hash[i]);
		}
	}
	if (!strcmp(algorithm, "SHA512")) {
		printf("SHA512: ");
		for (int i = 0; i < SHA512_DIGEST_LENGTH; i++) {
			printf("%02x", hash[i]);
		}
	}

}
