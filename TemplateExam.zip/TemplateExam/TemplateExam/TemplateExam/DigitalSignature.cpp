#include "DigitalSignature.h"
#include "MessageDigest.h"
#include <stdio.h>
#include <malloc.h>
#include <memory.h>
#include <openssl/pem.h>
#include <openssl/rsa.h>
#include <openssl/sha.h>

void DigitalSignature::create(const char* inputfName, const char *privKeyfName,const char* signaturefName, const char* md_algorithm)
{
	FILE* fsrc = NULL;
	FILE* fdst = NULL;
	errno_t err;
	unsigned char finalDigest[SHA256_DIGEST_LENGTH];
	unsigned char* digest = (unsigned char*)malloc(SHA256_DIGEST_LENGTH);
	MessageDigest::getHashToBuf(inputfName, &digest, "SHA256");
	memcpy(finalDigest, digest, SHA256_DIGEST_LENGTH);
	free(digest);

	printf("SHA(256) = ");
	for (int i = 0; i < SHA256_DIGEST_LENGTH; i++)
		printf("%02X ", finalDigest[i]);
	printf("\n");

	err = fopen_s(&fdst, signaturefName, "wb");

	RSA* apriv;
	FILE* f;

	unsigned char* buf = NULL;
	unsigned char* e_data = NULL;
	unsigned char* last_data = NULL;

	//unsigned char finalDigest[] = {
	//	0x99, 0x92, 0x62, 0x83, 0xe5, 0xa5, 0x49, 0x80,
	//	0xf1, 0x28, 0xd8, 0x04, 0x24, 0x47, 0xef, 0x87,
	//	0xae, 0xb1, 0x39, 0xd5, 0x65, 0xd4, 0x90, 0xcd,
	//	0xbd, 0x65, 0x1f, 0xdf, 0xec, 0x67, 0xfc, 0xfc
	//};

	//unsigned char finalDigest[] = {  // MD5  
	//	0x06, 0x48, 0x2B, 0x1F, 0x3E, 0xD9, 0x61, 0x44, 
	//	0xFC, 0x9F, 0x83, 0x57, 0x1E, 0xCE, 0x8D, 0x39
	//};

	apriv = RSA_new();

	f = fopen(privKeyfName, "r");
	apriv = PEM_read_RSAPrivateKey(f, NULL, NULL, NULL);
	fclose(f);

	buf = (unsigned char*)malloc(sizeof(finalDigest));
	memcpy(buf, finalDigest, sizeof(finalDigest));

	// e_data buffer to store the digital signature; there is one single RSA block for the signature
	e_data = (unsigned char*)malloc(RSA_size(apriv)); //RSA_size => 1024 bits/128 bytes

	RSA_private_encrypt(sizeof(finalDigest), buf, e_data, apriv, RSA_PKCS1_PADDING); // encryption for e-signature made by using the PRIVATE key

	printf("Signature(RSA) = ");
	printf("\n");
	for (int i = 0; i < RSA_size(apriv); i++)
	{
		printf("%02X ", e_data[i]);
	}
	printf("\n");

	// write the content of e_data with digital signature into a file
	fwrite(e_data, RSA_size(apriv), 1, fdst); // write the e-sign into the file

	fclose(fdst);

	free(e_data);
	free(buf);

	RSA_free(apriv);
}
void DigitalSignature::verify(const char* inputfName, const char* pubKeyfName, const char* signaturefName, const char* md_algorithm) {
	FILE* fsrc = NULL;
	FILE* fsig = NULL;
	errno_t err;;

	// Step #1 Compute the message digest for the restored plaintext
	unsigned char finalDigest[SHA256_DIGEST_LENGTH];
	unsigned char *digest = (unsigned char*)malloc(SHA256_DIGEST_LENGTH);
	MessageDigest::getHashToBuf(inputfName, &digest, "SHA256");
	memcpy(finalDigest, digest, SHA256_DIGEST_LENGTH);
	free(digest);

	// Step #2 Decrypt the content of e-signature and compare it with the message digest resulted from Stage #1
	err = fopen_s(&fsig, signaturefName, "rb");

	RSA* apub;
	FILE* f;
	unsigned char* buf = NULL;
	unsigned char* last_data = NULL;

	apub = RSA_new();

	f = fopen(pubKeyfName, "r");
	apub = PEM_read_RSAPublicKey(f, NULL, NULL, NULL);
	fclose(f);

	buf = (unsigned char*)malloc(RSA_size(apub));
	// there is one single ciphertext block
	fread(buf, RSA_size(apub), 1, fsig);

	last_data = (unsigned char*)malloc(SHA256_DIGEST_LENGTH); // 32 is the length of the SHA-256 algo result

	// decryption of the e-sign performed with the RSA public key
	RSA_public_decrypt(RSA_size(apub), buf, last_data, apub, RSA_PKCS1_PADDING);

	fclose(fsig);

	printf("\n SHA-256 content decrypted from digital signature file: ");
	for (int i = 0; i < SHA256_DIGEST_LENGTH; i++)
		printf("%02X ", last_data[i]);
	printf("\n");

	if (memcmp(last_data, finalDigest, SHA256_DIGEST_LENGTH) == 0) // the two message digests are compared: computed vs. decrypted from e-sign
		printf("\n Signature OK!\n");
	else
		printf("\n Signature does not validate the message!\n");

	free(last_data);
	free(buf);

	RSA_free(apub);


}
