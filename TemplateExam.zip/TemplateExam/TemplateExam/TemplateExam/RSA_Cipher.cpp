#include "RSA_Cipher.h"
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <openssl/applink.c>
#include <openssl/pem.h>
#include <openssl/rsa.h>

void RSA_Cipher::GenerateRSAKeyPair(int keySize, const char* privKeyfName, const char* pubKeyfName)
{
	RSA * rsaKP = NULL;
	rsaKP = RSA_new(); // allocate storage for RSA openssl structure
	rsaKP = RSA_generate_key(keySize, 65535, NULL, NULL); // generate RSA key pair on 1k bits

	RSA_check_key(rsaKP); // validate the previous generated key pair

	FILE* fpPriv = NULL;
	fopen_s(&fpPriv, privKeyfName, "w+"); // create file to store the RSA private key (in PEM format)
	PEM_write_RSAPrivateKey(fpPriv, rsaKP, NULL, NULL, 0, 0, NULL); // get the private key from RSA openssl structure and 
	// store it in the file in PEM format
	fclose(fpPriv);

	FILE* fpPub = NULL;
	fopen_s(&fpPub, pubKeyfName, "w+"); // create file to store the RSA public key
	PEM_write_RSAPublicKey(fpPub, rsaKP); // get the public key fro RSA openssl structure and
	// store it in the file in PEM format
	fclose(fpPub);

	RSA_free(rsaKP); // release the storage for RSA openssl structure

	printf("\n The RSA key pair generated! \n");
}
void RSA_Cipher::EncryptRSA(const char* infName,const char* keyfName, unsigned char* outBuffer, const char* outfName)
{
	FILE* fsrc = NULL;
	FILE* fdst = NULL;
	errno_t err;
	err = fopen_s(&fsrc, infName, "rb");
	fseek(fsrc, 0, SEEK_END);
	int fileLen = ftell(fsrc);
	fseek(fsrc, 0, SEEK_SET);

	RSA* apub;
	apub = RSA_new();
	FILE* f;
	unsigned char* e_data = NULL;
	unsigned char* last_data = NULL;
	f = fopen(keyfName, "r");
	apub = PEM_read_RSAPublicKey(f, NULL, NULL, NULL); // load RSA public key components into RSA structure
	fclose(f);
	err = fopen_s(&fdst, outfName, "wb");
	unsigned char* fsrcbuf = (unsigned char*)malloc(RSA_size(apub) + 1); // allocate buffer to store plaintext chunks, eack chunck has 128 bytes == RSA key length
	fsrcbuf[RSA_size(apub)] = 0x00;
	e_data = (unsigned char*)malloc(RSA_size(apub)); // allocate buffer to store the ciphertext on 128 bytes same like the RSA key length
	if (fileLen != RSA_size(apub)) {
		while (fread_s(fsrcbuf, RSA_size(apub), sizeof(unsigned char), RSA_size(apub), fsrc) == RSA_size(apub)) {
			// encryption block-by-block, each block has RSA key length (1024 bits)
			// because the block is filled in fully, then there is no padding to be used here
			RSA_public_encrypt(RSA_size(apub), fsrcbuf, e_data, apub, RSA_NO_PADDING); // if the plaintext is matching the number of blocks, 
			// the last full block will be encrypted without padding
			fwrite(e_data, sizeof(unsigned char), RSA_size(apub), fdst);
		}
	}
	else {
		fread_s(fsrcbuf, RSA_size(apub), sizeof(unsigned char), RSA_size(apub), fsrc);
	}

	if (fileLen % RSA_size(apub)) // if there are additional bytes to be encrypted
	{
		RSA_public_encrypt(fileLen % RSA_size(apub), fsrcbuf, e_data, apub, RSA_PKCS1_PADDING); // encryption of the last block with padding because it couls be a partial block (less 1024 bits)
		fwrite(e_data, sizeof(unsigned char), RSA_size(apub), fdst);
	}
	RSA_free(apub);
	fclose(fdst);
	fclose(fsrc);

}
void RSA_Cipher::DecryptRSA(const char* infName, const char* keyfName, unsigned char* outBuffer, const char* outfName){
	FILE* fsrc = NULL;
	FILE* fdst = NULL;
	errno_t err;
	RSA* apriv;
	apriv = RSA_new();
	FILE* f;

	unsigned char* e_data = NULL;
	unsigned char* last_data = NULL;
	f = fopen(keyfName, "r");
	apriv = PEM_read_RSAPrivateKey(f, NULL, NULL, NULL); // load RSA private key components into RSA openssl structure
	fclose(f);
	e_data = (unsigned char*)malloc(RSA_size(apriv)); // buffer to store the inpur ciphertext block with 128 bytes 
	last_data = (unsigned char*)malloc(RSA_size(apriv));
	
	err = fopen_s(&fsrc, infName, "rb");
	fseek(fsrc, 0, SEEK_END);
	int fileLen2 = ftell(fsrc);
	fseek(fsrc, 0, SEEK_SET);

	int maxChunks = fileLen2 / RSA_size(apriv); // number of ciphertext blocks
	int currentChunk = 1;

	err = fopen_s(&fdst, outfName, "wb");
	int haha = RSA_size(apriv);
	if (fileLen2 != RSA_size(apriv)) {
		while (fread_s(e_data, RSA_size(apriv), sizeof(unsigned char), RSA_size(apriv), fsrc) == RSA_size(apriv)) {
			if (currentChunk != maxChunks) { // 1 to (maxChunks - 1) are considered here because no padding
				// decryption done block-by-block; each block must have 1024 bits as length
				// because each block is filled in fully, there is no padding to be added here
				RSA_private_decrypt(RSA_size(apriv), e_data, last_data, apriv, RSA_NO_PADDING);
				fwrite(last_data, sizeof(unsigned char), RSA_size(apriv), fdst);
				currentChunk++;
			}
		}
	}
	else {
		fread_s(e_data, RSA_size(apriv), sizeof(unsigned char), RSA_size(apriv), fsrc);
	}


	if (fileLen2 % RSA_size(apriv))
	{
		// could be a partial block; the padding must be used to meet the length of RSA key
		RSA_private_decrypt(RSA_size(apriv), e_data, last_data, apriv, RSA_PKCS1_PADDING);
		fwrite(last_data, sizeof(unsigned char), fileLen2 % RSA_size(apriv), fdst);
		//fwrite(last_data, sizeof(unsigned char), RSA_size(apub), frst); // write the restored/decrypted block together with the padding (PKCS1)
	}
	else
	{
		// the last block to decrypted is a full block in plaintext; no padding required for decryption
		RSA_private_decrypt(RSA_size(apriv), e_data, last_data, apriv, RSA_NO_PADDING);
		fwrite(last_data, sizeof(unsigned char), RSA_size(apriv), fdst);
	}

	RSA_free(apriv);
	fclose(fdst);
	fclose(fsrc);
}
void RSA_Cipher::PrivEncryptRSA_AES_KEY(unsigned char* aes_key, int aes_key_size,const char* privKeyfName, const char* outfName) {
	FILE* fdst;
	RSA* apriv;
	FILE* f;

	unsigned char* buf = NULL;
	unsigned char* e_data = NULL;
	unsigned char* last_data = NULL;
	apriv = RSA_new();

	f = fopen(privKeyfName, "r");
	apriv = PEM_read_RSAPrivateKey(f, NULL, NULL, NULL);
	fclose(f);

	buf = (unsigned char*)malloc(aes_key_size);
	memcpy(buf, aes_key, aes_key_size);

	// e_data buffer to store the digital signature; there is one single RSA block for the signature
	e_data = (unsigned char*)malloc(RSA_size(apriv)); //RSA_size => 1024 bits/128 bytes

	RSA_private_encrypt(aes_key_size, buf, e_data, apriv, RSA_PKCS1_PADDING); // encryption for e-signature made by using the PRIVATE key

	printf("Encrypted AES key = ");
	printf("\n");
	for (int i = 0; i < RSA_size(apriv); i++)
	{
		printf("%02X ", e_data[i]);
	}
	printf("\n");

	errno_t err = fopen_s(&fdst, outfName, "wb");
	fwrite(e_data, RSA_size(apriv), 1, fdst);
	free(buf);
	fclose(fdst);
}

void RSA_Cipher::PubDecryptRSA_AES_KEY(const char* encryptedAESfName, const char* pubKeyfName, unsigned char** outBuffer)
{
	FILE* fdst;
	RSA* apub;
	FILE* f;

	unsigned char* buf = NULL;
	unsigned char* last_data = NULL;
	apub = RSA_new();
	f = fopen(pubKeyfName, "r");
	apub = PEM_read_RSAPublicKey(f, NULL, NULL, NULL);
	fclose(f);
	f = fopen(encryptedAESfName, "rb");
	unsigned char* enc_aes_key=(unsigned char*)malloc(RSA_size(apub));
	errno_t err = fread_s(enc_aes_key, RSA_size(apub), sizeof(unsigned char), RSA_size(apub), f);
	fclose(f);
	//buf = (unsigned char*)malloc(sizeof(aes_key));
	//memcpy(buf, aes_key, sizeof(aes_key));
	last_data = (unsigned char*)malloc(32);
	RSA_public_decrypt(RSA_size(apub), enc_aes_key, last_data, apub, RSA_PKCS1_PADDING);
	printf("Decrypted RSA sig = ");
	printf("\n");
	for (int i = 0; i < 32; i++)
	{
		printf("%02X ", last_data[i]);
	}
	printf("\n");
	free(last_data);
}
