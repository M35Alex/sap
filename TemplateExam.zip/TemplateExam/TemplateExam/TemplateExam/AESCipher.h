#include <openssl/ssl.h>
#include <openssl/bio.h>
#include <openssl/aes.h>
#include <stdio.h>
#include <string.h>
#define INBUFSIZE 512
#define OUTBUFSIZE 4096
class AESCipher {

public:
	static int outEncryptedBytes;
	static void EncryptECB(const char* inputfName, const char* outputfName, unsigned char** outBuffer,
		unsigned char* key, int key_size);
	static void EncryptCBC(const char* inputfName, const char* outputfName, unsigned char** outBuffer,
		unsigned char* key, int key_size, unsigned char* iv);
	static void DecryptECB(const char* inputfName, const char* outputfName, unsigned char** outBuffer,
		unsigned char* key, int key_size);
	static void DecryptCBC(const char* inputfName, const char* outputfName, unsigned char** outBuffer,
		unsigned char* key, int key_size, unsigned char* iv);
	static void EncryptBufferCBC(unsigned char* plaintext, int sizeOfPlaintext, unsigned char* key, unsigned char* iv, unsigned char** outBuffer);
	static void prtErrAndExit(int eVal, char* msg);
};
