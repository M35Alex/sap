#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <openssl/aes.h>
#include <openssl/sha.h>
#include "MessageDigest.h"
#include "AESCipher.h"
#include "RSA_Cipher.h"
#include "DigitalSignature.h"

#define MESSAGE_CHUNK 256 
#define MAX_BUF 256

int AESCipher::outEncryptedBytes = 0;
// Function to read IV from file and convert to byte array
void readIVFromFile(const char* filename, unsigned char* iv, size_t ivSize) {
	FILE* file;
	if (fopen_s(&file, filename, "r")) {
		fprintf(stderr, "Unable to open file %s\n", filename);
	}

	char buffer[256];
	if (fgets(buffer, sizeof(buffer), file) == NULL) {
		fprintf(stderr, "Error reading from file %s\n", filename);
		fclose(file);
	}
	fclose(file);

	// Convert hex string to byte array
	char* hexString = buffer;
	for (size_t i = 0; i < ivSize; ++i) {
		unsigned int byte;
		while (*hexString == ' ' || *hexString == ',' || *hexString == '\n') {
			++hexString;
		}
		if (sscanf_s(hexString, "0x%2x", &byte) == 1) {
			iv[i] = (unsigned char)byte;
			hexString += 4; // Move to the next hex value
		}
	}
}
void encryptFile(const char* inputFilename, const char* outputFilename, const unsigned char* key, const unsigned char* iv) {
	FILE* inputFile;
	if (fopen_s(&inputFile, inputFilename, "rb")) {
		fprintf(stderr, "Unable to open input file %s\n", inputFilename);
	}

	FILE* outputFile;
	if (fopen_s(&outputFile, outputFilename, "wb")) {
		fprintf(stderr, "Unable to open output file %s\n", outputFilename);
		fclose(inputFile);
	}

	AES_KEY aesKey;
	AES_set_encrypt_key(key, 256, &aesKey);

	unsigned char buffer[AES_BLOCK_SIZE];
	unsigned char encryptedBuffer[AES_BLOCK_SIZE];
	unsigned char ivec[AES_BLOCK_SIZE];
	memcpy(ivec, iv, AES_BLOCK_SIZE);

	int bytesRead;
	while ((bytesRead = fread(buffer, 1, AES_BLOCK_SIZE, inputFile)) != 0) {
		if (bytesRead < AES_BLOCK_SIZE) {
			memset(buffer + bytesRead, AES_BLOCK_SIZE - bytesRead, AES_BLOCK_SIZE - bytesRead);
		}
		AES_cbc_encrypt(buffer, encryptedBuffer, AES_BLOCK_SIZE, &aesKey, ivec, AES_ENCRYPT);
		fwrite(encryptedBuffer, 1, AES_BLOCK_SIZE, outputFile);
	}

	fclose(inputFile);
	fclose(outputFile);
}

int main() {
/* SAP JANUARY - NO CLASSES
	FILE* f = NULL;
	FILE* fdst = NULL;
	errno_t err;
	SHA256_CTX ctx;
	
	
	//EX1
	unsigned char finalDigest[SHA256_DIGEST_LENGTH];
	SHA256_Init(&ctx);
	int nameLen;
	unsigned char* fileBuffer = NULL;
	err = fopen_s(&f, "name.txt", "rb");
	if (err == 0) {
		fseek(f, 0, SEEK_END);
		int fileLen = ftell(f);
		nameLen = fileLen;
		fseek(f, 0, SEEK_SET);

		fileBuffer = (unsigned char*)malloc(fileLen);
		fread(fileBuffer, fileLen, 1, f);
		unsigned char* tmpBuffer = fileBuffer;

		while (fileLen > 0) {
			if (fileLen > MESSAGE_CHUNK) {
				SHA256_Update(&ctx, tmpBuffer, MESSAGE_CHUNK);
			}
			else {
				SHA256_Update(&ctx, tmpBuffer, fileLen);
			}
			fileLen -= MESSAGE_CHUNK;
			tmpBuffer += MESSAGE_CHUNK;
		}

		SHA256_Final(finalDigest, &ctx);

		int count = 0;
		printf("\nSHA256 = ");
		for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
			printf("%02X", finalDigest[i]);
			printf(" ");
		}
		printf("\n\n");

		fclose(f);
	}

	//EX2
	unsigned char iv[16];
	unsigned char key[32];
	//READ IV from FILE
	readIVFromFile("iv.txt", iv, sizeof(iv));
	//READ AES KEY
	err = fopen_s(&f, "aes.key", "rb");
	if (err == 0) {
		fread_s(key, sizeof(key), sizeof(unsigned char), sizeof(key),f);
		fclose(f);
	}
	//Encrypt FILE
	encryptFile("name.txt", "enc_name.aes", key, iv);
	
	SHA256_Init(&ctx);
	fileBuffer = NULL;
	err = fopen_s(&f, "enc_name.aes", "rb");
	if (err == 0) {
		fseek(f, 0, SEEK_END);
		int fileLen = ftell(f);
		nameLen = fileLen;
		fseek(f, 0, SEEK_SET);

		fileBuffer = (unsigned char*)malloc(fileLen);
		fread(fileBuffer, fileLen, 1, f);
		unsigned char* tmpBuffer = fileBuffer;

		while (fileLen > 0) {
			if (fileLen > MESSAGE_CHUNK) {
				SHA256_Update(&ctx, tmpBuffer, MESSAGE_CHUNK);
			}
			else {
				SHA256_Update(&ctx, tmpBuffer, fileLen);
			}
			fileLen -= MESSAGE_CHUNK;
			tmpBuffer += MESSAGE_CHUNK;
		}

		SHA256_Final(finalDigest, &ctx);

		int count = 0;
		printf("\nSHA256 = ");
		for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
			printf("%02X", finalDigest[i]);
			printf(" ");
		}
		printf("\n\n");

		fclose(f);
	}

	//EX3
	//Generate the RSA keypair
	//***********************************************************************
	RSA* rsaKP = NULL;

	// rsaKP = RSA_new(); // allocate storage for RSA openssl structure
	rsaKP = RSA_generate_key(1024, 65535, NULL, NULL); // generate RSA key pair on 1k bits

	RSA_check_key(rsaKP); // validate the previous generated key pair

	FILE* fpPriv = NULL;
	fopen_s(&fpPriv, "privKeyReceiver2.pem", "w+"); // create file to store the RSA private key (in PEM format)
	PEM_write_RSAPrivateKey(fpPriv, rsaKP, NULL, NULL, 0, 0, NULL); // get the private key from RSA openssl structure and 
	// store it in the file in PEM format
	fclose(fpPriv);

	FILE* fpPub = NULL;
	fopen_s(&fpPub, "pubKeyReceiver2.pem", "w+"); // create file to store the RSA public key
	PEM_write_RSAPublicKey(fpPub, rsaKP); // get the public key fro RSA openssl structure and
	// store it in the file in PEM format
	fclose(fpPub);

	RSA_free(rsaKP); // release the storage for RSA openssl structure

	printf("\n The RSA key pair generated! \n");

	//***********************************************************************

	//***************************CREATE THE SIGNATURE************************
	fopen_s(&fpPriv, "privKeyReceiver.pem", "r+");
	RSA* apriv;
	unsigned char* buf = NULL;
	unsigned char* e_data = NULL;
	unsigned char* last_data = NULL;
	apriv = RSA_new();
	apriv = PEM_read_RSAPrivateKey(fpPriv, NULL, NULL, NULL);
	fclose(fpPriv);
	buf = (unsigned char*)malloc(sizeof(finalDigest));
	memcpy(buf, finalDigest, sizeof(finalDigest));

	// e_data buffer to store the digital signature; there is one single RSA block for the signature
	e_data = (unsigned char*)malloc(RSA_size(apriv)); //RSA_size => 1024 bits/128 bytes

	RSA_private_encrypt(sizeof(finalDigest), buf, e_data, apriv, RSA_PKCS1_PADDING); // encryption for e-signature made by using the PRIVATE key

	printf("Signature(RSA) = ");
	printf("\n");
	for (int i = 0; i < RSA_size(apriv); i++)
	{
		printf("%02X ", e_data[i]);
	}
	printf("\n");

	err = fopen_s(&fdst, "digital2.sign", "wb");
	// write the content of e_data with digital signature into a file
	fwrite(e_data, RSA_size(apriv), 1, fdst); // write the e-sign into the file

	fclose(fdst);

	free(e_data);
	free(buf);

	RSA_free(apriv);
	return 0;
*/
/*  SAP JANUARY W/ CLASSES
//EX1
unsigned char* buf = (unsigned char*)malloc(SHA256_DIGEST_LENGTH);
MessageDigest::getHashToBuf("name.txt", &buf, "SHA256");
MessageDigest::printHash(buf, "SHA256");
//EX2
//READ IV from file
unsigned char iv[16];
readIVFromFile("iv.txt", iv, sizeof(iv));
//READ key from file
FILE* f = NULL;
unsigned char key[32];
int err = fopen_s(&f, "aes.key", "rb");
if (err == 0) {
	fread_s(key, sizeof(key), sizeof(unsigned char), sizeof(key), f);
	AESCipher::EncryptCBC("name.txt", "enc_name.aes", NULL, key, 256, iv);
	fclose(f);
}
//EX3
//Generate RSA Key-Pair
RSA_Cipher::GenerateRSAKeyPair(1024, "privKey.pem", "pubKey.pem");
DigitalSignature::create("enc_name.aes", "privKeyReceiver.pem", "digital.sign", "SHA256");
DigitalSignature::verify("enc_name.aes", "pubKeyReceiver.pem", "digital.sign", "SHA256");
return 0;

*/
	//EX1
	unsigned char key[16] = { 0xff, 0xff, 0xff, 0xff, 0x00, 0x00, 0x00, 0x00, 0x08, 0x07, 0x06, 0x05, 0x00, 0x00, 0x00, 0x00 };
	unsigned char iv[16] = { 0xff, 0xff, 0xff, 0xff, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x10, 0x11, 0x12};
	AES_KEY aes_key;
	AES_set_decrypt_key(key, (sizeof(key) * 8), &aes_key);

	unsigned char ciphertext[32];
	unsigned char restoringtext[32];
	FILE* f = NULL;
	int err = fopen_s(&f, "encrypted.aes", "rb");
	fread(ciphertext, sizeof(unsigned char*), sizeof(ciphertext), f);
	AES_cbc_encrypt(ciphertext, restoringtext, sizeof(restoringtext), &aes_key, iv, AES_DECRYPT);
	//restoringtext[32] = '\0';
	//printf("\nRestored plaintext for AES-ECB: ");
	//printf("%s", restoringtext);
	fclose(f);
	err = fopen_s(&f, "decrypted.txt", "w");
	fwrite(restoringtext, sizeof(restoringtext), sizeof(unsigned char), f);
	fclose(f);
	//EX2,3
	DigitalSignature::verify("decrypted.txt", "public.pem", "esign.sig", "SHA256");
	return 0;
}