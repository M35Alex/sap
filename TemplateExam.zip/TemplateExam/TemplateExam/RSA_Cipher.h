#pragma once
class RSA_Cipher
{
public:
	static void GenerateRSAKeyPair(int keySize,const char* privKeyfName, const char* pubKeyfName);
	static void EncryptRSA(const char* infName, const char* keyfName, unsigned char* outBuffer, const char* outfName);
	static void DecryptRSA(const char* infName, const char* keyfName, unsigned char* outBuffer, const char* outfName);
	static void PrivEncryptRSA_AES_KEY(unsigned char* aes_key,int aes_key_size, const char* privKeyfName, const char* outfName);
	static void PubDecryptRSA_AES_KEY(const char* encryptedAESfName, const char* pubKeyfName, unsigned char** outBuffer);
};

