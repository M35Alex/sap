#define _CRT_SECURE_NO_WARNINGS
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/aes.h>
#include <openssl/bio.h>
#include <openssl/sha.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cctype>

unsigned char* sha256(char* tmpBuffer) {
	unsigned char* finalDigestsha256;//[SHA_DIGEST_LENGTH]
	finalDigestsha256 = (unsigned char*)malloc(SHA256_DIGEST_LENGTH * sizeof(unsigned char));
	SHA256_CTX ctx;
	SHA256_Init(&ctx);
	SHA256_Update(&ctx, (unsigned char*)tmpBuffer, strlen(tmpBuffer)-4);
	SHA256_Final(finalDigestsha256, &ctx);
	return finalDigestsha256;
}
char* byteArrayToChar(unsigned char* input, int inputSize) {
	char* output;
	char* hexaDeciNum;
	output = (char*)malloc(inputSize * 4 - 4); //*2 because each byte is reprezented by 2 characters
	for (int i = 0; i < inputSize * 2 - 2; i++)
	{
		int byteOfI = int(input[i]);

		hexaDeciNum = (char*)malloc(2 * sizeof(char));
		//reset hexaDeciNum
		hexaDeciNum[0] = '0';
		hexaDeciNum[1] = '0';


		int counter = 0;
		while (byteOfI != 0) {

			// temporary variable to store remainder
			int temp = 0;

			// storing remainder in temp variable.
			temp = byteOfI % 16;

			// check if temp < 10
			if (temp < 10) {
				hexaDeciNum[counter] = (char)(temp + 48);
				counter++;
			}
			else {
				hexaDeciNum[counter] = (char)(temp + 55);
				counter++;
			}
			byteOfI = byteOfI / 16;
		}
		output[i * 2] = hexaDeciNum[1];
		output[i * 2 + 1] = hexaDeciNum[0];
		free(hexaDeciNum);
	}
	return output;
}

int main() {
	//sub 1
	FILE* passFile;
	FILE* outFile;
	passFile = fopen("wordlist.txt", "r");
	if (passFile == NULL) {
		printf("File not found!");
		return 1;
	}
	outFile = fopen("hashes.txt", "w");

	char* line = (char*)malloc(sizeof(char) * 50);
	while (fgets(line, sizeof(line), passFile)) {

		//sha of line
		char* lineToCharPointer;
		lineToCharPointer = (char*)malloc(strlen(line) * sizeof(char) - 1);
		strncpy(lineToCharPointer, line, strlen(line) - 1);


		unsigned char* shaOfLine = sha256(lineToCharPointer);





		
		//getHex of sha
		int shalength = SHA256_DIGEST_LENGTH;
		
		char* sha256rezToChar;
		sha256rezToChar = byteArrayToChar(shaOfLine, SHA256_DIGEST_LENGTH);
		sha256rezToChar[SHA256_DIGEST_LENGTH*2] = 0x00;
		printf("%s\n",sha256rezToChar);

		//write to file
		fprintf(outFile,"%s\n", sha256rezToChar);


		free(lineToCharPointer);
		free(sha256rezToChar);
	}

	free(line);
	fclose(passFile);
	fclose(outFile);
	return 0;
}