package ism.ase.ro.sap.exam.Dumitrescu.CristianMihail;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.security.*;
import java.security.cert.CertificateException;
import java.util.Base64;

public class DumitrescuCristianMihailExam {
    public static String getHex(byte[]bytes){
        StringBuilder sb = new StringBuilder();
        for(byte value : bytes){
            sb.append(String.format("%02x", value).toLowerCase());
        }
        return sb.toString();
    }
    public static void decryptCBC(String cipherFile, byte[] key, String algorithm, String plainFile) throws NoSuchPaddingException, NoSuchAlgorithmException, IOException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
        File input = new File(cipherFile);
        if (!input.exists()){
            throw new FileNotFoundException();
        }
        FileInputStream fis = new FileInputStream(input);
        BufferedInputStream bis = new BufferedInputStream(fis);

        File output = new File(plainFile);
        if (!output.exists()){
            output.createNewFile();
        }

        FileOutputStream fos = new FileOutputStream(output);
        BufferedOutputStream bos = new BufferedOutputStream(fos);

        Cipher ci = Cipher.getInstance(algorithm + "/CBC/PKCS5Padding");
        SecretKeySpec keySpec = new SecretKeySpec(key, algorithm);


        byte[] iv= {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,03,02,20,23};//16 bytes
        IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);

        ci.init(Cipher.DECRYPT_MODE, keySpec, ivParameterSpec);


        byte[] buffer = new byte[ci.getBlockSize()];
        byte[] cipherBuffer;
        int noBytes=0;

        while(noBytes!=-1){
            noBytes=bis.read(buffer);
            if(noBytes!=-1) {
                cipherBuffer=ci.update(buffer, 0, noBytes);
                bos.write(cipherBuffer);
            }
        }

        cipherBuffer = ci.doFinal();

        bos.write(cipherBuffer);

        bis.close();
        bos.close();
    }

    public static void main(String[] args) throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidAlgorithmParameterException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, CertificateException, KeyStoreException, UnrecoverableKeyException, SignatureException {
        //fingerprint from files
        //sub1
        File fingerprintFile = new File("sha2Fingerprints.txt");
        if(!fingerprintFile.exists()){
            System.out.println("No sha 2 file!");
        }
        FileReader frFingerprint = new FileReader(fingerprintFile);
        BufferedReader brFingerprint = new BufferedReader(frFingerprint);

        String nameOfFile = brFingerprint.readLine();

        while(nameOfFile!=null) {
            String shaOfFile = brFingerprint.readLine();

            Base64.Decoder shaOfFileBase64Decoder = Base64.getDecoder();
            byte[] resultOfDecoding = shaOfFileBase64Decoder.decode(shaOfFile.getBytes());

            File fileExamined = new File(nameOfFile);
            FileInputStream fisFileExamined = new FileInputStream(fileExamined);
            BufferedInputStream bisFileExamined = new BufferedInputStream(fisFileExamined);


            MessageDigest digest = MessageDigest.getInstance("SHA256");
            digest.update(bisFileExamined.readAllBytes());
            byte[] resultOfDigest = digest.digest();

            if((getHex(resultOfDecoding)).equals(getHex(resultOfDigest))){
                System.out.println("File "+ nameOfFile+" is ok!");
            }
            else{
                System.out.println("File "+ nameOfFile+" is NOT ok!");
            }

            bisFileExamined.close();
            nameOfFile = brFingerprint.readLine();
        }
        brFingerprint.close();

        //sub2
        //host is 71.
        File fileWithPassword = new File("system32\\svchost71.exe");
        FileInputStream fisFileWithPassword = new FileInputStream(fileWithPassword);
        BufferedInputStream bisFileWithPassword  = new BufferedInputStream(fisFileWithPassword);

        byte[] password = bisFileWithPassword.readAllBytes();

        decryptCBC("financialdata.enc",password,"AES","financialdata.txt");

        bisFileWithPassword.close();

        //sub3
        File responseInputFile = new File("myresponse.txt");
        FileInputStream fis = new FileInputStream(responseInputFile);

        byte[] responseContent = fis.readAllBytes();

        File file = new File("cristikeystore.ks");
        if(!file.exists()){
            throw new FileNotFoundException("-----No keystore File!-----");
        }

        FileInputStream fis2 = new FileInputStream(file);

        KeyStore ks = KeyStore.getInstance("pkcs12");
        ks.load(fis2, "cristikeystorepass".toCharArray());

        fis2.close();

        PrivateKey privateKey = (PrivateKey) ks.getKey("cristialias", "cristikeystorepass".toCharArray());

        Signature signature = Signature.getInstance("SHA256withRSA");
        signature.initSign(privateKey);
        signature.update(responseContent);

        byte[] signatureUsed = signature.sign();

        fis.close();

        File outputFileForSign = new File("DataSignature.ds");
        FileOutputStream fos = new FileOutputStream(outputFileForSign);
        BufferedOutputStream bos = new BufferedOutputStream(fos);

        bos.write(signatureUsed);

        bos.close();
    }
}