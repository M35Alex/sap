#define _CRT_SECURE_NO_WARNINGS
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/bio.h>
#include <openssl/sha.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cctype>


char* byteArrayToChar(unsigned char* input, int inputSize) {
	char* output;
	char* hexaDeciNum;
	output = (char*)malloc(inputSize * 4 - 4); //*2 because each byte is reprezented by 2 characters
	for (int i = 0; i < inputSize * 2 - 2; i++)
	{
		int byteOfI = int(input[i]);

		hexaDeciNum = (char*)malloc(2 * sizeof(char));
		//reset hexaDeciNum
		hexaDeciNum[0] = '0';
		hexaDeciNum[1] = '0';


		int counter = 0;
		while (byteOfI != 0) {

			// temporary variable to store remainder
			int temp = 0;

			// storing remainder in temp variable.
			temp = byteOfI % 16;

			// check if temp < 10
			if (temp < 10) {
				hexaDeciNum[counter] = (char)(temp + 48);
				counter++;
			}
			else {
				hexaDeciNum[counter] = (char)(temp + 55);
				counter++;
			}
			byteOfI = byteOfI / 16;
		}
		output[i * 2] = hexaDeciNum[1];
		output[i * 2 + 1] = hexaDeciNum[0];
		free(hexaDeciNum);
	}
	return output;
}
void rsaDecrypt(unsigned char* key, int sizeOfKey, unsigned char* tmpBuffer, int sizeOfTmpBuffer, unsigned char*& output, int& sizeOfOutput) {
	BIO* bio = BIO_new_mem_buf(key, sizeOfKey);
	RSA* rsa = RSA_new();
	if (!PEM_read_bio_RSAPublicKey(bio, &rsa, nullptr, nullptr)) {
		printf("Problem occured!");
	}
	else {
		unsigned char* outputBuffer = (unsigned char*)malloc(RSA_size(rsa));

		int result = RSA_public_decrypt(sizeOfTmpBuffer,
			(unsigned char*)tmpBuffer,
			(unsigned char*)outputBuffer,
			rsa,
			RSA_PKCS1_PADDING);
		output = outputBuffer;
		sizeOfOutput = result;
		BIO_free(bio);
		RSA_free(rsa);
	}
}

int main() {

	FILE* pemFile;
	pemFile = fopen("Utils/ReadPemDecryptRSAsign/pubKeySender.pem", "rb");
	if (pemFile == NULL) {
		printf("Public key file not found!");
		return 1;
	}

	unsigned char* key;
	int indexKey = 0;
	char letter = NULL;
	char keyBuffer[1000]="";
	while (!feof(pemFile)) {
		fread(&letter, sizeof(char), 1, pemFile);
		memcpy(((char*)keyBuffer) + indexKey,&letter,1);
		indexKey++;
	}
	indexKey--;
	key = (unsigned char*)malloc(indexKey * sizeof(char));
	for (int i = 0; i < indexKey; i++) {
		memcpy(((char*)key) + i, (char*)keyBuffer + i, 1);
	}


	FILE* rsaSign;
	rsaSign = fopen("Utils/ReadPemDecryptRSAsign/RSASign.sig", "rb");
	if (rsaSign == NULL) {
		printf("Rsa signiture file not found!");
		return 1;
	}

	unsigned char* signiture;
	int indexSigniture = 0;
	char signitureBuffer[1000]="";
	while (!feof(rsaSign)) {
		fread(&letter, sizeof(char), 1, rsaSign);
		memcpy(((char*)signitureBuffer) + indexSigniture, &letter, 1);
		indexSigniture++;
	}
	indexSigniture--;
	signiture = (unsigned char*)malloc(indexSigniture * sizeof(char));
	for (int i = 0; i < indexSigniture; i++) {
		memcpy((char*)signiture + i, (char*)signitureBuffer + i, 1);
	}



	unsigned char* RSASignitureDecryptedBuffer = (unsigned char*)malloc(1000 * sizeof(char));
	int indexRSASignitureDecrypted = 0;
	rsaDecrypt(key, indexKey, signiture, indexSigniture, RSASignitureDecryptedBuffer, indexRSASignitureDecrypted);
	char* RSASignitureDecrypted = byteArrayToChar(RSASignitureDecryptedBuffer, indexRSASignitureDecrypted);
	printf("Signiture decrypted with public key is: ");
	for (int i = 0; i < indexRSASignitureDecrypted * 2; i++) {
		printf("%c", tolower(RSASignitureDecrypted[i]));
	}
	printf("\n");




	free(pemFile);
	free(rsaSign);
	free(key);
	free(signiture);
	return 0;
}
