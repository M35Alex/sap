#define _CRT_SECURE_NO_WARNINGS
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/bio.h>
#include <openssl/sha.h>
#include <openssl/md5.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cctype>

char* byteArrayToChar(unsigned char* input, int inputSize) {
	char* output;
	char* hexaDeciNum;
	output = (char*)malloc(inputSize * 4 - 4); //*2 because each byte is reprezented by 2 characters
	for (int i = 0; i < inputSize * 2 - 2; i++)
	{
		int byteOfI = int(input[i]);

		hexaDeciNum = (char*)malloc(2 * sizeof(char));
		//reset hexaDeciNum
		hexaDeciNum[0] = '0';
		hexaDeciNum[1] = '0';


		int counter = 0;
		while (byteOfI != 0) {

			// temporary variable to store remainder
			int temp = 0;

			// storing remainder in temp variable.
			temp = byteOfI % 16;

			// check if temp < 10
			if (temp < 10) {
				hexaDeciNum[counter] = (char)(temp + 48);
				counter++;
			}
			else {
				hexaDeciNum[counter] = (char)(temp + 55);
				counter++;
			}
			byteOfI = byteOfI / 16;
		}
		output[i * 2] = hexaDeciNum[1];
		output[i * 2 + 1] = hexaDeciNum[0];
		free(hexaDeciNum);
	}
	return output;
}

int main() {

	//x509 cert
	X509* X509Cert = X509_new();

	X509_set_version(X509Cert, 0x2);

	ASN1_INTEGER_set(X509_get_serialNumber(X509Cert), 1);

	X509_NAME_add_entry_by_txt(X509_get_issuer_name(X509Cert), "C", MBSTRING_ASC, (unsigned char*)"RO", -1, -1, 0);
	X509_NAME_add_entry_by_txt(X509_get_issuer_name(X509Cert), "O", MBSTRING_ASC, (unsigned char*)"ASE", -1, -1, 0);
	X509_NAME_add_entry_by_txt(X509_get_issuer_name(X509Cert), "OU", MBSTRING_ASC, (unsigned char*)"ITC Security Master", -1, -1, 0);
	X509_NAME_add_entry_by_txt(X509_get_issuer_name(X509Cert), "CN", MBSTRING_ASC, (unsigned char*)"Cristi Dumitrescu", -1, -1, 0);

	int DaysStart = 1;
	int DaysStop = 7;
	X509_gmtime_adj(X509_get_notBefore(X509Cert), (long)60 * 60 * 24 * DaysStart);
	X509_gmtime_adj(X509_get_notAfter(X509Cert), (long)60 * 60 * 24 * DaysStop);

	//RSA key gen
	EVP_PKEY* pkey = EVP_PKEY_new();
	RSA* rsa = RSA_generate_key(1024, 65535, NULL, NULL);
	EVP_PKEY_set1_RSA(pkey, rsa);
	X509_set_pubkey(X509Cert, pkey);


	const EVP_MD* dgAlg = EVP_sha512();

	X509_sign(X509Cert, pkey, dgAlg);

	BIO* out1 = BIO_new_file("Utils/CreateKeyPlaceInCertificate/Certificate.cer", "wb");
	i2d_X509_bio(out1, X509Cert);
	BIO_free(out1);

	BIO* out2 = BIO_new_file("Utils/CreateKeyPlaceInCertificate/PrivateKey.key", "wb");
	i2d_PrivateKey_bio(out2, pkey);
	BIO_free(out2);
	

	RSA_free(rsa);
	EVP_PKEY_free(pkey);
	X509_free(X509Cert);
	return 0;
}