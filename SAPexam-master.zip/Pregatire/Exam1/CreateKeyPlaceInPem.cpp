#define _CRT_SECURE_NO_WARNINGS
#include <openssl/rsa.h>
#include <openssl/aes.h>
#include <openssl/pem.h>
#include <openssl/bio.h>
#include <openssl/sha.h>
#include <openssl/md5.h>
#include <openssl/rand.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cctype>

char* byteArrayToChar(unsigned char* input, int inputSize) {
	char* output;
	char* hexaDeciNum;
	output = (char*)malloc(inputSize * 4 - 4); //*2 because each byte is reprezented by 2 characters
	for (int i = 0; i < inputSize * 2 - 2; i++)
	{
		int byteOfI = int(input[i]);

		hexaDeciNum = (char*)malloc(2 * sizeof(char));
		//reset hexaDeciNum
		hexaDeciNum[0] = '0';
		hexaDeciNum[1] = '0';


		int counter = 0;
		while (byteOfI != 0) {

			// temporary variable to store remainder
			int temp = 0;

			// storing remainder in temp variable.
			temp = byteOfI % 16;

			// check if temp < 10
			if (temp < 10) {
				hexaDeciNum[counter] = (char)(temp + 48);
				counter++;
			}
			else {
				hexaDeciNum[counter] = (char)(temp + 55);
				counter++;
			}
			byteOfI = byteOfI / 16;
		}
		output[i * 2] = hexaDeciNum[1];
		output[i * 2 + 1] = hexaDeciNum[0];
		free(hexaDeciNum);
	}
	return output;
}

int main() {
	//RSA key gen



	RSA* r = NULL;
	BIGNUM* bne = NULL;
	BIO* bp_public = NULL, * bp_private = NULL;
	int bits = 2048;
	unsigned long e = RSA_F4;

	RSA* pb_rsa = NULL;
	RSA * p_rsa = NULL;



    // 1. generate rsa key
    bne = BN_new();
    if (BN_set_word(bne, e) != 1) {
        printf("Big number could not be generated!");
        return 1;
    }

    r = RSA_new();
    if (RSA_generate_key_ex(r, bits, bne, NULL) != 1) {
        printf("RSA key could not be generated!");
        return 1;
    }
    //r=RSA_generate_key(bits, 65535, NULL, NULL);

    // 2. save public key
    bp_public = BIO_new_file("Utils/CreateKeyPlaceInPem/public.pem", "w+");
    //PEM_write_RSAPublicKey(fpPub, r);
    bp_public = BIO_new(BIO_s_mem());
    if (PEM_write_bio_RSAPublicKey(bp_public, r) != 1) {
        printf("Public key could not be written!");
        return 1;
    }

    // 3. save private key
    bp_private = BIO_new_file("Utils/CreateKeyPlaceInPem/private.pem", "w+");
    //PEM_write_RSAPrivateKey(fpPriv, r, NULL, NULL, 0, 0, NULL);
    bp_private = BIO_new(BIO_s_mem());
    if (PEM_write_bio_RSAPrivateKey(bp_private, r, NULL, NULL, 0, NULL, NULL) != 1) {
        printf("Private key could not be written!");
        return 1;
    }


    
    //for decript
	size_t pri_len;          // Length of private key
	size_t pub_len;          // Length of public key
	char* pri_key;           // Private key in PEM
	char* pub_key;           // Public key in PEM

    BIO* pbkeybio = NULL;
    BIO* pkeybio = NULL;

    //4. Get the keys are PEM formatted strings //from memory
    pri_len = BIO_pending(bp_private);
    pub_len = BIO_pending(bp_public);

    pri_key = (char*)malloc(pri_len + 1);
    pub_key = (char*)malloc(pub_len + 1);

    BIO_read(bp_private, pri_key, pri_len);
    BIO_read(bp_public, pub_key, pub_len);

    pri_key[pri_len] = '\0';
    pub_key[pub_len] = '\0';

    printf("\n%s\n%s\n", pri_key, pub_key);

    //verify if you are able to re-construct the keys
    pbkeybio = BIO_new_mem_buf((void*)pub_key, pub_len);
    if (pbkeybio == NULL) {
        return -1;
    }
    pb_rsa = PEM_read_bio_RSAPublicKey(pbkeybio, &pb_rsa, NULL, NULL);
    if (pb_rsa == NULL) {
        char buffer[120];
        printf("Error reading public key:%s\n", buffer);
        return 1;
    }

    pkeybio = BIO_new_mem_buf((void*)pri_key, pri_len);
    if (pkeybio == NULL) {
        return -1;
    }
    p_rsa = PEM_read_bio_RSAPrivateKey(pkeybio, &p_rsa, NULL, NULL);
    if (p_rsa == NULL) {
        char buffer[120];
        printf("Error reading private key:%s\n", buffer);
        return 1;
    }

    //idk what this does
    //EVP_PKEY* evp_pbkey = NULL;
    //EVP_PKEY* evp_pkey = NULL;

    //evp_pkey = EVP_PKEY_new();
    //EVP_PKEY_assign_RSA(evp_pkey, p_rsa);

    BIO_free(pbkeybio);
    BIO_free(pkeybio);


    BIO_free_all(bp_public);
    BIO_free_all(bp_private);
    RSA_free(r);
    BN_free(bne);







    //AES key gen

    //for dercipt
    size_t aes_len;          // Length of  key
    char* aes_key;           // Key in PEM

    AES_KEY* a;
    BIO* bp_key = NULL;

    // 1. generate aes key

    unsigned char key[16], iv[16];

    if (!RAND_bytes(key, sizeof key)) {
        printf("Key could not be generated!");
        return 1;
    }
    if (!RAND_bytes(iv, sizeof iv)) {
        printf("Iv could not be generated!");
        return 1;
    }

    a = new AES_KEY();
    AES_set_encrypt_key(key, 256, a);
   

    //encription with padding
    //std::string txt("this is a test");
    //const int UserDataSize = (const int)txt.length();   // Get the length pre-padding
    //int RequiredPadding = (AES_BLOCK_SIZE - (txt.length() % AES_BLOCK_SIZE));   // Calculate required padding
    //std::vector<unsigned char> PaddedTxt(txt.begin(), txt.end());   // Easier to Pad as a vector
    //for (int i = 0; i < RequiredPadding; i++) {
    //    PaddedTxt.push_back(0); //  Increase the size of the string by
    //}                           //  how much padding is necessary
    //unsigned char* UserData = &PaddedTxt[0];// Get the padded text as an unsigned char array
    //const int UserDataSizePadded = (const int)PaddedTxt.size();// and the length (OpenSSl is a C-API)
    //AES_cbc_encrypt(UserData, EncryptedData, UserDataSizePadded, (const AES_KEY*)AesKey, IV, AES_ENCRYPT);

    //decription with padding
    //AES_KEY* AesDecryptKey = new AES_KEY(); // AES Key to be used for Decryption
    //AES_set_decrypt_key(Key, 256, AesDecryptKey);   // We Initialize this so we can use the OpenSSL Encryption API

    //AES_cbc_encrypt(inBuf, outBuf, inLen, &a, iv, AES_DECRYPT);


    //cannot save to pem file. we just save the key and iv in files



    return 0;
}
