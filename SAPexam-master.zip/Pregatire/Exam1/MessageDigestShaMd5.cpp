#define _CRT_SECURE_NO_WARNINGS
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/bio.h>
#include <openssl/sha.h>
#include <openssl/md5.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cctype>


unsigned char* sha256(unsigned char* tmpBuffer, int size) {
	unsigned char* finalDigestsha256;
	finalDigestsha256 = (unsigned char*)malloc(SHA256_DIGEST_LENGTH * sizeof(unsigned char));
	SHA256_CTX ctx;
	SHA256_Init(&ctx);
	SHA256_Update(&ctx, tmpBuffer, size);
	SHA256_Final(finalDigestsha256, &ctx);
	return finalDigestsha256;
}

unsigned char* sha512(unsigned char* tmpBuffer, int size) {
	unsigned char* finalDigestsha512;
	finalDigestsha512 = (unsigned char*)malloc(SHA512_DIGEST_LENGTH * sizeof(unsigned char));
	SHA512_CTX ctx;
	SHA512_Init(&ctx);
	SHA512_Update(&ctx, tmpBuffer, size);
	SHA512_Final(finalDigestsha512, &ctx);
	return finalDigestsha512;
}

unsigned char* md5(unsigned char* tmpBuffer, int size) {
	unsigned char* finalDigestmd5;
	finalDigestmd5 = (unsigned char*)malloc(MD5_DIGEST_LENGTH * sizeof(unsigned char));
	MD5_CTX ctx;
	MD5_Init(&ctx);
	MD5_Update(&ctx, tmpBuffer, size);
	MD5_Final(finalDigestmd5, &ctx);
	return finalDigestmd5;
}

char* byteArrayToChar(unsigned char* input, int inputSize) {
	char* output;
	char* hexaDeciNum;
	output = (char*)malloc(inputSize * 4 - 4); //*2 because each byte is reprezented by 2 characters
	for (int i = 0; i < inputSize * 2 - 2; i++)
	{
		int byteOfI = int(input[i]);

		hexaDeciNum = (char*)malloc(2 * sizeof(char));
		//reset hexaDeciNum
		hexaDeciNum[0] = '0';
		hexaDeciNum[1] = '0';


		int counter = 0;
		while (byteOfI != 0) {

			// temporary variable to store remainder
			int temp = 0;

			// storing remainder in temp variable.
			temp = byteOfI % 16;

			// check if temp < 10
			if (temp < 10) {
				hexaDeciNum[counter] = (char)(temp + 48);
				counter++;
			}
			else {
				hexaDeciNum[counter] = (char)(temp + 55);
				counter++;
			}
			byteOfI = byteOfI / 16;
		}
		output[i * 2] = hexaDeciNum[1];
		output[i * 2 + 1] = hexaDeciNum[0];
		free(hexaDeciNum);
	}
	return output;
}

int main() {
	try {
		//open file with passwords and read it line by line
		FILE* passFile;
		char line[50];
		char lineConcatenated[56];
		char* lineConcatenatedNoBackSlashN;

		passFile = fopen("./Utils/MessageDigestShaMd5/ignis-10M.txt", "r");
		if (passFile == NULL) {
			printf("File not found!");
			return 1;
		}
		int count = 0;
		while (fgets(line, sizeof(line), passFile)) {
			count++;
			printf("%d /100\n", count / 100000);
			//printf("%s", line);//it counldn't read a line (511733,2731998,4904420,7517088,9974366) so i removed a line/character in that line

			//concatenate "ismsap" to it
			strcpy(lineConcatenated, "ismsap");
			strcat(lineConcatenated, line);
			//remove "\n" from line
			lineConcatenatedNoBackSlashN = (char*)malloc(strlen(lineConcatenated) * sizeof(char) - 1);
			strncpy(lineConcatenatedNoBackSlashN, lineConcatenated, strlen(lineConcatenated) - 1);

			//since passwords are short, we init, update once and final
			//hash with MD5
			unsigned char* md5rez = md5((unsigned char*)lineConcatenatedNoBackSlashN, strlen(lineConcatenatedNoBackSlashN)-4);

			//hash with SHA-256
			unsigned char* sha256rez = sha512(md5rez, MD5_DIGEST_LENGTH);

			//bytes resulting to string
			char* sha256rezToChar;

			sha256rezToChar = byteArrayToChar(sha256rez, SHA_DIGEST_LENGTH);

			//compare with given value
			bool ok = 1;
			for (int i = 0; i < strlen("8920c4d0ee6d49a247d4c46b990cb626030a37e2865c8c03a43c1e50b5eb6a54"); i++) {
				if (tolower(sha256rezToChar[i]) != "8920c4d0ee6d49a247d4c46b990cb626030a37e2865c8c03a43c1e50b5eb6a54"[i]) {
					ok = 0;
					break;
				}
			}
			if (ok == 1) {
				printf("Rezult is: %s", line);
				break;
			}
			free(md5rez);
			free(sha256rez);
			free(sha256rezToChar);

		}

		fclose(passFile);

		return 0;
	}
	catch (int ex) {
		printf("An exception occured!");
		return 1;
	}
}