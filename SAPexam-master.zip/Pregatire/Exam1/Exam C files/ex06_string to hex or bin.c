#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <string.h>

//int main()
//{
//	unsigned char str[] = "7F 80";
//	unsigned char* ptr;
//	long int result;
//
//	result = strtol(str, &ptr, 16);
//	printf("Internal value after conversion ASCII-to-binary is %d or %X\n", result, result);
//	result = strtol(ptr, &ptr, 16);
//	printf("Internal value after conversion ASCII-to-binary is %d or %X\n", result, result);
//}

int main()
{
	unsigned char str[] = "7F808182ABAC";
	unsigned char str_new[] = "1234AABB";
	unsigned char str_bin[] = "1000110100000000100011010000000";
	unsigned char* ptr, pair[2];
	long int result;

	ptr = str;
	for (unsigned char i = 0; i < strlen((char*)str); i += 2)
	{
		memcpy(pair, ptr, 2);
		result = strtol((char*)pair, NULL, 16);
		printf(" %X", result);
		ptr += 2;
	}
	printf("\n");
	result = strtol((char*)str_new, NULL, 16); // in order to fit the length of result, 
	// the input string must be max 8 bytes as hexadecimal pairs
	printf("%X", result);
	printf("\n");
	result = strtol((char*)str_bin, NULL, 2);
	printf("%d", result);
}