#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <openssl/md5.h>
#include <openssl/sha.h>

char* getHex(const unsigned char* bytearr, int size) {
	const size_t hexlen = 2;
	const size_t outstrlen = size * hexlen;

	char* outstr = (char*)malloc(outstrlen + 1);

	char* p = outstr;
	for (size_t i = 0; i < size; i++) {
		p += sprintf(p, "%.2x", bytearr[i]);
	}

	return outstr;
}

int main(){
	char passwordHashValue[] = "e6fe859c6a5352eff302a35f1642e1173b63199821bef384388850543f8aba68";
	FILE* f;
	unsigned char md5Digest[MD5_DIGEST_LENGTH];
	unsigned char sha256Digest[SHA256_DIGEST_LENGTH];
	unsigned char buffer[256];
	char salt[] = "ismsap";
	
	//open file
	f = fopen("ignis-10M.txt", "rb");
	//check if file exists
	if (f == NULL) {
		printf("File not found");
		return 1;
	}
	while (!feof(f)) {
		//read passwords from file and add salt
		//add salt
		for (int i = 0; i < strlen(salt); i++) {
			buffer[i] = salt[i];
		}
		int num_chars = strlen(salt);
		//read password
		for (int ch = fgetc(f); ch != EOF && ch != '\n'; ch = fgetc(f)) {
			buffer[num_chars++] = ch;
		}
		buffer[num_chars] = '\0';

		//compute Hashes
		MD5(buffer, num_chars, md5Digest);
		SHA256(md5Digest, sizeof(md5Digest), sha256Digest);
		char* hashAsHex = getHex(sha256Digest, sizeof(sha256Digest));

		//check if the password was found
		if (strcmp(passwordHashValue, hashAsHex) == 0) {
			printf("\nThe password is: %s", (buffer + strlen(salt)));
			break;
		}
		free(hashAsHex);
	}
	fclose(f);
	return 0;
}















