#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <string.h>
#include <windows.h>
#include <wincrypt.h>

unsigned char* get_random_bytes(size_t size) {
    HCRYPTPROV hCryptProv;
    if (!CryptAcquireContext(&hCryptProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT | CRYPT_SILENT)) {
        perror("Error acquiring cryptographic context");
        exit(1);
    }

    unsigned char* buffer = (unsigned char*)malloc(size * sizeof(unsigned char));
    if (!buffer) {
        perror("Error allocating memory");
        exit(1);
    }

    if (!CryptGenRandom(hCryptProv, (DWORD)size, buffer)) {
        perror("Error generating random data");
        exit(1);
    }

    CryptReleaseContext(hCryptProv, 0);

    return buffer;
}

int main()
{
    unsigned char* randomBytes = get_random_bytes(32);

    for (int i = 0; i < 16; i++)
        printf("%02X ", randomBytes[i]);

    free(randomBytes);
}

