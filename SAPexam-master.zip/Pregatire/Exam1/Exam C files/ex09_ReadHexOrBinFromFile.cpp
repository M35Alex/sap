#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <string.h>

#define KEY_SIZE 16

void print_binary(unsigned int num) {
    int i;
    for (i = 31; i >= 0; i--) {
        putchar(((num >> i) & 1) + '0');
        if (i % 8 == 0) putchar(' ');
    }
    putchar('\n');
}

char* getHex(const unsigned char* bytearr, int size) {
    const size_t hexlen = 2;
    const size_t outstrlen = size * hexlen;

    char* outstr = (char*)malloc(outstrlen + 1);

    char* p = outstr;
    for (size_t i = 0; i < size; i++) {
        p += sprintf(p, "%.2x", bytearr[i]);
    }

    return outstr;
}

int main() {
    FILE* fp;
    char str[KEY_SIZE * 2 + 1];
    unsigned char key[KEY_SIZE];

    // Open the text file for reading
    fp = fopen("key.txt", "r");
    if (fp == NULL) {
        perror("Error opening file");
        exit(1);
    }

    // Read the hexadecimal string from the file
    fgets(str, KEY_SIZE * 2 + 1, fp);

    // Convert the hexadecimal string to an unsigned char array
    for (int i = 0; i < KEY_SIZE; i++) {
        sscanf(str + 2 * i, "%2hhx", &key[i]);
    }

    // Close the text file
    fclose(fp);

    //print
    printf("The key is: ");
    for (int i = 0; i < KEY_SIZE; i++) {
        printf(" %d", key[i]);
    }
    printf("\n");
    printf("The key in hex is: ");
    for (int i = 0; i < KEY_SIZE; i++) {
        printf(" %02x", key[i]);
    }
    printf("\n");
    printf("The key in binary is: \n");
    for (int i = 0; i < KEY_SIZE; i++) {
        print_binary(key[i]);
    }

    //read from file binary
    unsigned char* buffer;
    int file_size, bytes_read;

    //open file in binary
    fp = fopen("key.txt", "rb");
    if (fp == NULL) {
        perror("Error opening file");
        exit(1);
    }
    
    // Get the size of the file
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    // Allocate memory for the buffer
    buffer = (unsigned char*)malloc(file_size * sizeof(unsigned char));

    // Read the data into the buffer
    bytes_read = fread(buffer, sizeof(unsigned char), file_size, fp);
    fclose(fp);

    //print in hex
    for (int i = 0; i < bytes_read; i++)
        printf("%02X ", buffer[i]);

    //use getHex to get hexa representation as string
    char* bin = getHex(buffer, bytes_read);
    printf("\n%s", bin);

    return 0;
}

