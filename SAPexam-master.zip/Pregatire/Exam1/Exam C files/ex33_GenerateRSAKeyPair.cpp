#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <malloc.h>
#include <openssl/applink.c>
#include <openssl/pem.h>
#include <openssl/rsa.h>


int main()
{
	RSA* rsaKP = NULL;

	rsaKP = RSA_new();
	rsaKP = RSA_generate_key(1024, 65535, NULL, NULL); //e = public exponent

	RSA_check_key(rsaKP);

	FILE* fpPriv = NULL;
	fopen_s(&fpPriv, "privKeySender.pem", "w+");
	PEM_write_RSAPrivateKey(fpPriv, rsaKP, NULL, NULL, 0, 0, NULL);
	fclose(fpPriv);

	FILE* fpPub = NULL;
	fopen_s(&fpPub, "pubKeySender.pem", "w+");
	PEM_write_RSAPublicKey(fpPub, rsaKP);
	fclose(fpPub);

	RSA_free(rsaKP);

	printf("\n The RSA key pair generated! \n");

	return 0;
}