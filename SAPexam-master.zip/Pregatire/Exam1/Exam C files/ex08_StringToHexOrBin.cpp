// StringToHex.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <string.h>

int main()
{
	unsigned char str[] = "7F808182ABAC";
	unsigned char str_new[] = "1234AABB";
	unsigned char str_bin[] = "1000110100000000100011010000000";
	unsigned char* ptr, pair[2];
	long int result;

	ptr = str;
	for (unsigned char i = 0; i < strlen((char*)str); i += 2)
	{
		memcpy(pair, ptr, 2);
		result = strtol((char*)pair, NULL, 16);
		printf(" %X", result);
		ptr += 2;
	}
	printf("\n");
	result = strtol((char*)str_new, NULL, 16); // in order to fit the length of result, 
	// the input string must be max 8 bytes as hexadecimal pairs
	printf("%X", result);
	printf("\n");
	result = strtol((char*)str_bin, NULL, 2);
	printf("%d", result);
}
