#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <malloc.h>
#include <memory.h>
#include <openssl/applink.c>
#include <openssl/pem.h>
#include <openssl/rsa.h>
#include <openssl/sha.h>

int main(int argc, char** argv)
{
	FILE* plainTextFile;
	char publicKeyFileName[] = "pubKeySender.pem";
	char signatureFileName[] = "RSASign.sig";
	char plainTextFileName[] = "ignis-10M.txt";

	//Compute message digest for plaintext file
	unsigned char* fileBuffer = NULL;

	//open plaintext file
	fopen_s(&plainTextFile, plainTextFileName, "rb");
	if (plainTextFile == NULL) {
		printf("\nPlain text file not found!");
		return 1;
	}
	//get file length
	fseek(plainTextFile, 0, SEEK_END);
	int fileLen = ftell(plainTextFile);
	fseek(plainTextFile, 0, SEEK_SET);

	//initialize the buffer
	fileBuffer = (unsigned char*)malloc(fileLen);
	fread(fileBuffer, fileLen, 1, plainTextFile);
	unsigned char* tmpBuffer = fileBuffer;

	//compute the SHA256
	unsigned char finalDigest[SHA256_DIGEST_LENGTH];
	SHA256_CTX ctx;
	SHA256_Init(&ctx);

	while (fileLen > 0) {
		if (fileLen > SHA256_DIGEST_LENGTH)
			SHA256_Update(&ctx, tmpBuffer, SHA256_DIGEST_LENGTH);
		else
			SHA256_Update(&ctx, tmpBuffer, fileLen);
		fileLen -= SHA256_DIGEST_LENGTH;
		tmpBuffer += SHA256_DIGEST_LENGTH;
	}
	SHA256_Final(finalDigest, &ctx);
	fclose(plainTextFile);
	free(fileBuffer);

	//Display the message digest
	printf("SHA256 content of file:\n");
	for (int i = 0; i < SHA256_DIGEST_LENGTH; i++)
		printf("%2X ", finalDigest[i]);
	printf("\n");
	
	//Decrypt signature and compare with previously computed message digest
	//Open signature file
	FILE* signedFile;
	fopen_s(&signedFile, signatureFileName, "rb");
	if (signedFile == NULL) {
		printf("\nSigned file not found!");
		return 1;
	}

	//Open public key file
	FILE* publicKeyFile;
	fopen_s(&publicKeyFile, publicKeyFileName, "r");
	if (publicKeyFile == NULL) {
		printf("\nPublic key not found!");
		return 1;
	}

	//Compute RSA
	RSA* rsa = RSA_new();
	unsigned char* buffer = NULL;
	unsigned char* last_data = NULL;

	//Add public key
	rsa = PEM_read_RSAPublicKey(publicKeyFile, NULL, NULL, NULL);
	fclose(publicKeyFile);
	buffer = (unsigned char*)malloc(RSA_size(rsa));
	fread(buffer, RSA_size(rsa), 1, signedFile);
	last_data = (unsigned char*)malloc(SHA256_DIGEST_LENGTH);
	RSA_public_decrypt(RSA_size(rsa), buffer, last_data, rsa, RSA_PKCS1_PADDING);
	fclose(signedFile);

	//Display decrypted content
	printf("SHA256 decrypted content of %s:\n", signatureFileName);
	for (int i = 0; i < SHA256_DIGEST_LENGTH; i++)
		printf("%2X ", last_data[i]);
	printf("\n");

	if (memcmp(last_data, finalDigest, SHA256_DIGEST_LENGTH) == 0)
		printf("\nSignature OK!\n");
	else
		printf("\nSignature is wrong!\n");

	free(buffer);
	free(last_data);
	RSA_free(rsa);

	return 0;
}