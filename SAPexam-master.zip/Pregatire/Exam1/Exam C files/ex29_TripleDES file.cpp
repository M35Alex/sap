#define _CRT_SECURE_NO_WARNINGS
#include <openssl/des.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int encrypt_file() {
    int n, padding_len;
    FILE* fd_in, *fd_out;
    unsigned char buf[8], buf_out[8];
    DES_cblock key1, key2, key3;
    DES_key_schedule ks1, ks2, ks3;
    //DES_cblock iv = { 0, 0, 0, 0, 0, 0, 0, 0 }; //needed for cbc

    // Open input and output files
    fd_in = fopen("input.txt", "rb");
    fd_out = fopen("ciphertext.txt", "w");

    if (fd_in == NULL) { fputs("File error", stderr); exit(1); }
    if (fd_out == NULL) { fputs("File error", stderr); exit(1); }

    // Set the encryption keys
    DES_string_to_key("Key1", &key1);
    DES_string_to_key("Key2", &key2);
    DES_string_to_key("Key3", &key3);
    DES_set_key((C_Block*)key1, &ks1);
    DES_set_key((C_Block*)key2, &ks2);
    DES_set_key((C_Block*)key3, &ks3);

    if (-2 == (DES_set_key_checked(&key1, &ks1) || DES_set_key_checked(&key2, &ks2) || DES_set_key_checked(&key3, &ks3)))
    {
        printf(" Weak key ....\n");
        return 1;
    }

    // Read 8 bytes at a time from the input file, encrypt them, and write to the output file
    while ((n = fread(buf,1, 8, fd_in)) > 0) {
        if (n < 8) {
            padding_len = 8 - n;
            memset(buf + n, padding_len, padding_len);
            n = 8;
        }
        //DES_ede3_cbc_encrypt(buf, buf_out,n, &ks1, &ks2, &ks3, &iv, DES_ENCRYPT);
        DES_ecb3_encrypt((C_Block*)buf, (C_Block*)buf_out, &ks1, &ks2, &ks3, DES_ENCRYPT);
        fwrite(buf_out, 1, 8, fd_out);
    }

    // Close the input and output files
    fclose(fd_in);
    fclose(fd_out);

    return 0;
}
int decrypt_file() {
    int n, padding_len;
    FILE* fd_in, *fd_out;
    unsigned char buf[8], buf_out[8];
    DES_cblock key1, key2, key3;
    DES_key_schedule ks1, ks2, ks3;
    DES_cblock iv = { 0, 0, 0, 0, 0, 0, 0, 0 };

    // Open input and output files
    fd_in = fopen("ciphertext.txt", "rb");
    fd_out = fopen("recovered.txt", "w");

    if (fd_in == NULL) { fputs("File error", stderr); exit(1); }
    if (fd_out == NULL) { fputs("File error", stderr); exit(1); }

    // Set the encryption keys
    DES_string_to_key("Key1", &key1);
    DES_string_to_key("Key2", &key2);
    DES_string_to_key("Key3", &key3);
    DES_set_key((C_Block*)key1, &ks1);
    DES_set_key((C_Block*)key2, &ks2);
    DES_set_key((C_Block*)key3, &ks3);

    // Read 8 bytes at a time from the input file, decrypt them, and write to the output file
    while ((n = fread(buf,1, 8, fd_in)) > 0) {
        //DES_ede3_cbc_encrypt(buf, buf_out, n, &ks1, &ks2, &ks3, &iv, DES_DECRYPT);
        DES_ecb3_encrypt((C_Block*)buf, (C_Block*)buf_out, &ks1, &ks2, &ks3, DES_DECRYPT);

        // Remove PKCS#7 padding
        padding_len = buf_out[7];
        if (padding_len < 8 && padding_len > 0) {
            n = 8 - padding_len;
        }

        fwrite(buf_out,1, n, fd_out);
    }

    // Close the input and output files
    fclose(fd_in);
    fclose(fd_out);

    return 0;
}
int main() {
    
    encrypt_file();
    decrypt_file();
    return 0;
}