#define _CRT_SECURE_NO_WARNINGS
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/bio.h>
#include <openssl/sha.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cctype>


char* byteArrayToChar(unsigned char* input, int inputSize) {
	char* output;
	char* hexaDeciNum;
	output = (char*)malloc(inputSize * 4 - 4); //*2 because each byte is reprezented by 2 characters
	for (int i = 0; i < inputSize * 2 - 2; i++)
	{
		int byteOfI = int(input[i]);

		hexaDeciNum = (char*)malloc(2 * sizeof(char));
		//reset hexaDeciNum
		hexaDeciNum[0] = '0';
		hexaDeciNum[1] = '0';


		int counter = 0;
		while (byteOfI != 0) {

			// temporary variable to store remainder
			int temp = 0;

			// storing remainder in temp variable.
			temp = byteOfI % 16;

			// check if temp < 10
			if (temp < 10) {
				hexaDeciNum[counter] = (char)(temp + 48);
				counter++;
			}
			else {
				hexaDeciNum[counter] = (char)(temp + 55);
				counter++;
			}
			byteOfI = byteOfI / 16;
		}
		output[i * 2] = hexaDeciNum[1];
		output[i * 2 + 1] = hexaDeciNum[0];
		free(hexaDeciNum);
	}
	return output;
}

unsigned char* sha256(unsigned char* tmpBuffer, int size) {
	unsigned char* finalDigestsha256;//[SHA_DIGEST_LENGTH]
	finalDigestsha256 = (unsigned char*)malloc(SHA256_DIGEST_LENGTH * sizeof(unsigned char));
	SHA256_CTX ctx;
	SHA256_Init(&ctx);
	SHA256_Update(&ctx, tmpBuffer, size);
	SHA256_Final(finalDigestsha256, &ctx);
	return finalDigestsha256;
}

int main() {

	FILE* passFile;
	FILE* outFile;
	passFile = fopen("wordlist.txt", "r");
	outFile = fopen("hashes.txt", "wb");

	if (passFile == NULL) {
		printf("Pass file not found!");
		return 1;
	}

	fseek(passFile, 0, SEEK_END);
	int fileLen = ftell(passFile);
	fseek(passFile, 0, SEEK_SET);


	char line[50];
	char* linePointer;
	unsigned char* linePointerUnsigned;
	long long int counter = 0x0000000000000000;
	while (fgets(line, sizeof(line), passFile)) {
		counter++;
		printf("%s", line);


		linePointer = (char*)malloc(strlen(line) - 1 * sizeof(char));
		strncpy(linePointer, line, strlen(line) - 1);

		linePointerUnsigned = (unsigned char*)malloc(strlen(line) - 1 * sizeof(unsigned char));
		linePointerUnsigned = (unsigned char*)linePointer;


		char* lineInHex;

		lineInHex = byteArrayToChar(linePointerUnsigned, strlen(line) - 1);

		int sizeOfLineInHex = (strlen(line) - 1) * 2;

		char* lineAfterConvertion = (char*)malloc(sizeOfLineInHex * sizeof(char));	//value i need
		strncpy(lineAfterConvertion, lineInHex, sizeOfLineInHex);

		char* counterToChar = (char*)malloc((8) * sizeof(char));
		strcpy(counterToChar, "");
		for (int i = 0; i < 16; i++) {
			strcat(counterToChar, "0");
		}
		char* finalcounter = (char*)malloc((8) * sizeof(char));


		//concat values
		char* finalInput = (char*)malloc((sizeOfLineInHex) * sizeof(char));
		strncpy(finalInput, lineAfterConvertion, sizeOfLineInHex);

		unsigned char* ceva = sha256((unsigned char*)finalInput, sizeOfLineInHex + 8);

		printf("%s", ceva);

		char* outText;
		outText = byteArrayToChar((unsigned char*)finalInput, sizeOfLineInHex + 8);
		fwrite(outText, sizeof(char), sizeOfLineInHex + 8, outFile);

	}

	fclose(passFile);
	fclose(outFile);

	return 0;
}
