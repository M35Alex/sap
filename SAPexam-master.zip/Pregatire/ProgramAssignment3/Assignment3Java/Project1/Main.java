import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.*;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

public class Main {

    public static String getHex(byte[]bytes){
        StringBuilder sb = new StringBuilder();
        for(byte value : bytes){
            sb.append(String.format("%02x", value).toLowerCase());
        }
        return sb.toString();
    }

    public static void main(String[] args) throws IOException, NoSuchAlgorithmException, CertificateException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        Boolean foundTheFile = Boolean.FALSE;
        int noOfCicles=0;
        while(!foundTheFile){
            //sha of file
            noOfCicles++;
            String nameOfFile = "SAPExamSubject"+noOfCicles+".txt";
            File examSubject = new File(nameOfFile);
            if(!examSubject.exists()){
                throw new FileNotFoundException("-----No SAPExamSubject"+noOfCicles+".txt Files!-----");
            }
            FileInputStream fis = new FileInputStream(examSubject);
            BufferedInputStream bis = new BufferedInputStream(fis);

            MessageDigest md = MessageDigest.getInstance("SHA-512");
            byte[] resultDigest = md.digest(bis.readAllBytes());

            fis.close();
            bis.close();

            //cert decryption
            File certFile = new File("SimplePGP_ISM.cer");
            if(!certFile.exists()){
                throw new FileNotFoundException("-----No certificate File!-----");
            }
            FileInputStream fis2 = new FileInputStream(certFile);
            CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
            X509Certificate certificate = (X509Certificate) certFactory.generateCertificate(fis2);
            PublicKey pubKey = certificate.getPublicKey();

            fis2.close();

            String nameOfFileSign = "SAPExamSubject"+noOfCicles+".signature";
            File examSubjectSign = new File(nameOfFileSign);
            if(!examSubjectSign.exists()){
                throw new FileNotFoundException("-----No SAPExamSubject"+noOfCicles+".signature Files!-----");
            }
            FileInputStream fis3 = new FileInputStream(examSubject);
            BufferedInputStream bis3 = new BufferedInputStream(fis3);

            Cipher cipher = Cipher.getInstance("RSA");
            cipher.init(Cipher.DECRYPT_MODE, pubKey);
            byte[] resultDecript;
            resultDecript = cipher.doFinal(bis3.readAllBytes());

            fis3.close();
            bis3.close();


            System.out.println(getHex(resultDigest));
            System.out.println(getHex(resultDecript));

        }
    }
}