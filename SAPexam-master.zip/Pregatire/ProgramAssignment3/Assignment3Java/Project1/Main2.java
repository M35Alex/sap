import javax.crypto.*;
import java.io.*;
import java.security.*;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

public class Main2 {

    public static String getHex(byte[]bytes){
        StringBuilder sb = new StringBuilder();
        for(byte value : bytes){
            sb.append(String.format("%02x", value).toLowerCase());
        }
        return sb.toString();
    }

    public static void main(String[] args) throws IOException, NoSuchAlgorithmException, CertificateException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, SignatureException, KeyStoreException, UnrecoverableKeyException {
        Boolean foundTheFile = Boolean.FALSE;
        int noOfCicles=0;
        while(!foundTheFile){
            noOfCicles++;
            String nameOfFile = "SAPExamSubject"+noOfCicles+".txt";
            File examSubject = new File(nameOfFile);
            if(!examSubject.exists()){
                throw new FileNotFoundException("-----No SAPExamSubject"+noOfCicles+".txt Files!-----");
            }
            FileInputStream fis3 = new FileInputStream(examSubject);
            byte[] originalFileContent = fis3.readAllBytes();

            File certFile = new File("SimplePGP_ISM.cer");
            if(!certFile.exists()){
                throw new FileNotFoundException("-----No certificate File!-----");
            }
            FileInputStream fis2 = new FileInputStream(certFile);
            CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
            X509Certificate certificate = (X509Certificate) certFactory.generateCertificate(fis2);
            PublicKey pubKey = certificate.getPublicKey();

            fis2.close();

            Signature signiture = Signature.getInstance("SHA512withRSA");
            signiture.initVerify(pubKey);
            signiture.update(originalFileContent);



            File signFile = new File("SAPExamSubject"+noOfCicles+".signature");
            FileInputStream sigFis = new FileInputStream(signFile);
            byte[] digitalSignature = sigFis.readAllBytes();
            fis2.close();
            fis3.close();
            sigFis.close();
            if(signiture.verify(digitalSignature)) {
                System.out.println("Message no."+noOfCicles+" is valid!");
                foundTheFile = Boolean.TRUE;
            }
        }

        KeyGenerator kg = KeyGenerator.getInstance("AES");
        kg.init(128);
        SecretKey key = kg.generateKey();

        File myFile = new File("DumitrescuCristianMihail.txt");
        if(!myFile.exists()){
            throw new FileNotFoundException("-----No My file!-----");
        }
        FileInputStream fis = new FileInputStream(myFile);
        BufferedInputStream bis = new BufferedInputStream(fis);


        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] resultEncript;
        resultEncript =cipher.doFinal(bis.readAllBytes());

        System.out.println(getHex(resultEncript));

        File myFileOut = new File("response.enc");
        FileOutputStream fosOut = new FileOutputStream(myFileOut);
        BufferedOutputStream bosOut = new BufferedOutputStream(fosOut);
        bosOut.write(resultEncript);

        bosOut.close();
        fis.close();
        bis.close();

//        File file = new File("cristikeystore.ks");
//        if(!file.exists()){
//            throw new FileNotFoundException("-----No keystore File!-----");
//        }
//
//        FileInputStream fis2 = new FileInputStream(file);
//
//        KeyStore ks = KeyStore.getInstance("pkcs12");
//        ks.load(fis2, "cristikeystorepass".toCharArray());
//
//        fis2.close();

        //PrivateKey privateKey = (PrivateKey) ks.getKey("cristialias", "cristikeystorepass".toCharArray());


        File certFile = new File("SimplePGP_ISM.cer");
        if(!certFile.exists()){
            throw new FileNotFoundException("-----No certificate File!-----");
        }
        FileInputStream fis2 = new FileInputStream(certFile);
        CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
        X509Certificate certificate = (X509Certificate) certFactory.generateCertificate(fis2);
        PublicKey pubKey = certificate.getPublicKey();


        Cipher cipher2 = Cipher.getInstance("RSA");
        cipher2.init(Cipher.ENCRYPT_MODE, pubKey);
        byte[] resultEncript2;
        resultEncript2 =cipher2.doFinal(key.getEncoded());

        System.out.println(getHex(resultEncript2));
        System.out.println(getHex(key.getEncoded()));

        File outputFile = new File("aes_key.sec");
        FileOutputStream fos = new FileOutputStream(outputFile);
        BufferedOutputStream bos = new BufferedOutputStream(fos);

        bos.write(resultEncript2);

        bos.close();
    }
}