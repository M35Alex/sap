import java.io.*;
import java.security.*;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.ShortBufferException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.plaf.synth.SynthSeparatorUI;

public class Main {

    // provided method for getting the public key from a X509 certificate file
    public static PublicKey getCertificateKey(String file) throws FileNotFoundException, CertificateException {
        FileInputStream fis = new FileInputStream(file);

        CertificateFactory factory = CertificateFactory.getInstance("X509");

        X509Certificate certificate = (X509Certificate) factory.generateCertificate(fis);

        return certificate.getPublicKey();
    }

    //provided method to print a byte array to console
    public static String getHex(byte[] array) {
        String output = "";
        for(byte value : array) {
            output += String.format("%02x", value);
        }
        return output;
    }


    // method for getting the private key from a keystore
    public static PrivateKey getPrivateKey(
            String keyStoreFileName,
            String keyStorePass,
            String keyAlias,
            String keyPass) throws KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException,
            UnrecoverableKeyException {

        File file = new File(keyStoreFileName);
        if(!file.exists()){
            throw new FileNotFoundException("-----No File!-----");
        }

        FileInputStream fis = new FileInputStream(file);

        KeyStore ks = KeyStore.getInstance("pkcs12");
        ks.load(fis, keyStorePass.toCharArray());

        fis.close();

        PrivateKey privateKey = (PrivateKey) ks.getKey(keyAlias, keyPass.toCharArray());

        return privateKey;
    }


    // method for computing the RSA digital signature
    public static void getDigitalSignature(
            String inputFileName,
            String signatureFileName,
            PrivateKey key)
            throws NoSuchAlgorithmException, InvalidKeyException, SignatureException, IOException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {

        //generate and store the RSA digital signature of the inputFileName file
        //store it in signatureFileName file
        File inputFile = new File(inputFileName);
        File signatureFile = new File(signatureFileName);

        FileInputStream fis = new FileInputStream(inputFile);
        BufferedInputStream bis = new BufferedInputStream(fis);

        FileOutputStream fos = new FileOutputStream(signatureFileName);
        BufferedOutputStream bos = new BufferedOutputStream(fos);

        Signature signature = Signature.getInstance("SHA256withRSA");
        signature.initSign(key);

        signature.update(bis.readAllBytes());

        byte[] result = signature.sign();
        bos.write(result);


        bis.close();
        bos.close();
    }


    //proposed function for generating the hash value
    public static byte[] getSHA1Hash(File file)
            throws NoSuchAlgorithmException, NoSuchProviderException, IOException {

        //generate the SHA-1 value of the received file
        MessageDigest md = MessageDigest.getInstance("SHA-1");
        FileInputStream fis = new FileInputStream(file);
        BufferedInputStream bis = new BufferedInputStream(fis);

        byte[] buffer = new byte[10];
        int noBytes = 0;

        while(noBytes!=-1){
            noBytes = bis.read(buffer);
            if(noBytes>0){
                //update
                //md.update(buffer);//buffer still has residual data
                //wrong
                md.update(buffer,0,noBytes);//to treat the last residual data
            }
        }
        bis.close();

        return md.digest();
    }

    //proposed function for decryption
    public static void decryptAESCBC(
            File inputFile,
            File outputFile,
            byte[] key)
            throws NoSuchAlgorithmException, NoSuchProviderException, NoSuchPaddingException, InvalidKeyException,
            InvalidAlgorithmParameterException, IllegalBlockSizeException, ShortBufferException, BadPaddingException,
            IOException {

        //decrypt the input file using AES in CBC
        //the file was encrypted without using padding - didn't need it
        FileInputStream fis = new FileInputStream(inputFile);
        BufferedInputStream bis = new BufferedInputStream(fis);

        FileOutputStream fos = new FileOutputStream(outputFile);
        BufferedOutputStream bos = new BufferedOutputStream(fos);


        Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
        byte[] iv = bis.readNBytes(cipher.getBlockSize());
        IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
        SecretKeySpec aesKey = new SecretKeySpec(key, "AES");
        cipher.init(Cipher.DECRYPT_MODE, aesKey, ivParameterSpec);
        //the IV is at the beginning of the input file
        byte[] message = cipher.doFinal(bis.readAllBytes());

        bos.write(message);
        bis.close();
        bos.close();
    }

    //proposed function for print the text file content
    public static void printTextFileContent(
            String textFileName) throws	IOException {

        //print the text file content on the console
        //you need to do this to get values for the next request
        File file = new File(textFileName);
        FileInputStream fis = new FileInputStream(file);
        BufferedInputStream bis = new BufferedInputStream(fis);

        byte[] content = bis.readAllBytes();

        System.out.println(getHex(content));
        System.out.println(new String(content));
        bis.close();
    }




    public static void main(String[] args) {
        try {


            /*
             *
             * @author - Please write your name here and also rename the class
             *
             *
             *
             */
            /*
             * Request 1
             */
            File passFile = new File("Passphrase.txt");
            byte[] hashValue = getSHA1Hash(passFile);
            System.out.println("SHA1: " + getHex(hashValue));


            //check point - you should get 268F10........


            /*
             * Request 2
             */

            //generate the key form previous hash
            byte[] key = new byte[16];
            for(int i=0;i<16;i++){
                key[i]=hashValue[i];
            }
       

            //decrypt the input file
            //there is no need for padding and the IV is written at the beginning of the file
            decryptAESCBC(new File("EncryptedData.data"), new File("OriginalData.txt"), key);


            printTextFileContent("OriginalData.txt");

            //get the keyStorePassword from OriginalMessage.txt. Copy and paste the values from the console
            String ksPassword = "you_already_made_it";
            String keyName = "sapexamkey";
            String keyPassword = "grant_access";

            /*
             * Request 3
             */


            //compute the RSA digital signature for the EncryptedMessage.cipher file and store it in the
            //	signature.ds file

            PrivateKey privKey = getPrivateKey("sap_exam_keystore.ks",ksPassword,keyName,keyPassword);
            getDigitalSignature("OriginalData.txt", "DataSignature.ds", privKey);


            //optionally - you can check if the signature is ok using the given SAPExamCertificate.cer
            //not mandatory
            //write code that checks the previous signature



            System.out.println("Done");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
