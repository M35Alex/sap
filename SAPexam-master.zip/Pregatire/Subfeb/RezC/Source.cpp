#define _CRT_SECURE_NO_WARNINGS
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/aes.h>
#include <openssl/bio.h>
#include <openssl/sha.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <cctype>


class Cipher {
	static unsigned char ALGO_AES_CBC;
	static unsigned char ALGO_RSA_PKCS1;
	static unsigned char MODE_ENCRYPT;
	static unsigned char MODE_DECRYPT;
	unsigned char algorithm;
public:
	Cipher() {
		this->algorithm = NULL;
	}
	Cipher(unsigned char algorithm) {
		this->algorithm = algorithm;
	}

	static Cipher create_instance(unsigned char algorithm) {
		Cipher* cipher = new Cipher(algorithm);
		return *cipher;
	}
};


class AESCBCCipher :public Cipher {

	AES_KEY aes_key;
	unsigned char ivec[16];

public:
	AESCBCCipher() : Cipher() {
	}
	AESCBCCipher(unsigned char algorithm) : Cipher(algorithm) {

	}

	void init_cipher(unsigned char* user_key,
		unsigned short int bit_key_length,
		unsigned short array_key_offset,
		unsigned char* iv, unsigned short
		array_iv_offset, unsigned char mode) {

	}

};

class RSACipher :public Cipher {
	RSA* rsa_key_pair;

public:
	RSACipher() :Cipher() {
	}
	RSACipher(unsigned char algorithm) :Cipher(algorithm) {

	}

	int generate_key_pair(int
		bit_modulus_length, unsigned
		long public_exp) {
		//	this->rsa_key_pair=ceva

		return 1;
	}

	unsigned char* public_encrypt(unsigned
		char* in_buffer, unsigned
		short byte_in_length,
		unsigned short in_offset,
		unsigned short*
		byte_out_length) {

	}
	
	~RSACipher() {

	}

};



int main() {

	unsigned char algorithm = NULL;

	Cipher cipher = Cipher::create_instance(algorithm);

	AESCBCCipher AESCBCCipher;
	AESCBCCipher.create_instance(algorithm);
	RSACipher RSACipher;
	RSACipher.create_instance(algorithm);

	unsigned char* user_key = nullptr;
	unsigned short int bit_key_length=NULL;
	unsigned short array_key_offset = NULL;
	unsigned char* iv= nullptr;
	unsigned short array_iv_offset = NULL;
	unsigned char mode = NULL;

	AESCBCCipher.init_cipher(user_key, bit_key_length, array_key_offset, iv, array_iv_offset, mode);


	int bit_modulus_length = NULL;
	unsigned long public_exp = NULL;
	int keyPair = RSACipher.generate_key_pair(bit_modulus_length, public_exp);

	return 1;

}