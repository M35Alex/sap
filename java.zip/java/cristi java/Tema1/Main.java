package DumitrescuCristianMihailTema1SAP;

import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;



public class Main {
    //Functions taken from the course (with small modifications to make them work on my use case)
    public static String getHex(byte[]bytes){
        StringBuilder sb = new StringBuilder();
        for(byte value : bytes){
            sb.append(String.format("%02x", value).toLowerCase());
        }
        return sb.toString();
    }

    public static byte[] getHashValueOfString(String value, String algorithm) throws NoSuchAlgorithmException {
        //call update, call digest
        //for a file we break it in 128bit length chunks update call
        MessageDigest md = MessageDigest.getInstance(algorithm);
        return md.digest(value.getBytes());
    }
    public static byte[] getHashValueOfByteArray(byte[] value, String algorithm) throws NoSuchAlgorithmException {
        //call update, call digest
        //for a file we break it in 128bit length chunks update call
        MessageDigest md = MessageDigest.getInstance(algorithm);
        return md.digest(value);
    }


    //Main function to solve problem
    //8920c4d0ee6d49a247d4c46b990cb626030a37e2865c8c03a43c1e50b5eb6a54 - digest I have to find
    public static void main(String[] args) throws IOException, NoSuchAlgorithmException {
        //Open file with all passwords and read one line.
        File passFile = new File("ignis-10M.txt");
        if(!passFile.exists()){
            throw new UnsupportedOperationException("File does not exist! Place ignis-10M.txt in the corresponding folder!");
        }
        FileReader fr = new FileReader(passFile);
        BufferedReader br = new BufferedReader(fr);

        long timeStart = System.currentTimeMillis();
        String line = br.readLine();
        boolean ok = false;
        while(line!=null && !ok) {
            //Process the line and printing the pass if it finds a match:
            //1. Add the padding of "ismsap" to the start of password
            String paddedLine = "ismsap" + line;

            //2. Hash the resulting pass with MD5
            byte[] resultingDigest = getHashValueOfString(paddedLine, "MD5");

            //3. Hash the resulting digest with SHA256
            resultingDigest = getHashValueOfByteArray(resultingDigest, "SHA-256");

            //4. Convert the resulting digest to the implicitly defined format ("hex values one after another")
            String digestFinal = getHex(resultingDigest);

            //5. Check if it is the same with "8920c4d0ee6d49a247d4c46b990cb626030a37e2865c8c03a43c1e50b5eb6a54"
            if(digestFinal.equals("8920c4d0ee6d49a247d4c46b990cb626030a37e2865c8c03a43c1e50b5eb6a54")){
                System.out.println(line);
                ok=true;
            }
            line = br.readLine();
        }
        br.close();
        long timeEnd = System.currentTimeMillis();

        System.out.println("Duration is : " + (timeEnd-timeStart) + " ms.");
    }
}