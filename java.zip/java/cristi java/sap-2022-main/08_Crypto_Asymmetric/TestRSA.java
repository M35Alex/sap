package ro.ase.ism.sap.day4;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SignatureException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.Arrays;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class TestRSA {

	public static void main(String[] args) throws KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException, UnrecoverableKeyException, InvalidKeyException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, SignatureException {
		
		KeyStore keyStore = KeyStoreManager.loadKeyStore(
				"ismkeystore.ks", "passks", "pkcs12");
		
		KeyStoreManager.listKeyStoreContent(keyStore);
		
		PublicKey ism1PubKey = 
				KeyStoreManager.getCertificateKey("ISMCertificateX509.cer");
		
		System.out.println("ISM1 key algorithm " + ism1PubKey.getAlgorithm());
		
		System.out.println("ISM1 Public Key: ");
		System.out.println(Util.getHex(ism1PubKey.getEncoded()));
		
		PublicKey ism1PubKeyFromKS = 
				KeyStoreManager.getKeyStorePublicKey(keyStore, "ismkey1");
		
		System.out.println("ISM1 Public Key from KS: ");
		System.out.println(Util.getHex(ism1PubKeyFromKS.getEncoded()));
		
		if(Arrays.equals(ism1PubKey.getEncoded(), ism1PubKeyFromKS.getEncoded()))
		{
			System.out.println("Identical keys");
		}
		
		PrivateKey ism1PrivKey = 
				KeyStoreManager.getKeyStorePrivateKey(keyStore, "ismkey1", "passks");
		System.out.println("ISM1 Private Key: ");
		System.out.println(Util.getHex(ism1PrivKey.getEncoded()));
		
		byte[] AESRandomSessionKey = Util.getRandomBytes(16, null);
		
		System.out.println("AES session key: ");
		System.out.println(Util.getHex(AESRandomSessionKey));
		
		
		byte[] encryptedSessionKey = RSACipher.encrypt(ism1PubKey, AESRandomSessionKey);
		
		System.out.println("Encrypted key");
		System.out.println(Util.getHex(encryptedSessionKey));
		
		byte[] decryptedSessionKey = RSACipher.decrypt(ism1PrivKey, encryptedSessionKey);
		

		if(Arrays.equals(AESRandomSessionKey, decryptedSessionKey))
		{
			System.out.println("Decrypted key is correct");
		} else 
		{
			System.out.println("Houston we have a problem");
		}
		
		byte[] digitalSignature = 
				RSACipher.generateDigitalSignature(
						"Message.txt", ism1PrivKey, "SHA256withRSA");
		
		System.out.println("Digital signature:");
		System.out.println(Util.getHex(digitalSignature));
		
		if(RSACipher.hasValidSignature(
				"Message.txt", ism1PubKeyFromKS, 
				digitalSignature, "SHA256withRSA"))
		{
			System.out.println("The message is valid");
		} 
		else {
			System.out.println("The message is NOT valid !!!!");
		}
				
	}

}
