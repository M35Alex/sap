package ro.ase.ism.sap.day4;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class RSACipher {
	
	public static byte[] encrypt(Key key, byte[] input) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {	
		Cipher cipher = Cipher.getInstance("RSA");
		cipher.init(Cipher.ENCRYPT_MODE, key);
		return cipher.doFinal(input);	
	}
	
	public static byte[] decrypt(Key key, byte[] cipherText) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {	
		Cipher cipher = Cipher.getInstance("RSA");
		cipher.init(Cipher.DECRYPT_MODE, key);
		return cipher.doFinal(cipherText);	
	}
	
	public static byte[] generateDigitalSignature(
			String filename, PrivateKey privateKey, String algorithm) throws IOException, NoSuchAlgorithmException, InvalidKeyException, SignatureException
	{
		File file = new File(filename);
		if(!file.exists()) {
			throw new FileNotFoundException();
		}
		
		FileInputStream fis = new FileInputStream(file);
		
		byte[] fileContent = fis.readAllBytes();
		
		fis.close();
		
		Signature signature = java.security.Signature.getInstance(algorithm);
		signature.initSign(privateKey);
		signature.update(fileContent);
		
		return signature.sign();
		
	}
	
	public static boolean hasValidSignature(
			String filename, PublicKey pubKey, 
			byte[] digitalSignature, String algorithm) throws IOException, NoSuchAlgorithmException, InvalidKeyException, SignatureException
	{
		File file = new File(filename);
		if(!file.exists()) {
			throw new FileNotFoundException();
		}
		
		FileInputStream fis = new FileInputStream(file);
		byte[] fileContent = fis.readAllBytes();
		fis.close();
		
		Signature signature = Signature.getInstance(algorithm);
		signature.initVerify(pubKey);
		
		signature.update(fileContent);
		return signature.verify(digitalSignature);
	}
	
	
	
	
}
