package ro.ase.ism.sap.day4;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Enumeration;

public class KeyStoreManager {

	
	public static KeyStore loadKeyStore(
			String keyStoreFilename,
			String keyStorePass,
			String keyStoreType
			) throws KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException {
		File file = new File(keyStoreFilename);
		if(!file.exists()) {
			throw new FileNotFoundException();
		}
		FileInputStream fis = new FileInputStream(file);
		
		KeyStore ks = KeyStore.getInstance(keyStoreType);
		ks.load(fis, keyStorePass.toCharArray());
		
		fis.close();
		return ks;
	}
	
	public static void listKeyStoreContent(KeyStore ks) throws KeyStoreException {
		System.out.println("Key store content:");
		Enumeration<String> aliases = ks.aliases();
		
		while(aliases.hasMoreElements()) {
			String alias = aliases.nextElement();
			System.out.println("Key store entry: " + alias);
			if(ks.isCertificateEntry(alias)) {
				System.out.println("Is public key - certificate");
			}
			if(ks.isKeyEntry(alias)) {
				System.out.println("Is a private - public pair");
			}
		}
	}
	
	public static PublicKey getCertificateKey(String x509CertificateFile) throws CertificateException, IOException {
		File file = new File(x509CertificateFile);
		if(!file.exists()) {
			throw new FileNotFoundException();
		}
		FileInputStream fis = new FileInputStream(file);
		
		CertificateFactory cerFactory = 
				CertificateFactory.getInstance("X.509");
		X509Certificate certificate = 
				(X509Certificate) cerFactory.generateCertificate(fis);
		fis.close();
		return certificate.getPublicKey();
		
	}
	
	public static PublicKey getKeyStorePublicKey(KeyStore keyStore, String alias) throws KeyStoreException {
		if(keyStore == null) {
			throw new UnsupportedOperationException();
		}
		if(keyStore.containsAlias(alias)) {
			return keyStore.getCertificate(alias).getPublicKey();
		} else
		{
			throw new UnsupportedOperationException();
		}
	}
	
	public static PrivateKey getKeyStorePrivateKey(
			KeyStore keyStore, String alias, String keyPass) throws UnrecoverableKeyException, KeyStoreException, NoSuchAlgorithmException
	{
		if(keyStore == null) {
			throw new UnsupportedOperationException();
		}
		if(keyStore.containsAlias(alias)) {
			return (PrivateKey) keyStore.getKey(alias,keyPass.toCharArray());
		} else
		{
			throw new UnsupportedOperationException();
		}
	}
	
}
