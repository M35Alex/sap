package ro.ase.ism.sap.day4;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

import javax.crypto.KeyGenerator;

public class Util {
	
	public static String getHex(byte[] value) {
		String output = "";
		for(byte byteValue : value) {
			output += String.format("%02x", byteValue);
		}
		return output;
	}
	
	public static byte[] getRandomBytes(int noBytes, byte[] seed) throws NoSuchAlgorithmException {
		SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
		if(seed != null) {
			secureRandom.setSeed(seed);
		}
		byte[] randomBytes = new byte[noBytes];
		secureRandom.nextBytes(randomBytes);
		
		return randomBytes;
	}
	
	public static byte[] getRandomSessionKey(String algorithm, int noBytes) throws NoSuchAlgorithmException {
		KeyGenerator keyGenerator = KeyGenerator.getInstance(algorithm);
		keyGenerator.init(noBytes);
		return keyGenerator.generateKey().getEncoded();
	}

}
