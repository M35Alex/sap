package ro.asm.ism.sap.day1;

import java.util.Base64;

public class Main {
    public static String getHex(byte[] value){
        StringBuffer sb = new StringBuffer();

        for(byte input:value){
            sb.append("0x"+String.format("%02x", input).toUpperCase());
            sb.append(" ");

        }
        return sb.toString();
    }


    public static void main(String[] args) {
        //recap bitwise operations
        //in java, a char is a 2 byte variable for extended ascii
        //in c, a char is 1 byte
        char character = 'a';   //2 byte variable
        //so we don't use chars because it creates confusion


        //string has a byte array
        //string can be made from byte array


        //in "Java" we have the byte type
        byte smallNumber = 23;  //in c/c++ we have a char

        //example
        String password = "password";
        byte[] passwordBytes = password.getBytes(); //size of 8 bytes
        //we will have the actual byte array (one byte array)
        //converts utf to ascii (basicly)

        System.out.print("The length of the password byte array is:");
        System.out.println(passwordBytes.length);

        String oldPassword = new String(passwordBytes); //convert back
        System.out.print("The initial password is:");
        System.out.println(oldPassword);

        //don't store anything as strings
        //because we lose some values
        //example

        byte passByte = 0x02;           //define val in hex
        byte passByte2 = 0b00000010;    //define val in bin

        byte[] binaryKey = {(byte)0b1000_0001, 0b0000_0010, 0b0000_0100, 0b0000_1000};
        byte[] binaryKey2 = {(byte)0x81, 0x02, 0x04, 0x08};
        String binaryKeyAsString = new String(binaryKey);       //DON'T DO THIS (WE LOSE THE VALUE) -> LOOK UP BASE64

        System.out.print("Binary key is:");
        System.out.println(binaryKeyAsString);
        System.out.print("Key size is:");
        System.out.println(binaryKeyAsString.length());

        byte[] initialKey = binaryKeyAsString.getBytes();
        if(initialKey[0] == binaryKey[0]){
            System.out.println("They are the same");
        }
        else{
            System.out.println("They are different");
        }

        //tldr: encoding(char shifting/replacement aka an algorithm) is not encryption(requires a key too)
        //base 64 encoding form binary strings as streams
        //takes 6 bits and is conv to an ascii character
        //this padds the ending
        //the safest way to store binary as text

        //they match every 6 bits value to a char

        //example
        String base64Key = Base64.getEncoder().encodeToString(binaryKey);
        System.out.print("The binary key as Base64 is :");
        System.out.println(base64Key);      //most base64 terminates with ==

        initialKey = Base64.getDecoder().decode(base64Key);
        if(initialKey[0] == binaryKey[0]){
            System.out.println("They are the same");
        }
        else{
            System.out.println("They are different");
        }
        //the way we communicate binary is base64!!!!!!!!!!!!!!!!!

        //encoding to print as hex
        //we need our own func
        byte[] someValues = {(byte)0b1111_1111, (byte)0xA3, 0x03, 0b0000_1111};
        System.out.println("The hex value is "+ String.format("0x%02x", someValues[0]).toUpperCase());


        System.out.println(getHex(someValues));

    }
}