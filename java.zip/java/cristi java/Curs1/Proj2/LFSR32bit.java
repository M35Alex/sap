package ro.ase.ism.sap.day1;

import java.util.ArrayList;
import java.util.List;

public class LFSR32bit {

    //32 bit LFSR with 1 register
    //tap seq: x^31+x^11+x^5+x^2
    //it needs and initial key/seed of 32 bits

    byte[] register = new byte[4];
    public LFSR32bit(byte[] seed) {
        if(seed.length!=4){
            throw new UnsupportedOperationException("Seed size not ok");
        }
        //this.register=seed; //don't do shallow coppy
        //or seed.clone();
        //or System.arraycopy(seed, 0, this.register, 0, register.length);
        for (int i = 0; i < register.length; i++) {
            this.register[i] = seed[i];
        }
    }

    public byte get31Bit(){
        byte mask31Bit = (byte) 0b1000_0000;
        byte result = (byte) (register[0] & mask31Bit);
        return (byte) (result==0?0:1);
    }

    public byte get11Bit(){
        byte mask11Bit = (byte) 0b0000_1000;
        byte result = (byte) (register[2] & mask11Bit);
        return (byte) (result==0?0:1);
    }

    public byte get5Bit(){
        byte mask5Bit = (byte) 0b0010_0000;
        byte result = (byte) (register[3] & mask5Bit);
        return (byte) (result==0?0:1);
    }

    public byte get2Bit(){
        byte mask2Bit = (byte) 0b0000_0100;
        byte result = (byte) (register[3] & mask2Bit);
        return (byte) (result==0?0:1);
    }

    private byte getLastBit(byte value){
        return (byte) (value & 1);
    }
    private byte shiftAndAddMostSignificatBit(byte value, byte bit){
        value = (byte) ((value&0xff)>>>1);
        return (byte) (value|(bit<<7));
    }

    private byte shiftRegister(byte bit){
//        byte lastBit = 0;
//        byte lastBitPrev = shiftAndAddMostSignificatBit(register[0],bit);
//        register[0] = (byte) (register[0]>>>1);
//        for(int i=1;i<register.length-1;i++){
//            lastBit = getLastBit(register[i]);
//            register[i] = shiftAndAddMostSignificatBit(register[i],lastBitPrev);
//            lastBitPrev=lastBit;
//        }
//        return lastBit;

        byte firstByteLastBit = getLastBit(register[0]);
        register[0]=shiftAndAddMostSignificatBit(register[0],bit);

        byte secondByteLastBit = getLastBit(register[1]);
        register[1]=shiftAndAddMostSignificatBit(register[1],firstByteLastBit);

        byte thirdByteLastBit = getLastBit(register[2]);
        register[2]=shiftAndAddMostSignificatBit(register[2],secondByteLastBit);

        byte forthByteLastBit = getLastBit(register[3]);
        register[3]=shiftAndAddMostSignificatBit(register[3],thirdByteLastBit);

        return forthByteLastBit;

    }
    public byte processTapSequence(){
        return (byte) (get31Bit()^ get11Bit()^ get5Bit()^ get2Bit());
    }

    public List<Byte> getRandomBits(int noBits){
        //we need to run 32 iterations to remove the seed;
        for(int i=0;i<32;i++){
            byte nextBit = processTapSequence();
            shiftRegister(nextBit);
        }
        List<Byte> randomBits = new ArrayList<>();
        for(int i=0;i<noBits;i++){
            byte nextBit = processTapSequence();
            randomBits.add(shiftRegister(nextBit));
        }
        return randomBits;
    }

}
