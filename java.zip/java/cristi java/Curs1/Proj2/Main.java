package ro.ase.ism.sap.day1;

import java.util.BitSet;
import java.util.List;

public class Main {


    public static String getHex(byte[] value){
        StringBuffer sb = new StringBuffer();

        for(byte input:value){
            sb.append("0x"+String.format("%02x", input).toUpperCase());
            sb.append(" ");

        }
        return sb.toString();
    }



    public static void main(String[] args) {
        int vb =10;
        if (vb==20){
            System.out.println("it's 20");
        }
        else {
            System.out.println("it's not");
        }

        if(vb!=10&&vb!=20){
            System.out.println("It's not 10 or 20");
        }

        //&& and || is made to not run if first(the one before) cond is false or true respectively
        if(vb!=20&&vb!=30&&(++vb)!=31) {
            System.out.println("it's not 20,30 or 31");
        }
        System.out.println(vb); //not here LOL

        //bitwise operatiors
        //vb is 11
        //check if vb has the 4th bit 1 (from left to right)
        //we must create a mask

        byte bitMaskForthBit = 0b0001_0000;
        System.out.println(bitMaskForthBit);

        bitMaskForthBit = 1<<4;//same thing (cuz of drawing not cuz of four)
        System.out.println(bitMaskForthBit);

        bitMaskForthBit = 16;
        System.out.println(bitMaskForthBit);

        if((bitMaskForthBit&vb)==0){
            System.out.println("The 4th bit in vb is 0");
        }
        else{
            System.out.println("The 4th bit in vb is 1");
        }

        //WRONG! THE INT is 4 bytes and the byte is 1 byte size. 4th value is from the 1st byte.
        //we need a mask on 32 bits or 4 bytes.

        //Correct way:
        int bitMask32BitsForthBit = 1<<(32-4);
        if((bitMask32BitsForthBit&vb)==0){
            System.out.println("The 4th bit in vb is 0");
        }
        else{
            System.out.println("The 4th bit in vb is 1");
        }

        //We don't get error on bit operations even in java


        // or(|) is used to combine masks
        byte bitMask2ndBit = 0b0100_0000;
        byte bitMask8thBit = 0b01;
        byte bitMask2ndadn8thBit = (byte) (bitMask2ndBit | bitMask8thBit);

        System.out.println(bitMask2ndadn8thBit);

        //shifting values with preserving sign bit or not!!!
        int value = 0x01;
        System.out.println(value);
        value = (byte) (value<<3);
        System.out.println(value);

        value = (byte) 0b1000_0001; //it preserves the sign
        System.out.println(value);
        value = value<<3;   //only works on integers(not on byte)
        System.out.println(value);

        byte value2 = 0x01;
        System.out.println(value2);
        value2 = (byte) (value<<3);
        System.out.println(value2);

        value2 = (byte) 0b1000_0001;
        System.out.println(value2);
        value2 = (byte) (value2<<3);   //we lost sign bit cuz int is too big
        System.out.println(value2);


        //right side shifting can be used to preserve sign bit with >>> or not with >>

        //conclusion: dont convert too much!

        value = 0x800000FF;
        System.out.println("Decimal:" + value);
        System.out.println("Hex:" + Integer.toHexString(value));
        value=value>>1;
        System.out.println("Decimal:" + value);
        System.out.println("Hex:" + Integer.toHexString(value));

        value=value>>>1;
        System.out.println("Decimal:" + value);
        System.out.println("Hex:" + Integer.toHexString(value));

        //PRGN with tap sequence:
        //x31,x11,x5,x2
        //right to left:
        //1,21,27,30


        //test lfsr
        LFSR32bit lfsr32bit = new LFSR32bit(new byte[]{(byte) 0x00, (byte) 0xFF, (byte) 0x08, (byte) 0xFF});
        List<Byte> randomBits1 = lfsr32bit.getRandomBits(32);

        System.out.println(randomBits1);


        //alternative to byte array or boolean array or integer :)
        BitSet register = new BitSet(32);
        register.set(0);
        System.out.println("The first bit is " + register.get(0));
        register.clear(0);
        System.out.println("The first bit is " + register.get(0));



    }
}