package ro.ase.ism.day1;

import java.util.Arrays;

public class Certificate implements Cloneable {    //no more problems
    String name;
    int version;
    String[] authorities = {"Google", "Amazon", "Cloudflare", "Mielu"};

    public Certificate(String name, int version) {
        this.name = name;
        this.version = version;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    //not ok based on shallowCopy
    public String[] getAuthorities() {
        //eturn authorities;
        return authorities.clone();             //no more problems
    }

    public void setAuthorities(String[] authorities) {
        //this.authorities = authorities;
        this.authorities = authorities.clone(); //no more problems
    }

    @Override
    public String toString() {
        return "Certificate{" +
                "name='" + name + '\'' +
                ", version=" + version +
                ", authorities=" + Arrays.toString(authorities) +
                '}';
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        Certificate copy = new Certificate(name, version);
        copy.authorities = this.authorities.clone();
        return copy;
        //return super.clone();
    }
}
