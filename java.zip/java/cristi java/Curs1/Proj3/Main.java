package ro.ase.ism.day1;

public class Main {
    public static void main(String[] args) throws CloneNotSupportedException {
        Certificate certificate = new Certificate("ISM", 1);

        System.out.println(certificate.toString());

        //problem with "ShallowCopy"
        String[] cas = certificate.getAuthorities();
        cas[0]="MieluMeu";
        System.out.println(certificate.toString());

        String[] newAuthorities = {"VeriMiel"};
        certificate.setAuthorities(newAuthorities);
        System.out.println(certificate.toString());

        newAuthorities[0]= "NoMoreMielu";
        System.out.println(certificate.toString());


        //clone the certificate
        Certificate copy = (Certificate) certificate.clone();
        System.out.println(copy.toString());

        newAuthorities = new String[]{"VeriMiel2"};
        certificate.setAuthorities(newAuthorities);
        System.out.println(certificate.toString());
        System.out.println(copy.toString());

    }
}