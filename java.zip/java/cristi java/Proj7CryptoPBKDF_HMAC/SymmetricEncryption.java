package ro.ase.ism.sap.day3;

import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

public class SymmetricEncryption {
    public static void encryptECB(String inputFile, String key, String algorithm, String cipherFile) throws NoSuchPaddingException, NoSuchAlgorithmException, IOException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        //If the messages have size = block size, then we can choose NoPadding
        //PKCS5Padding just for des (block size 64 bites)
        File input = new File(inputFile);
        if (!input.exists()){
            throw new FileNotFoundException();
        }
        FileInputStream fis = new FileInputStream(input);
        BufferedInputStream bis = new BufferedInputStream(fis);

        File output = new File(cipherFile);
        if (!output.exists()){
           output.createNewFile();
        }

        FileOutputStream fos = new FileOutputStream(output);
        BufferedOutputStream bos = new BufferedOutputStream(fos);

        Cipher ci = Cipher.getInstance(algorithm + "/ECB/PKCS5Padding");//"AES/CBC/PKCS5Padding"
        SecretKeySpec keySpec = new SecretKeySpec(key.getBytes(), algorithm);
        ci.init(Cipher.ENCRYPT_MODE, keySpec);//cript or decript?


        byte[] buffer = new byte[ci.getBlockSize()];
        byte[] cipherBuffer;
        int noBytes=0;

        while(noBytes!=-1){
            noBytes=bis.read(buffer);
            if(noBytes!=-1) {
                cipherBuffer=ci.update(buffer, 0, noBytes);
                bos.write(cipherBuffer);
            }
        }

        cipherBuffer = ci.doFinal();

        bos.write(cipherBuffer);

        bis.close();
        bos.close();
    }
    public static void decryptECB(String cipherFile, String key, String algorithm, String plainFile) throws NoSuchPaddingException, NoSuchAlgorithmException, IOException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        //If the messages have size = block size, then we can choose NoPadding
        //PKCS5Padding just for des (block size 64 bites)
        File input = new File(cipherFile);
        if (!input.exists()){
            throw new FileNotFoundException();
        }
        FileInputStream fis = new FileInputStream(input);
        BufferedInputStream bis = new BufferedInputStream(fis);

        File output = new File(plainFile);
        if (!output.exists()){
            output.createNewFile();
        }

        FileOutputStream fos = new FileOutputStream(output);
        BufferedOutputStream bos = new BufferedOutputStream(fos);

        Cipher ci = Cipher.getInstance(algorithm + "/ECB/PKCS5Padding");//"AES/CBC/PKCS5Padding"
        SecretKeySpec keySpec = new SecretKeySpec(key.getBytes(), algorithm);
        ci.init(Cipher.DECRYPT_MODE, keySpec);//cript or decript?


        byte[] buffer = new byte[ci.getBlockSize()];
        byte[] cipherBuffer;
        int noBytes=0;

        while(noBytes!=-1){
            noBytes=bis.read(buffer);
            if(noBytes!=-1) {
                cipherBuffer=ci.update(buffer, 0, noBytes);
                bos.write(cipherBuffer);
            }
        }

        cipherBuffer = ci.doFinal();

        bos.write(cipherBuffer);

        bis.close();
        bos.close();
    }

    //we need iv for the rest
    public static void encryptCBC(String inputFile, String key, String algorithm, String cipherFile) throws NoSuchPaddingException, NoSuchAlgorithmException, IOException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
        //If the messages have size = block size, then we can choose NoPadding
        //PKCS5Padding just for des (block size 64 bites)
        File input = new File(inputFile);
        if (!input.exists()){
            throw new FileNotFoundException();
        }
        FileInputStream fis = new FileInputStream(input);
        BufferedInputStream bis = new BufferedInputStream(fis);

        File output = new File(cipherFile);
        if (!output.exists()){
            output.createNewFile();
        }

        FileOutputStream fos = new FileOutputStream(output);
        BufferedOutputStream bos = new BufferedOutputStream(fos);

        Cipher ci = Cipher.getInstance(algorithm + "/CBC/PKCS5Padding");//"AES/CBC/PKCS5Padding"
        SecretKeySpec keySpec = new SecretKeySpec(key.getBytes(), algorithm);

        //generate a new random iv for each encription
        SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
        byte[] iv = secureRandom.generateSeed(ci.getBlockSize());
        IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
        //write iv in the cipher file
        bos.write(iv);

        ci.init(Cipher.ENCRYPT_MODE, keySpec, ivParameterSpec);//cript or decript?

        byte[] buffer = new byte[ci.getBlockSize()];
        byte[] cipherBuffer;
        int noBytes=0;

        while(noBytes!=-1){
            noBytes=bis.read(buffer);
            if(noBytes!=-1) {
                cipherBuffer=ci.update(buffer, 0, noBytes);
                bos.write(cipherBuffer);
            }
        }

        cipherBuffer = ci.doFinal();

        bos.write(cipherBuffer);

        bis.close();
        bos.close();
    }
    public static void decryptCBC(String cipherFile, String key, String algorithm, String plainFile) throws NoSuchPaddingException, NoSuchAlgorithmException, IOException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
        //If the messages have size = block size, then we can choose NoPadding
        //PKCS5Padding just for des (block size 64 bites)
        File input = new File(cipherFile);
        if (!input.exists()){
            throw new FileNotFoundException();
        }
        FileInputStream fis = new FileInputStream(input);
        BufferedInputStream bis = new BufferedInputStream(fis);

        File output = new File(plainFile);
        if (!output.exists()){
            output.createNewFile();
        }

        FileOutputStream fos = new FileOutputStream(output);
        BufferedOutputStream bos = new BufferedOutputStream(fos);

        Cipher ci = Cipher.getInstance(algorithm + "/CBC/PKCS5Padding");//"AES/CBC/PKCS5Padding"
        SecretKeySpec keySpec = new SecretKeySpec(key.getBytes(), algorithm);


        byte[] iv = new byte[ci.getBlockSize()];
        bis.read(iv);
        IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);

        ci.init(Cipher.DECRYPT_MODE, keySpec, ivParameterSpec);//cript or decript?


        byte[] buffer = new byte[ci.getBlockSize()];
        byte[] cipherBuffer;
        int noBytes=0;

        while(noBytes!=-1){
            noBytes=bis.read(buffer);
            if(noBytes!=-1) {
                cipherBuffer=ci.update(buffer, 0, noBytes);
                bos.write(cipherBuffer);
            }
        }

        cipherBuffer = ci.doFinal();

        bos.write(cipherBuffer);

        bis.close();
        bos.close();
    }

    public static void encryptCTR(String inputFile, String key, String algorithm, String cipherFile) throws NoSuchPaddingException, NoSuchAlgorithmException, IOException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
        //If the messages have size = block size, then we can choose NoPadding
        //PKCS5Padding just for des (block size 64 bites)
        File input = new File(inputFile);
        if (!input.exists()){
            throw new FileNotFoundException();
        }
        FileInputStream fis = new FileInputStream(input);
        BufferedInputStream bis = new BufferedInputStream(fis);

        File output = new File(cipherFile);
        if (!output.exists()){
            output.createNewFile();
        }

        FileOutputStream fos = new FileOutputStream(output);
        BufferedOutputStream bos = new BufferedOutputStream(fos);

        Cipher ci = Cipher.getInstance(algorithm + "/CTR/NoPadding");//nu avem nev de padding

        //define counter initial value (look into pdf at crypto)
        //similar to iv
        byte[] counterInitialValue = new byte[ci.getBlockSize()];
        counterInitialValue[counterInitialValue.length-1] = (byte) 0xff;//our choice
        IvParameterSpec ivParameterSpec = new IvParameterSpec(counterInitialValue);


        SecretKeySpec keySpec = new SecretKeySpec(key.getBytes(), algorithm);
        ci.init(Cipher.ENCRYPT_MODE, keySpec, ivParameterSpec);//cript or decript?


        byte[] buffer = new byte[ci.getBlockSize()];
        byte[] cipherBuffer;
        int noBytes=0;

        while(noBytes!=-1){
            noBytes=bis.read(buffer);
            if(noBytes!=-1) {
                cipherBuffer=ci.update(buffer, 0, noBytes);
                bos.write(cipherBuffer);
            }
        }

        cipherBuffer = ci.doFinal();

        bos.write(cipherBuffer);

        bis.close();
        bos.close();
    }
    public static void decryptCTR(String cipherFile, String key, String algorithm, String plainFile) throws NoSuchPaddingException, NoSuchAlgorithmException, IOException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
        //If the messages have size = block size, then we can choose NoPadding
        //PKCS5Padding just for des (block size 64 bites)
        File input = new File(cipherFile);
        if (!input.exists()){
            throw new FileNotFoundException();
        }
        FileInputStream fis = new FileInputStream(input);
        BufferedInputStream bis = new BufferedInputStream(fis);

        File output = new File(plainFile);
        if (!output.exists()){
            output.createNewFile();
        }

        FileOutputStream fos = new FileOutputStream(output);
        BufferedOutputStream bos = new BufferedOutputStream(fos);

        Cipher ci = Cipher.getInstance(algorithm + "/CTR/NoPadding");//"AES/CBC/PKCS5Padding"
        //define counter initial value (look into pdf at crypto)
        //similar to iv
        byte[] counterInitialValue = new byte[ci.getBlockSize()];
        counterInitialValue[counterInitialValue.length-1] = (byte) 0xff;//our choice
        IvParameterSpec ivParameterSpec = new IvParameterSpec(counterInitialValue);

        SecretKeySpec keySpec = new SecretKeySpec(key.getBytes(), algorithm);
        ci.init(Cipher.DECRYPT_MODE, keySpec, ivParameterSpec);//cript or decript?


        byte[] buffer = new byte[ci.getBlockSize()];
        byte[] cipherBuffer;
        int noBytes=0;

        while(noBytes!=-1){
            noBytes=bis.read(buffer);
            if(noBytes!=-1) {
                cipherBuffer=ci.update(buffer, 0, noBytes);
                bos.write(cipherBuffer);
            }
        }

        cipherBuffer = ci.doFinal();

        bos.write(cipherBuffer);

        bis.close();
        bos.close();
    }

    //different but still need iv cuz its implemented in cbc mode
    public static void encryptCTS(String inputFile, String key, String algorithm, String cipherFile) throws NoSuchPaddingException, NoSuchAlgorithmException, IOException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
        //If the messages have size = block size, then we can choose NoPadding
        //PKCS5Padding just for des (block size 64 bites)
        File input = new File(inputFile);
        if (!input.exists()){
            throw new FileNotFoundException();
        }
        FileInputStream fis = new FileInputStream(input);
        BufferedInputStream bis = new BufferedInputStream(fis);

        File output = new File(cipherFile);
        if (!output.exists()){
            output.createNewFile();
        }

        FileOutputStream fos = new FileOutputStream(output);
        BufferedOutputStream bos = new BufferedOutputStream(fos);

        Cipher ci = Cipher.getInstance(algorithm + "/CTS/NoPadding");//"AES/CBC/PKCS5Padding"
        SecretKeySpec keySpec = new SecretKeySpec(key.getBytes(), algorithm);

        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[ci.getBlockSize()]);

        ci.init(Cipher.ENCRYPT_MODE, keySpec, ivParameterSpec);//cript or decript?


        byte[] buffer = new byte[ci.getBlockSize()];
        byte[] cipherBuffer;
        int noBytes=0;

        while(noBytes!=-1){
            noBytes=bis.read(buffer);
            if(noBytes!=-1) {
                cipherBuffer=ci.update(buffer, 0, noBytes);
                bos.write(cipherBuffer);
            }
        }

        cipherBuffer = ci.doFinal();

        bos.write(cipherBuffer);

        bis.close();
        bos.close();
    }
    public static void decryptCTS(String cipherFile, String key, String algorithm, String plainFile) throws NoSuchPaddingException, NoSuchAlgorithmException, IOException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
        //If the messages have size = block size, then we can choose NoPadding
        //PKCS5Padding just for des (block size 64 bites)
        File input = new File(cipherFile);
        if (!input.exists()){
            throw new FileNotFoundException();
        }
        FileInputStream fis = new FileInputStream(input);
        BufferedInputStream bis = new BufferedInputStream(fis);

        File output = new File(plainFile);
        if (!output.exists()){
            output.createNewFile();
        }

        FileOutputStream fos = new FileOutputStream(output);
        BufferedOutputStream bos = new BufferedOutputStream(fos);

        Cipher ci = Cipher.getInstance(algorithm + "/CTS/NoPadding");//"AES/CBC/PKCS5Padding"
        SecretKeySpec keySpec = new SecretKeySpec(key.getBytes(), algorithm);

        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[ci.getBlockSize()]);

        ci.init(Cipher.DECRYPT_MODE, keySpec, ivParameterSpec);//cript or decript?


        byte[] buffer = new byte[ci.getBlockSize()];
        byte[] cipherBuffer;
        int noBytes=0;

        while(noBytes!=-1){
            noBytes=bis.read(buffer);
            if(noBytes!=-1) {
                cipherBuffer=ci.update(buffer, 0, noBytes);
                bos.write(cipherBuffer);
            }
        }

        cipherBuffer = ci.doFinal();

        bos.write(cipherBuffer);

        bis.close();
        bos.close();
    }
}
