package ro.ase.ism.sap.day3;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;



public class Main {
    public static String getHex(byte[]bytes){
        StringBuilder sb = new StringBuilder();
        for(byte value : bytes){
            sb.append(String.format("%02xh ", value).toUpperCase());
        }
        return sb.toString();
    }

    public static void main(String[] args) throws NoSuchAlgorithmException, InvalidKeySpecException, InvalidKeyException, IOException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
        //Password Based Key Derivation Function doesn't apply to files.
        //Weka keys are thrown in "PBKDF" and the number of iterations is saved.
        //The func input is a string or byte[] and the output is a new key or a digest.

        String password = "12345678";
        String salt = "ismsap"; //(saved as base 64 or blob)
        double testStart = System.currentTimeMillis();
        byte[] generatedHash = PBKDF.getPBKDFvalue(password, salt.getBytes(),100000, "PBKDF2WithHmacSHA256", 160);//PBKDF2WithHmacSHA1
        double testEnd = System.currentTimeMillis();

        System.out.println("Hash is: " + getHex(generatedHash));
        System.out.println("Time for generation of hash: " + (testEnd-testStart));

        testStart = System.currentTimeMillis();
        generatedHash = SHA1.getDigest(password.getBytes());
        testEnd = System.currentTimeMillis();

        System.out.println("Hash is: " + getHex(generatedHash));
        System.out.println("Time for generation of hash: " + (testEnd-testStart));


        //HMAC
        //Ok for messages sent in clear text.
        String message = "Check ISM Schedule";
        testStart = System.currentTimeMillis();
        generatedHash = HMAC.getHMAC(message.getBytes(),"ismsecret","HmacSHA1");
        testEnd = System.currentTimeMillis();

        System.out.println("Hash is: " + getHex(generatedHash));
        System.out.println("Time for generation of hash: " + (testEnd-testStart));

        //HMAC on file
        testStart = System.currentTimeMillis();
        generatedHash = HMAC.getHMAC("aaa.txt", "ismsecret", "HmacSha1");
        testEnd = System.currentTimeMillis();

        System.out.println("Hash is: " + getHex(generatedHash));
        System.out.println("Time for generation of hash: " + (testEnd-testStart));

        //Symmetric encryption (same key)
        //ECB
        SymmetricEncryption.encryptECB("secretECB.txt", "passwordpassword", "AES","secretECB.enc");// key size=block size
        SymmetricEncryption.decryptECB("secretECB.enc", "passwordpassword", "AES","secretECB2.txt");

        //CBC
        SymmetricEncryption.encryptCBC("secretCBC.txt", "ism1pass", "DES","secretCBC.enc");
        SymmetricEncryption.decryptCBC("secretCBC.enc", "ism1pass", "DES","secretCBC2.txt");

        //CTR (block cipher ca un stream cipher)
        SymmetricEncryption.encryptCTR("secretCTR.txt", "passwordpassword", "AES","secretCTR.enc");
        SymmetricEncryption.decryptCTR("secretCTR.enc", "passwordpassword", "AES","secretCTR2.txt");

        //CTS (idea de "padding" cu block-ul penultim)
        SymmetricEncryption.encryptCTS("secretCTS.txt", "passwordpassword", "AES","secretCTS.enc");
        SymmetricEncryption.decryptCTS("secretCTS.enc", "passwordpassword", "AES","secretCTS2.txt");
    }
}