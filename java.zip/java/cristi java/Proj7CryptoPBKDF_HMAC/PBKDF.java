package ro.ase.ism.sap.day3;

import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

public class PBKDF {
    public static byte[] getPBKDFvalue(String password, byte[] salt, int noIterations, String algorithm, int outputSize) throws NoSuchAlgorithmException, InvalidKeySpecException {
        //We use Secret key Factory class
        SecretKeyFactory pbkdfFactory = SecretKeyFactory.getInstance(algorithm);
        //We use PBEKeySpec to mention the specifications of the algorithm
        PBEKeySpec pbkdfSpecification = new PBEKeySpec(password.toCharArray(),salt,noIterations, outputSize);

        //We run the algorithm
        SecretKey generatedKey = pbkdfFactory.generateSecret(pbkdfSpecification);

        return generatedKey.getEncoded();
    }
}
