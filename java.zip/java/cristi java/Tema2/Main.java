package Dumitrescu.Cristian.ism.sap;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public class Main {
    public static byte[] getHMAC(String fileName, String key, String algorithm) throws IOException, NoSuchAlgorithmException, InvalidKeyException {
        File file = new File(fileName);
        FileInputStream fis = new FileInputStream(file);
        BufferedInputStream bis = new BufferedInputStream(fis);

        Mac mac = Mac.getInstance(algorithm);
        mac.init(new SecretKeySpec(key.getBytes(), algorithm));

        byte[] buffer = new byte[10];
        int noBytes = 0;

        while (noBytes != -1) {
            noBytes = bis.read(buffer);
            if (noBytes != -1)
                mac.update(buffer, 0, noBytes);
        }
        bis.close();
        return mac.doFinal();
    }

    public static String getHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte value : bytes) {
            sb.append(String.format("%02x", value).toUpperCase());
        }
        return sb.toString();
    }

    private static void scanFiles(File root, BufferedOutputStream outputStream, int noTabs, String key) throws IOException, NoSuchAlgorithmException, InvalidKeyException {
        //Get list of subdirectories
        File[] list = root.listFiles();
        if (list != null && list.length != 0) {
            for (File file : list) {
                if (file.isDirectory()) {
                    //Output directory name to outputFile
                    StringBuilder output = new StringBuilder();
                    for (int i = 0; i < noTabs; i++) {
                        output.append("   ");
                    }
                    output.append(file.getName() + ":\n");
                    System.out.print(output);
                    outputStream.write(output.toString().getBytes());

                    //Scan depth first
                    scanFiles(file, outputStream, noTabs + 1, key);
                } else if (file.isFile()) {
                    //Output file name to outputFile
                    StringBuilder output = new StringBuilder();
                    for (int i = 0; i < noTabs; i++) {
                        output.append("   ");
                    }
                    output.append(file.getName() + "_");
                    System.out.print(output);
                    outputStream.write(output.toString().getBytes());

                    //Calculate digest for the contents of the file
                    byte[] digest = getHMAC(file.getAbsolutePath(), key, "HmacSHA256");
                    String digestString = getHex(digest);
                    //Output-ing the value as hex to console and "integrity.txt"
                    StringBuilder output2 = new StringBuilder();
                    output2.append(digestString + "\n");
                    System.out.print(output2);
                    outputStream.write(output2.toString().getBytes());
                }
            }
        }
    }

    static boolean shouldReadNextLine = true;
    static String savedLine = "";
    static boolean shouldReadNextFile = true;
    static File savedlFile = null;

    private static void checkFiles(File root, BufferedReader inputReader, int noTabs, String key) throws IOException, NoSuchAlgorithmException, InvalidKeyException {
        //Get list of subdirectories
        File[] list = root.listFiles();


        if (list != null && list.length != 0) {
            for (int f = 0; f < list.length || !shouldReadNextFile; f++) {
                //read all elements from file only if condition is met
                File file;
                if (!shouldReadNextFile) {
                    file = savedlFile;
                    f--;
                } else {
                    file = list[f];
                }

                //Revelation: files are in alphabetical order
                //we can compare file name to what is in the inputFile
                String fileName = file.getName();

                //Read next line if we have to
                String line = savedLine;
                if (shouldReadNextLine) {
                    line = inputReader.readLine();
                }
                shouldReadNextLine = true;
                shouldReadNextFile = true;

                //compare strings at char level
                if (file.isDirectory()) {
                    try {
                        String lineWithNoAddedThings = line.substring(0, line.indexOf(':'));
                        StringBuilder fileConcatTabs = new StringBuilder();
                        for (int i = 0; i < noTabs; i++) {
                            fileConcatTabs.append("   ");
                        }
                        String fileWithAddedTabs = fileConcatTabs.append(fileName).toString();

                        char[] first = lineWithNoAddedThings.toLowerCase().toCharArray();
                        char[] second = fileWithAddedTabs.toLowerCase().toCharArray();
                        int minLength = Math.min(first.length, second.length);
                        boolean didWeFindMissmatch = false;
                        boolean missmatchLowerOrHigher = true;//false=lower value of file input then what was saved aka new file in front; true=higher value of file input then what was saved aka new file after
                        for (int i = 0; i < minLength && !didWeFindMissmatch; i++) {
                            if (first[i] < second[i]) {
                                didWeFindMissmatch = true;
                                missmatchLowerOrHigher = true;
                            }
                            if (first[i] > second[i]) {
                                didWeFindMissmatch = true;
                                missmatchLowerOrHigher = false;
                            }
                        }
                        if (!didWeFindMissmatch) {
                            StringBuilder output = new StringBuilder();
                            for (int i = 0; i < noTabs; i++) {
                                output.append("   ");
                            }
                            output.append(file.getName() + ": OK\n");
                            System.out.print(output);

                            //Checks files into ok directory
                            checkFiles(file, inputReader, noTabs + 1, key);
                        } else {
                            //should read next file but not read next line
                            if (missmatchLowerOrHigher == Boolean.FALSE) {
                                StringBuilder output = new StringBuilder();
                                for (int i = 0; i < noTabs; i++) {
                                    output.append("   ");
                                }
                                output.append(file.getName() + ": NEW\n");
                                System.out.print(output);
                                shouldReadNextLine = Boolean.FALSE;
                                savedLine = line;
                            }
                            //should read next line but not read next file
                            else if (missmatchLowerOrHigher == Boolean.TRUE) {
                                StringBuilder output = new StringBuilder();
                                output.append(lineWithNoAddedThings + ": DELETED\n");
                                System.out.print(output);
                                shouldReadNextFile = Boolean.FALSE;
                                savedlFile = file;
                            }
                        }
                    } catch (Exception ex) {    //if folder after file deleted(in windows it cant happen apparently)
                        StringBuilder output = new StringBuilder();
                        output.append(line + " DELETED\n");
                        System.out.print(output);
                        shouldReadNextFile = Boolean.FALSE;
                        savedlFile = file;
                    }
                } else if (file.isFile()) {
                    try {
                        String lineWithNoAddedThings = line.substring(0, line.indexOf('_'));
                        StringBuilder fileConcatTabs = new StringBuilder();
                        for (int i = 0; i < noTabs; i++) {
                            fileConcatTabs.append("   ");
                        }
                        String fileWithAddedTabs = fileConcatTabs.append(fileName).toString();

                        String digestFromLine = line.substring(line.indexOf('_') + 1, line.length());


                        char[] first = lineWithNoAddedThings.toLowerCase().toCharArray();
                        char[] second = fileWithAddedTabs.toLowerCase().toCharArray();
                        int minLength = Math.min(first.length, second.length);
                        boolean didWeFindMissmatch = false;
                        boolean missmatchLowerOrHigher = true;//false=lower true=higher
                        for (int i = 0; i < minLength && !didWeFindMissmatch; i++) {
                            if (first[i] > second[i]) {
                                didWeFindMissmatch = true;
                                missmatchLowerOrHigher = false;
                            }
                            if (first[i] < second[i]) {
                                didWeFindMissmatch = true;
                                missmatchLowerOrHigher = true;
                            }
                        }
                        if (!didWeFindMissmatch && getHex(getHMAC(file.getAbsolutePath(), key, "HmacSHA256")).equals(digestFromLine)) {
                            StringBuilder output = new StringBuilder();
                            for (int i = 0; i < noTabs; i++) {
                                output.append("   ");
                            }
                            output.append(file.getName() + " OK\n");
                            System.out.print(output);

                            //Checks files into ok directory
                            checkFiles(file, inputReader, noTabs + 1, key);
                        } else if (didWeFindMissmatch) {
                            //should read next file but not read next line
                            if (missmatchLowerOrHigher == Boolean.FALSE) {
                                StringBuilder output = new StringBuilder();
                                for (int i = 0; i < noTabs; i++) {
                                    output.append("   ");
                                }
                                output.append(file.getName() + " NEW\n");
                                System.out.print(output);
                                shouldReadNextLine = Boolean.FALSE;
                                savedLine = line;
                            }
                            //should read next line but not read next file
                            else if (missmatchLowerOrHigher == Boolean.TRUE) {
                                StringBuilder output = new StringBuilder();
                                output.append(lineWithNoAddedThings + " DELETED\n");
                                System.out.print(output);
                                shouldReadNextFile = Boolean.FALSE;
                                savedlFile = file;
                            }
                        } else if (!getHex(getHMAC(file.getAbsolutePath(), key, "HmacSHA256")).equals(digestFromLine)) {
                            StringBuilder output = new StringBuilder();
                            for (int i = 0; i < noTabs; i++) {
                                output.append("   ");
                            }
                            output.append(file.getName() + " CORRUPTED\n");
                            System.out.print(output);
                        }
                    } catch (Exception ex) {    //if file after folder deleted(in windows it cant happen apparently)
                        StringBuilder output = new StringBuilder();
                        output.append(line + " DELETED\n");
                        System.out.print(output);
                        shouldReadNextFile = Boolean.FALSE;
                        savedlFile = file;
                    }
                }
            }
        }
    }

    //There can be edge cases on the file system that I have not thought about...
    public static void main(String[] args) throws IOException, NoSuchAlgorithmException, InvalidKeyException {
        //region Checking input
        String mode;
        String key;
        String filePath;
        //Check args
        if (args.length > 3 || args.length < 2) {
            System.out.println("Usage of program: java.exe thisApp.java scan/check(whichever you want) yourSecret[optional(\"yoursecret\" is used if nothing is provided)](key for creation of the digest of files) pathToFiles");
            return;
        }
        if (!args[0].equals("scan") && !args[0].equals("check")) {
            System.out.println("Wrong mode used. Please use scan or check.");
            System.out.println("Usage of program: java.exe thisApp.java scan/check(whichever you want) yourSecret[optional(\"soursecret\" is used if nothing is provided)](key for creation of the digest of files) pathToFiles");
            return;
        }
        mode = args[0];
        if (args.length == 3) {
            key = args[1];
            filePath = args[2];
        } else {
            key = "yoursecret";
            filePath = args[1];
        }
        //Display values used
        System.out.println("Mode used is: " + mode);
        System.out.println("Key used is: " + key);
        System.out.println("Mode used is: " + filePath);
        //endregion

        //scan mode
        if (mode.equals("scan")) {
            //Check of input validity
            File root = new File(filePath);
            if (!root.exists()) {
                System.out.println("Wrong route. Please check what you are trying to scan.");
                System.out.println("Usage of program: java.exe thisApp.java scan/check(whichever you want) yourSecret[optional(\"soursecret\" is used if nothing is provided)](key for creation of the digest of files) pathToFiles");
                return;
            }
            if (!root.isDirectory()) {
                System.out.println("Wrong route. Please check what you are trying to scan.");
                System.out.println("Usage of program: java.exe thisApp.java scan/check(whichever you want) yourSecret[optional(\"soursecret\" is used if nothing is provided)](key for creation of the digest of files) pathToFiles");
                return;
            }
            //Create file where the name of folders and files plus the digest of each file will go
            File outputFile = new File("integrity.txt");
            if (!outputFile.exists()) {
                outputFile.createNewFile();
            }


            FileOutputStream fos = new FileOutputStream(outputFile);
            BufferedOutputStream bos = new BufferedOutputStream(fos);

            System.out.println("Text written to \"integrity.txt\":");

            System.out.print(filePath + ":\n");
            bos.write((filePath + ":\n").getBytes());

            //Scan the files and place output in "integrity.txt"
            scanFiles(root, bos, 1, key);

            bos.close();
            return;
        }
        //check mode
        if (mode.equals("check")) {
            //Check of input validity
            File root = new File(filePath);
            if (!root.exists()) {
                System.out.println("Wrong route. Please check what you are trying to scan.");
                System.out.println("Usage of program: java.exe thisApp.java scan/check(whichever you want) yourSecret[optional(\"soursecret\" is used if nothing is provided)](key for creation of the digest of files) pathToFiles");
                return;
            }
            if (!root.isDirectory()) {
                System.out.println("Wrong route. Please check what you are trying to scan.");
                System.out.println("Usage of program: java.exe thisApp.java scan/check(whichever you want) yourSecret[optional(\"soursecret\" is used if nothing is provided)](key for creation of the digest of files) pathToFiles");
                return;
            }
            File inputFile = new File("integrity.txt");
            if (!inputFile.exists()) {
                System.out.println("Wrong use of program. Please use the scan functionality first.");
                System.out.println("Usage of program: java.exe thisApp.java scan/check(whichever you want) yourSecret[optional(\"soursecret\" is used if nothing is provided)](key for creation of the digest of files) pathToFiles");
                return;
            }

            FileReader fr = new FileReader(inputFile);
            BufferedReader br = new BufferedReader(fr);

            String line = br.readLine();
            if (!line.equals(root.toString() + ":")) {
                System.out.println("Wrong use of program. Please use the scan functionality first on the proper directory.");
                System.out.println("The last scan has to be on the same folder.");
                System.out.println("Usage of program: java.exe thisApp.java scan/check(whichever you want) yourSecret[optional(\"soursecret\" is used if nothing is provided)](key for creation of the digest of files) pathToFiles");
                return;
            }

            checkFiles(root, br, 1, key);

            br.close();
            return;
        }
    }
}