package ro.ase.ism.sap.day4;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.IOException;
import java.security.*;
import java.security.cert.CertificateException;

public class Main {
    public static void main(String[] args) throws CertificateException, IOException, KeyStoreException, NoSuchAlgorithmException, UnrecoverableKeyException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, InvalidKeyException, SignatureException {
        //keystore
        KeyStore keyStore = KeyStoreManager.loadKeyStore("ismkeystore.ks", "passks", "pkcs12");//.store (fos, pass)

        KeyStoreManager.listKeyStoreContent(keyStore);

        PublicKey ism1PubKey = KeyStoreManager.getCertificateKey("ISMCertificateX509.cer");

        System.out.println("ISM1 key algorithm " + ism1PubKey.getAlgorithm());

        System.out.println("ISM1 public key: " + Util.getHex(ism1PubKey.getEncoded()));

        PublicKey ism1PubKeyFromKS = KeyStoreManager.getKeyStorePublicKey(keyStore, "ismkey1");//din comanda

        System.out.println("ISM1 key algorithm in KS " + ism1PubKeyFromKS.getAlgorithm());

        System.out.println("ISM1 public key from KS: " + Util.getHex(ism1PubKeyFromKS.getEncoded()));

        PrivateKey ism1PrivKeyFromKS = KeyStoreManager.getKeyStorePrivateKey(keyStore,"ismkey1", "passks");//din comanda
        //comanda init dadea parola pt fiecare per de chei
        System.out.println("ISM1 private key from KS: " + Util.getHex(ism1PrivKeyFromKS.getEncoded()));

        byte[] AESRandomSessionKey = Util.getRandomBytes(16,null);

        System.out.println("AES session key: ");
        System.out.println(Util.getHex(AESRandomSessionKey));

        byte[] encryptedSessionKey = RSACipher.encrypt(ism1PrivKeyFromKS,AESRandomSessionKey);
        System.out.println("Encrypted key "+Util.getHex(encryptedSessionKey));
        byte[] decryptedSesstionKey = RSACipher.decrypt(ism1PubKey,encryptedSessionKey);
        System.out.println("Decrypted key "+Util.getHex(decryptedSesstionKey));

        byte[] digitalSigniture = RSACipher.generateDigitalSigniture("Message.txt", ism1PrivKeyFromKS, "SHA256withRSA");
        System.out.println("Digital signiture: " + Util.getHex(digitalSigniture));

        if(RSACipher.hasValidSigniture("Message.txt",ism1PubKeyFromKS, digitalSigniture,"SHA256withRSA")) {
            System.out.println("The message is valid");
        }
        else{
            System.out.println("The message is not valid");
        }
    }
}
