package ro.ase.ism.sap.day2;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import java.security.Provider;
import java.security.Security;

public class CryptoUtil {

    public static boolean isProviderAviable(String providerName){
        Provider provider = Security.getProvider(providerName);
        return provider != null;
        //return provider==null?false:true;
    }
    public static void loadBouncyCastleProvider(){
        Security.addProvider(new BouncyCastleProvider());
    }
    public static String getHex(byte[]bytes){
        StringBuilder sb = new StringBuilder();
        for(byte value : bytes){
            sb.append(String.format("%02xh ", value).toUpperCase());
        }
        return sb.toString();
    }

}
