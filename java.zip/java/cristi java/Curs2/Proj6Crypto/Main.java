package ro.ase.ism.sap.day2;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;

public class Main {
    public static final String BouncyCastleProvider = "BC";
    public static void main(String[] args) throws NoSuchAlgorithmException, NoSuchProviderException, IOException {
        //how to switch between crypto algorithms instantly.
        CryptoUtil.loadBouncyCastleProvider();  //allows us to use BC
        if(CryptoUtil.isProviderAviable(BouncyCastleProvider)){
            System.out.println("Bouncy Castle is available");
        }
        else{
            System.out.println("Bouncy Castle is not available");
        }

        if(CryptoUtil.isProviderAviable("SUN")){
            System.out.println("SUN is available");
        }
        else{
            System.out.println("SUN is not available");
        }

        if(CryptoUtil.isProviderAviable("SunJCE")){
            System.out.println("SunJCE is available");
        }
        else{
            System.out.println("SunJCE is not available");
        }
        //test random bytes
        byte[]randomBytes = RandomGenerator.GetRanomBytes(16);
        System.out.println(CryptoUtil.getHex(randomBytes));

//        byte[]randomBytesBC = RandomGenerator.GetRanomBytesWithBC(16);
//        System.out.println(CryptoUtil.getHex(randomBytesBC));//no implem

        byte[] seed = "password".getBytes();
        randomBytes = RandomGenerator.GetRanomBytes(16, seed);
        System.out.println("Random bytes:");
        System.out.println(CryptoUtil.getHex(randomBytes));

        //testing OPT encryption
        OTP.encrypt("message.txt", "message.enc", "random.key");

        OTP.decrypt("message.enc", "random.key", "message.txt");

        String password = "password";
        byte[] passHash = HASH.getHashValue(password, "MD5");
        System.out.println("MD5 os 'password':" + CryptoUtil.getHex(passHash));

        passHash = HASH.getHashValue(password, "SHA-1");
        System.out.println("SHA-1 os 'password':" + CryptoUtil.getHex(passHash));

        passHash = HASH.getHashValue(password, "MD5", "BC");
        System.out.println("MD5 os 'password':" + CryptoUtil.getHex(passHash));

        passHash = HASH.getHashValue(password, "SHA-1", "BC");
        System.out.println("SHA-1 os 'password':" + CryptoUtil.getHex(passHash));

        byte[] fileHash = HASH.getFileHashValue("message.txt", "SHA-256");
        System.out.println("SHA-256 os 'password':" + CryptoUtil.getHex(fileHash));
    }
}