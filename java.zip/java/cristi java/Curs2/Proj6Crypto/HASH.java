package ro.ase.ism.sap.day2;

import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;

public class HASH {

    public static byte[] getHashValue(String value, String algorithm) throws NoSuchAlgorithmException {
        //call update, call digest
        //for a file we break it in 128bit length chunks update call
        MessageDigest md = MessageDigest.getInstance(algorithm);
        return md.digest(value.getBytes());
    }

    public static byte[] getHashValue(String value, String algorithm, String provider) throws NoSuchAlgorithmException, NoSuchProviderException {
        MessageDigest md = MessageDigest.getInstance(algorithm, provider);
        return md.digest(value.getBytes());
    }


    public static byte[] getFileHashValue(String fileName, String algorithm) throws NoSuchAlgorithmException, IOException {
        File file = new File(fileName);
        if(!file.exists()){
            throw new FileNotFoundException("No input file");
        }
        FileInputStream fis = new FileInputStream(file);
        BufferedInputStream bis = new BufferedInputStream(fis);

        MessageDigest md = MessageDigest.getInstance(algorithm);

        //read file and process the hash
        byte[] buffer = new byte[10];
        int noBytes = 0;

        while(noBytes!=-1){
            noBytes = bis.read(buffer);
            if(noBytes>0){
                //update
                //md.update(buffer);//buffer still has residual data
                //wrong
                md.update(buffer,0,noBytes);//to treat the last residual data
            }
        }
        bis.close();

        return md.digest();
    }
}
