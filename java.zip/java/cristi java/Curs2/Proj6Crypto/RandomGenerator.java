package ro.ase.ism.sap.day2;

import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.util.Random;

public class RandomGenerator {
    //don't use it. it's not secure
    public static byte[] doNotUseGenerator(int noBytes){
        Random rand = new Random();
        byte[] notRandomValue = new byte[noBytes];
        rand.nextBytes(notRandomValue);
        return notRandomValue;
    }

    public static byte[] GetRanomBytes(int noBytes) throws NoSuchAlgorithmException {
        SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
        byte[] randomValue = new byte[noBytes];
        secureRandom.nextBytes(randomValue);
        return randomValue;
    }

//    public static byte[] GetRanomBytesWithBC(int noBytes) throws NoSuchAlgorithmException, NoSuchProviderException {
//        SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG","BC");
//        byte[] randomValue = new byte[noBytes];
//        secureRandom.nextBytes(randomValue);
//        return randomValue;
//    }//has no implem

    public static byte[] GetRanomBytes(int noBytes, byte[]seed) throws NoSuchAlgorithmException {
        SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
        secureRandom.setSeed(seed);
        byte[] randomValue = new byte[noBytes];
        secureRandom.nextBytes(randomValue);
        return randomValue;
    }

}
