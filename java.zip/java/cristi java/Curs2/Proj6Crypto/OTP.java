package ro.ase.ism.sap.day2;

import java.io.*;
import java.security.NoSuchAlgorithmException;

public class OTP {
    public static void encrypt(String plaintextFileName, String ciphertextFileName, String keyFileName) throws NoSuchAlgorithmException, IOException {
        File plaintextFile = new File(plaintextFileName);
        if(!plaintextFile.exists()){
            throw new FileNotFoundException("No plaintext file.");
        }

        File ciphertextFile = new File(ciphertextFileName);
        if(!ciphertextFile.exists()){
            ciphertextFile.createNewFile();
        }

        File keyFile = new File(keyFileName);
        if(!keyFile.exists()){
            keyFile.createNewFile();
        }

        long plaintextSize = (long) plaintextFile.length();

        byte[] randomKey = RandomGenerator.GetRanomBytes((int) plaintextSize);

        FileInputStream fis = new FileInputStream(plaintextFile);
        BufferedInputStream bis = new BufferedInputStream(fis);

        FileOutputStream fos = new FileOutputStream(ciphertextFile);
        BufferedOutputStream bos = new BufferedOutputStream(fos);

        byte[] buffer = new byte[1];
        int noBytesFromFile = 0;
        int keyByteCounter = 0;

        //reading and xor each byte from plaintext also write it to ciphertext output file
        while(noBytesFromFile!=-1){
            noBytesFromFile = bis.read(buffer);
            if(noBytesFromFile == 1){
                buffer[0] = (byte) (buffer[0]^randomKey[keyByteCounter]);
                keyByteCounter++;
                bos.write(buffer);
            }
        }

        bis.close();
        bos.close();

        fos = new FileOutputStream(keyFile);
        bos = new BufferedOutputStream(fos);

        bos.write(randomKey); //write key in file

        bos.close();
    }

    public static void decrypt(String ciphertextFileName, String keyFileName, String plaintextFileName) throws NoSuchAlgorithmException, IOException {
        File plaintextFile = new File(plaintextFileName);
        if(!plaintextFile.exists()){
            plaintextFile.createNewFile();
        }

        File ciphertextFile = new File(ciphertextFileName);
        if(!ciphertextFile.exists()){
            throw new FileNotFoundException("No ciphertext file.");
        }

        File keyFile = new File(keyFileName);
        if(!keyFile.exists()){
            throw new FileNotFoundException("No key file.");
        }

        if(ciphertextFile.length()!= keyFile.length()){
            throw new UnsupportedOperationException("Different file sizes.");
        }

        FileInputStream fis = new FileInputStream(ciphertextFile);
        BufferedInputStream bis = new BufferedInputStream(fis);

        FileInputStream fis2 = new FileInputStream(keyFileName);
        BufferedInputStream bis2 = new BufferedInputStream(fis2);

        FileOutputStream fos = new FileOutputStream(plaintextFile);
        BufferedOutputStream bos = new BufferedOutputStream(fos);

        byte[] buffer = new byte[1];
        byte[] buffer2 = new byte[1];
        int noBytesFromFile = 0;
        int noBytesFromFile2 = 0;

        //reading and xor each byte from plaintext also write it to ciphertext output file
        while(noBytesFromFile!=-1&&noBytesFromFile2!=-1){
            noBytesFromFile = bis.read(buffer);
            noBytesFromFile2 = bis2.read(buffer2);
            if(noBytesFromFile == 1){
                buffer[0] = (byte) (buffer[0]^buffer2[0]);
                bos.write(buffer);
            }
        }

        bis.close();
        bis2.close();
        bos.close();
    }
}
