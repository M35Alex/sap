package ro.ase.ism.sap.day2;

import java.util.*;

public class Main {

    public static class Box{
        Object content;

        public Object getContent() {
            return content;
        }

        public void setContent(Object content) {
            this.content = content;
        }
    }
    public static class GenericBox<T>{//, otherType
        T content;
        float weight;
        //otherType attribute;

        public T getContent() {
            return content;
        }

        public void setContent(T content) {
            this.content = content;
        }
    }

    public static class User{
        String username;
        int id;

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }


        //we need those to let it be "unique" in set
        @Override
        public int hashCode() {
            return this.username.hashCode();
        }

        @Override
        public boolean equals(Object obj) {
            if(!(obj instanceof User)) {
                return false;
            }
            else{
                User userObj = (User) obj;
                return this.username.equals(userObj.username);
            }
        }

        @Override
        public String toString() {
            return "User{" +
                    "username='" + username + '\'' +
                    ", id=" + id +
                    '}';
        }
    }

    public static void main(String[] args) {
        Box stringBox = new Box();
        stringBox.setContent("Hello!");
        System.out.println("Message:" + stringBox.getContent());

        stringBox.setContent(23.6);
        System.out.println("Message:" + stringBox.getContent());
        //can be used with wrong type
        //can be cast wrongly. We should not allow devs to place a diff type in a box
        //they introduced templates in c/generics in java

        GenericBox<String> stringGenericBoxBox = new GenericBox<String>();
        stringGenericBoxBox.setContent("AAA");
        System.out.println(stringGenericBoxBox.getContent());

        //lists, sets and maps are similar in idea but behave differently

        GenericBox<Integer> integerGenericBox = new GenericBox<>();
        integerGenericBox.setContent(1);


        //test collections
        List<String> names = new ArrayList<>();
        names.add("John");
        names.add("Alice");
        names.add("Bob");
        names.add("John");

        System.out.println(names.toString());

        Set<String> uniqueNames = new HashSet<>();
        uniqueNames.add("John");
        uniqueNames.add("Alice");
        uniqueNames.add("Bob");
        uniqueNames.add("John");

        System.out.println(uniqueNames.toString());

        Map<Integer,String> users = new HashMap<>();
        users.put(1, "John");
        users.put(5, "Alice");
        users.put(20, "Bob");
        users.put(1, "Vader");

        System.out.println(users.toString());

        System.out.println(users.get(20));
        System.out.println(users.get(23));

        User user1 = new User();
        user1.username="Alin";
        user1.id=1;

        User user2 = new User();
        user2.username="Alin";
        user2.id=1;

        User user3 = new User();
        user3.username="Mihai";
        user3.id=2;

        Set<User> userSet = new HashSet<>();
        userSet.add(user1);
        userSet.add(user2);
        userSet.add(user3);

        System.out.println(userSet);
    }
}