package ro.ase.ism.day2;

import java.io.*;

public class Main {
    public static void main(String[] args) throws IOException {
        File newFile;
        newFile = new File("message.txt"); //,true for append mode
        //the file is relative to the project folder root
        if(!newFile.exists()){
            newFile.createNewFile();
        }
        //write into the text file
        FileWriter fileWriter = new FileWriter(newFile);
        PrintWriter printWriter = new PrintWriter(fileWriter);  //to create the idea of pipeline
        //we can still use the FileWriter

        printWriter.println("This is a secret message.");
        printWriter.println("Don't tell anyone.");

        //always close the file from any object of the pipeline
        fileWriter.close();
        System.out.println("File written!");

        //read from the text file
        FileReader fileReader = new FileReader(newFile);
        BufferedReader bufferedReader = new BufferedReader(fileReader);

//        System.out.println(bufferedReader.readLine());
//        System.out.println(bufferedReader.readLine());
        String line = bufferedReader.readLine();
        while(line!=null) {//not eof
            System.out.println("Text file line:"+line);
            line = bufferedReader.readLine();
        }
        fileReader.close();
        System.out.println("File read!");


        //play with the file system
        //scan to check hard drive
        //only File class interacts with the file system
        File folderRoot = new File("C:\\Users\\dumi_\\AllFiles\\University\\SecureApplicationProgramming");
        if(folderRoot.exists()&&folderRoot.isDirectory()){
            File[] subContent = folderRoot.listFiles();
            for(File content:subContent){
                String description = content.isFile()?"Is a file":"Is a folder";
                System.out.println(content.getName() + "-" + description);
            }
        }

//        File tempFolder = new File("C:\\Users\\dumi_\\AllFiles\\University\\SecureApplicationProgramming\\tempFolder");
//        if(!tempFolder.exists()){
//            tempFolder.mkdir();
//        }

        //using binary files
        File myData = new File("mySecret.data");
        if(!myData.exists()){
            myData.createNewFile();
        }
        FileOutputStream fos = new FileOutputStream(myData);
        BufferedOutputStream bos = new BufferedOutputStream(fos);
        DataOutputStream dos = new DataOutputStream(bos);

        int intValue = 23;
        float floatValue = 23.5F;
        boolean booleanValue = true;
        String stringValue = "John";

        dos.writeInt(intValue);
        //dos.write(intValue);
        dos.writeBoolean(booleanValue);
        dos.writeFloat(floatValue);
        dos.writeUTF(stringValue);
        //dos.writeChars(stringValue);

        dos.close();


        //reading from binary files
        FileInputStream fis = new FileInputStream(myData);
        BufferedInputStream bis = new BufferedInputStream(fis);
        DataInputStream dis = new DataInputStream(bis);

        int intValueRead = dis.readInt();
        boolean booleanValueRead = dis.readBoolean();
        float floatValueRead = dis.readFloat();
        String stringValueRead = dis.readUTF();

        System.out.println("Int:" + intValueRead);
        System.out.println("Float:" + floatValueRead);
        System.out.println("Boolean:" + booleanValueRead);
        System.out.println("String:" + stringValueRead);

        dis.close();


        //using RandomAccessFile    //literally c
        File values = new File("values.bin");
        RandomAccessFile raf = new RandomAccessFile(values, "rw");

        byte[] numbers = {10,20,30,40};
        for(byte number:numbers){
            raf.write(number);
        }
        raf.close();

        raf = new RandomAccessFile(values, "r");

        raf.seek(2);
        byte thirdNumber = raf.readByte();

        System.out.println(thirdNumber);
        raf.close();

        //workaround to get file size
        raf = new RandomAccessFile(values, "r");
        long fileSize = raf.length();

        System.out.println("File size is " + fileSize);
        raf.close();
    }
}